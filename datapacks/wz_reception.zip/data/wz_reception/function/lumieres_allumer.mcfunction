scoreboard players set #lum wz_rec 1
execute as @e[type=marker,tag=wz_rec_lum] at @s if block ~ ~ ~ air run setblock ~ ~ ~ light[level=15]
tellraw @s {"text":"Lustres allumés.","color":"gold"}
