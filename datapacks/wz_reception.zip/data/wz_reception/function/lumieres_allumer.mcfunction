scoreboard players set #lum wz_rec 1
execute as @e[type=marker,tag=wz_rec_lum,tag=!wz_rec_lum_app] at @s if block ~ ~ ~ air run setblock ~ ~ ~ light[level=15]
execute as @e[type=marker,tag=wz_rec_lum_app] at @s if block ~ ~ ~ air run setblock ~ ~ ~ light[level=13]
tellraw @s {"text":"Lustres et appliques allumés.","color":"gold"}
function wz_reception:lumiere_maj
