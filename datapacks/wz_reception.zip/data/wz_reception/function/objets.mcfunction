give @s barrier[item_model="wozorfoz:nappe_fontaine",item_name={text:"Nappe de banquet 3×4 (avec fontaine)",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:nappe",item_name={text:"Nappe de banquet 3×4",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:nappe6_fontaine",item_name={text:"Nappe de banquet 3×6 (avec fontaine)",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:nappe6",item_name={text:"Nappe de banquet 3×6",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:fontaine",item_name={text:"Fontaine à champagne",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:lustre_tulipes",item_name={text:"Grand lustre à tulipes",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:lustre_cristal",item_name={text:"Grand lustre à pampilles",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:chaine_lustre",item_name={text:"Chaîne de lustre",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:piano_queue",item_name={text:"Piano à queue de concert",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:banquette_piano",item_name={text:"Banquette de piano",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:chaise_banquet",item_name={text:"Chaise de banquet",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:bouquet_table",item_name={text:"Centre de table fleuri",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:grand_bouquet",item_name={text:"Grand vase de fleurs",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:portrait_fro",item_name={text:"Portrait de Fro (3 × 4)",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:portrait_kora",item_name={text:"Portrait du Consul Koraneii (3 × 4)",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:portrait_blason",item_name={text:"Tableau du blason de l'Empire (3 × 4)",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:laurier_versailles",item_name={text:"Laurier en caisse (feuillage 2 blocs)",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:laurier_haut",item_name={text:"Laurier en caisse (feuillage 3 blocs)",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:buis_medicis",item_name={text:"Buis en vase Médicis",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:orchidee",item_name={text:"Orchidée blanche",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:lys_vase",item_name={text:"Lys blancs en vase",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:applique_bougies",item_name={text:"Applique à bougies",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:applique_cristal",item_name={text:"Applique à pampilles",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:applique_tulipes",item_name={text:"Applique à tulipes",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:hortensias",item_name={text:"Hortensias bleus en vase",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:roses_rouges",item_name={text:"Roses rouges en vase",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:pivoines",item_name={text:"Pivoines en vase",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:torchere",item_name={text:"Torchère dorée (3 de haut)",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:arche_doree",item_name={text:"Arche dorée ajourée (5 × 5)",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:rideaux_embrasses",item_name={text:"Rideaux à embrasses (3 × 6)",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:tenture_brodee",item_name={text:"Tenture brodée (2 × 6)",color:"gold"}] 4
give @s barrier[item_model="wozorfoz:draperie_festons",item_name={text:"Draperie à festons (3 × 4)",color:"gold"}] 4
tellraw @s [{"text":"Nappe : ","color":"gold","bold":true},{"text":"c'est une table complète : pose-la AU SOL (sans table dessous), colonne du milieu, en regardant dans le sens de la longueur : 2e bloc depuis ton bout pour la 3 × 4, 3e bloc pour la 3 × 6. Elle se rend solide toute seule.\n","color":"gold","bold":false},{"text":"Lustres : ","bold":true},{"text":"au plafond (ils pendent sur environ 3,5 blocs) ; des chaînes au-dessus pour les descendre.\n","bold":false},{"text":"Tapis 5 × 6 : ","bold":true},{"text":"/function wz_reception:tapis_imperial, tapis_ivoire ou tapis_nuit (colonne du milieu, 3e bloc depuis le bout derrière toi).\n","bold":false},{"text":"Tapis 7 × 10 : ","bold":true},{"text":"tapis7x10_imperial, tapis7x10_ivoire ou tapis7x10_nuit (colonne du milieu, 5e bloc depuis le bout derrière toi).\n","bold":false},{"text":"Buffet : ","bold":true},{"text":"regarde la table du buffet et /function wz_reception:jupe.\n","bold":false},{"text":"Piano : ","bold":true},{"text":"pose-le en te tenant au clavier, barrière au milieu du clavier : il occupe 3 blocs de large sur 4 de long, vers l'avant ; banquette devant le clavier.\n","bold":false},{"text":"Chaises : ","bold":true},{"text":"pose-les en regardant la table (clic droit pour s'asseoir, accroupi pour se lever).\n","bold":false},{"text":"Fleurs : ","bold":true},{"text":"le centre de table se pose sur la table, le grand vase au sol.\n","bold":false},{"text":"Plantes : ","bold":true},{"text":"remplace le pot décoré (et sa tige, ses feuilles) par la barrière, sur le socle en terre cuite.\n","bold":false},{"text":"Tableaux : ","bold":true},{"text":"pose la barrière contre le mur, au bloc du bas au milieu : le tableau monte de 4 blocs et déborde d'un bloc de chaque côté.\n","bold":false},{"text":"Appliques : ","bold":true},{"text":"pose la barrière contre le pilier, à hauteur d'applique (elle s'allume toute seule).\n","bold":false},{"text":"Rideaux, tenture, draperie : ","bold":true},{"text":"barrière AU SOL contre le mur, au milieu : les rideaux montent de 6 blocs (3 de large), la tenture de 6 (2 de large), la draperie commence 1 bloc au-dessus du sol.\n","bold":false},{"text":"Torchère, arche : ","bold":true},{"text":"barrière au sol ; l'arche se pose au centre, en regardant le public, et s'étend de 2,5 blocs de chaque côté.","bold":false}]
