summon marker ~0.5 ~0.5 ~0.5 {Tags:["wz_rec_lum_torch","wz_rec_part"]}
