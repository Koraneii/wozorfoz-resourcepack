advancement revoke @s only wz_reception:assise_clic
tag @s add wz_rec_assis
execute as @e[type=interaction,tag=wz_rec_assise,distance=..8] if data entity @s interaction run function wz_reception:assise_asseoir
tag @s remove wz_rec_assis
