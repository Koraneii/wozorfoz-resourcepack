execute if entity @s[tag=wz_rec_nappe] rotated as @s run function wz_reception:nappe_vider
execute if entity @s[tag=wz_rec_nappe_fontaine] rotated as @s run function wz_reception:nappe_vider
execute if entity @s[tag=wz_rec_nappe6] rotated as @s run function wz_reception:nappe6_vider
execute if entity @s[tag=wz_rec_nappe6_fontaine] rotated as @s run function wz_reception:nappe6_vider
execute if entity @s[tag=wz_rec_piano_queue] rotated as @s run function wz_reception:piano_vider
execute if block ~ ~-0.5 ~ barrier run setblock ~ ~-0.5 ~ air
kill @e[type=interaction,tag=wz_rec_part,distance=..0.8]
execute as @e[type=marker,tag=wz_rec_lum,distance=..3.6] at @s if block ~ ~ ~ light run setblock ~ ~ ~ air
execute positioned ~ ~-3 ~ run kill @e[type=marker,tag=wz_rec_lum,distance=..0.2]
execute positioned ~ ~-2 ~ run kill @e[type=marker,tag=wz_rec_lum,distance=..0.2]
kill @s
