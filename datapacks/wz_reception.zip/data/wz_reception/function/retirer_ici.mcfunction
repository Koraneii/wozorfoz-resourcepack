execute if entity @s[tag=wz_rec_nappe] rotated as @s run function wz_reception:nappe_vider
execute if entity @s[tag=wz_rec_nappe_fontaine] rotated as @s run function wz_reception:nappe_vider
execute if entity @s[tag=wz_rec_nappe6] rotated as @s run function wz_reception:nappe6_vider
execute if entity @s[tag=wz_rec_nappe6_fontaine] rotated as @s run function wz_reception:nappe6_vider
execute if entity @s[tag=wz_rec_piano_queue] rotated as @s run function wz_reception:piano_vider
execute if block ~ ~-0.5 ~ barrier run setblock ~ ~-0.5 ~ air
kill @e[type=interaction,tag=wz_rec_part,distance=..0.8]
execute positioned ~ ~-3 ~ as @e[type=marker,tag=wz_rec_lum,distance=..0.2] at @s run function wz_reception:lum_retirer
execute positioned ~ ~-2 ~ as @e[type=marker,tag=wz_rec_lum,distance=..0.2] at @s run function wz_reception:lum_retirer
execute if entity @s[tag=wz_rec_applique_bougies] as @e[type=marker,tag=wz_rec_lum_app,distance=..1.1,sort=nearest,limit=1] at @s run function wz_reception:lum_retirer
execute if entity @s[tag=wz_rec_applique_cristal] as @e[type=marker,tag=wz_rec_lum_app,distance=..1.1,sort=nearest,limit=1] at @s run function wz_reception:lum_retirer
execute if entity @s[tag=wz_rec_applique_tulipes] as @e[type=marker,tag=wz_rec_lum_app,distance=..1.1,sort=nearest,limit=1] at @s run function wz_reception:lum_retirer
execute if entity @s[tag=wz_rec_torchere] positioned ~ ~2 ~ as @e[type=marker,tag=wz_rec_lum_torch,distance=..0.6,sort=nearest,limit=1] at @s run function wz_reception:lum_retirer
kill @s
