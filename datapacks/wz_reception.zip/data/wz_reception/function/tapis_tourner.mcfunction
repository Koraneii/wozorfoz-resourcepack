# Tourne d'un quart de tour le tapis le plus proche (il reste aligné sur les blocs)
execute as @e[type=item_display,tag=wz_rec_tapis,distance=..6,sort=nearest,limit=1] at @s run tp @s ~ ~ ~ ~90 0
