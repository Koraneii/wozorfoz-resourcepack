advancement revoke @s only wz_reception:pose_draperie_festons
scoreboard players set #ray wz_rec 0
execute anchored eyes positioned ^ ^ ^ run function wz_reception:rayon_draperie_festons
