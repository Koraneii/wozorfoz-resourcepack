advancement revoke @s only wz_reception:pose_buis_medicis
scoreboard players set #ray wz_rec 0
execute anchored eyes positioned ^ ^ ^ run function wz_reception:rayon_buis_medicis
