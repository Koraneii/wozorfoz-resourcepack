kill @e[type=item_display,tag=wz_rec_tapis,distance=..5,sort=nearest,limit=1]
tellraw @s {"text":"Tapis retiré.","color":"gold"}
