# allume ou éteint les torchères selon l'éclairage de la scène
scoreboard players operation #torch wz_rec = #t_new wz_rec
execute if score #torch wz_rec matches 1 as @e[type=item_display,tag=wz_rec_torchere] run data merge entity @s {brightness:{sky:15,block:15}}
execute unless score #torch wz_rec matches 1 as @e[type=item_display,tag=wz_rec_torchere] run data remove entity @s brightness
execute if score #torch wz_rec matches 1 as @e[type=marker,tag=wz_rec_lum_torch] at @s if block ~ ~ ~ air run setblock ~ ~ ~ light[level=14]
execute unless score #torch wz_rec matches 1 as @e[type=marker,tag=wz_rec_lum_torch] at @s if block ~ ~ ~ light run setblock ~ ~ ~ air
