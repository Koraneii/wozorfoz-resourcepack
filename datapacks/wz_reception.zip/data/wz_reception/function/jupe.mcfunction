# Regardez un bloc de la table du buffet : la jupe habille ce bloc et tous les blocs identiques alignés avec lui
scoreboard players set #ray wz_rec 0
execute anchored eyes positioned ^ ^ ^ run function wz_reception:jupe_rayon
