function wz_reception:jupe_ici
scoreboard players add #pas wz_rec 1
execute if score #pas wz_rec matches ..30 if blocks ~ ~ ~ ~ ~ ~ ~ ~ ~1 all positioned ~ ~ ~1 run function wz_reception:jupe_pz
