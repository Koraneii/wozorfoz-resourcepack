# Retire les objets dont le bloc barrière a été cassé à la main
execute as @e[type=item_display,tag=wz_rec_obj] at @s unless block ~ ~-0.5 ~ barrier run kill @s
execute as @e[type=interaction,tag=wz_rec_part] at @s unless block ~ ~0.1 ~ barrier run kill @s
execute as @e[type=marker,tag=wz_rec_lum,tag=!wz_rec_lum_app] at @s unless block ~ ~3 ~ barrier unless block ~ ~2 ~ barrier run function wz_reception:lum_retirer
execute as @e[type=marker,tag=wz_rec_lum_app] at @s unless entity @e[type=item_display,tag=wz_rec_obj,distance=..1.1] unless entity @e[type=item_display,tag=wz_rec_torchere,distance=..2.2] run function wz_reception:lum_retirer
tellraw @s {"text":"Objets orphelins nettoyés.","color":"gold"}
