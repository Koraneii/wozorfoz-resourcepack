# remplit les blocs de la table de barrieres (collision)
execute positioned ^-1 ^ ^-1 if block ~ ~ ~ #wz_reception:remplacable run setblock ~ ~ ~ barrier
execute positioned ^-1 ^ ^0 if block ~ ~ ~ #wz_reception:remplacable run setblock ~ ~ ~ barrier
execute positioned ^-1 ^ ^1 if block ~ ~ ~ #wz_reception:remplacable run setblock ~ ~ ~ barrier
execute positioned ^-1 ^ ^2 if block ~ ~ ~ #wz_reception:remplacable run setblock ~ ~ ~ barrier
execute positioned ^0 ^ ^-1 if block ~ ~ ~ #wz_reception:remplacable run setblock ~ ~ ~ barrier
execute positioned ^0 ^ ^1 if block ~ ~ ~ #wz_reception:remplacable run setblock ~ ~ ~ barrier
execute positioned ^0 ^ ^2 if block ~ ~ ~ #wz_reception:remplacable run setblock ~ ~ ~ barrier
execute positioned ^1 ^ ^-1 if block ~ ~ ~ #wz_reception:remplacable run setblock ~ ~ ~ barrier
execute positioned ^1 ^ ^0 if block ~ ~ ~ #wz_reception:remplacable run setblock ~ ~ ~ barrier
execute positioned ^1 ^ ^1 if block ~ ~ ~ #wz_reception:remplacable run setblock ~ ~ ~ barrier
execute positioned ^1 ^ ^2 if block ~ ~ ~ #wz_reception:remplacable run setblock ~ ~ ~ barrier
