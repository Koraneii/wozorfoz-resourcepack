summon marker ~0.5 ~-2 ~0.5 {Tags:["wz_rec_lum","wz_rec_part"]}
execute unless score #lum wz_rec matches 0 if block ~ ~-2 ~ air run setblock ~ ~-2 ~ light[level=15]
