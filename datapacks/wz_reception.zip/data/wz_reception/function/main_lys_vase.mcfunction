advancement revoke @s only wz_reception:pose_lys_vase
scoreboard players set #ray wz_rec 0
execute anchored eyes positioned ^ ^ ^ run function wz_reception:rayon_lys_vase
