# Tourne d'un quart de tour l'objet le plus proche (3 blocs)
execute as @e[type=item_display,tag=wz_rec_obj,distance=..3,sort=nearest,limit=1] at @s run tp @s ~ ~ ~ ~90 0
