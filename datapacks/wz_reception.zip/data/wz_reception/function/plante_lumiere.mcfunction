execute if entity @s[tag=wz_rec_buis_medicis] run data remove entity @s brightness
execute if entity @s[tag=wz_rec_laurier_haut] run data remove entity @s brightness
execute if entity @s[tag=wz_rec_laurier_versailles] run data remove entity @s brightness
execute if entity @s[tag=wz_rec_lys_vase] run data remove entity @s brightness
execute if entity @s[tag=wz_rec_orchidee] run data remove entity @s brightness
