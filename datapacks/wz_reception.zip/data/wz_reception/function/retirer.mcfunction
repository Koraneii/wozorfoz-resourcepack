# Retire l'objet le plus proche (4 blocs) avec son bloc barrière et sa lumière
execute as @e[type=item_display,tag=wz_rec_obj,distance=..4,sort=nearest,limit=1] at @s run function wz_reception:retirer_ici
