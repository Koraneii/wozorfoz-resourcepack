execute as @e[type=item_display,tag=wz_rec_obj] run data remove entity @s brightness
execute as @e[type=item_display,tag=wz_rec_tapis] run data remove entity @s brightness
execute as @e[type=item_display,tag=wz_rec_jupe] run data remove entity @s brightness
execute unless score #lum wz_rec matches 0 as @e[type=item_display,tag=wz_rec_applique_bougies] run data merge entity @s {brightness:{sky:15,block:15}}
execute unless score #lum wz_rec matches 0 as @e[type=item_display,tag=wz_rec_applique_cristal] run data merge entity @s {brightness:{sky:15,block:15}}
execute unless score #lum wz_rec matches 0 as @e[type=item_display,tag=wz_rec_applique_tulipes] run data merge entity @s {brightness:{sky:15,block:15}}
execute unless score #lum wz_rec matches 0 as @e[type=item_display,tag=wz_rec_lustre_cristal] run data merge entity @s {brightness:{sky:15,block:15}}
execute unless score #lum wz_rec matches 0 as @e[type=item_display,tag=wz_rec_lustre_tulipes] run data merge entity @s {brightness:{sky:15,block:15}}
