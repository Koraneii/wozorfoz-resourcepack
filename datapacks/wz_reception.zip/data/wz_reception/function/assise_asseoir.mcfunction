execute store success score #moi wz_rec on target if entity @s[tag=wz_rec_assis]
data remove entity @s interaction
execute unless score #moi wz_rec matches 1 run return 0
execute on passengers run return 0
ride @a[tag=wz_rec_assis,limit=1] mount @s
