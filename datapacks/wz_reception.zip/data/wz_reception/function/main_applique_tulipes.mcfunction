advancement revoke @s only wz_reception:pose_applique_tulipes
scoreboard players set #ray wz_rec 0
execute anchored eyes positioned ^ ^ ^ run function wz_reception:rayon_applique_tulipes
