advancement revoke @s only wz_reception:pose_portrait_fro
scoreboard players set #ray wz_rec 0
execute anchored eyes positioned ^ ^ ^ run function wz_reception:rayon_portrait_fro
