schedule function wz_reception:flammes_boucle 4t replace
execute if score #lum wz_rec matches 0 run return 0
execute as @e[type=item_display,tag=wz_rec_torchere] at @s run particle minecraft:flame ~ ~2.45 ~ 0.09 0.06 0.09 0.006 2
execute as @e[type=item_display,tag=wz_rec_torchere] at @s run particle minecraft:small_flame ~ ~2.6 ~ 0.12 0.08 0.12 0.01 1
execute if predicate {condition:"minecraft:random_chance",chance:0.15} as @e[type=item_display,tag=wz_rec_torchere] at @s run particle minecraft:smoke ~ ~2.95 ~ 0.05 0.05 0.05 0.01 1
execute if predicate {condition:"minecraft:random_chance",chance:0.06} as @e[type=item_display,tag=wz_rec_torchere] at @s run playsound minecraft:block.fire.ambient block @a[distance=..8] ~ ~2.5 ~ 0.25 1
