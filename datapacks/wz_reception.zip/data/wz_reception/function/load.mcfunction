scoreboard objectives add wz_rec dummy
# les objets prennent la lumière de la salle ; seuls lustres et appliques brillent, quand ils sont allumés
function wz_reception:lumiere_maj
