scoreboard objectives add wz_rec dummy
# les plantes prennent la lumière de la salle (pas de luminosité imposée)
execute as @e[type=item_display,tag=wz_rec_obj] run function wz_reception:plante_lumiere
