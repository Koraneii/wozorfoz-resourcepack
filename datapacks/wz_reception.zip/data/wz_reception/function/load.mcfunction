scoreboard objectives add wz_rec dummy
