scoreboard objectives add wz_rec dummy
# les objets prennent la lumière de la salle ; seuls lustres et appliques brillent, quand ils sont allumés
function wz_reception:lumiere_maj
# torchères posées avant leur branchement sur la scène : leur lumière n'obéit plus aux lustres
execute as @e[type=item_display,tag=wz_rec_torchere] at @s positioned ~ ~2 ~ run tag @e[type=marker,tag=wz_rec_lum_app,distance=..0.6] add wz_rec_lum_torch
tag @e[type=marker,tag=wz_rec_lum_torch] remove wz_rec_lum_app
tag @e[type=marker,tag=wz_rec_lum_torch] remove wz_rec_lum
scoreboard players set #torch wz_rec -1
schedule function wz_reception:flammes_boucle 4t replace
