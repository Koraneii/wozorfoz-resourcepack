execute unless block ~ ~ ~ #wz_reception:remplacable align xyz positioned ~0.5 ~0.5 ~0.5 run return run function wz_reception:jupe_depart
scoreboard players add #ray wz_rec 1
execute if score #ray wz_rec matches ..120 positioned ^ ^ ^0.05 run function wz_reception:jupe_rayon
