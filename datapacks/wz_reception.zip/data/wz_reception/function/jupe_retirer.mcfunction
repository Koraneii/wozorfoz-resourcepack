kill @e[type=item_display,tag=wz_rec_jupe,distance=..24]
tellraw @s {"text":"Jupe du buffet retirée.","color":"gold"}
