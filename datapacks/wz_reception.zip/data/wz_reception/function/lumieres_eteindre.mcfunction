scoreboard players set #lum wz_rec 0
execute as @e[type=marker,tag=wz_rec_lum] at @s if block ~ ~ ~ light run setblock ~ ~ ~ air
tellraw @s {"text":"Lustres et appliques éteints.","color":"gold"}
