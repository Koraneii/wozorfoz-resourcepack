execute if block ~ ~ ~ barrier align xyz unless entity @e[type=item_display,tag=wz_rec_obj,dx=0,dy=0,dz=0] run return run function wz_reception:habiller_lustre_cristal
scoreboard players add #ray wz_rec 1
execute if score #ray wz_rec matches ..140 positioned ^ ^ ^0.05 run function wz_reception:rayon_lustre_cristal
