advancement revoke @s only wz_reception:pose_piano_queue
scoreboard players set #ray wz_rec 0
execute anchored eyes positioned ^ ^ ^ run function wz_reception:rayon_piano_queue
