summon marker ~0.5 ~-3 ~0.5 {Tags:["wz_rec_lum","wz_rec_part"]}
execute unless score #lum wz_rec matches 0 if block ~ ~-3 ~ air run setblock ~ ~-3 ~ light[level=15]
