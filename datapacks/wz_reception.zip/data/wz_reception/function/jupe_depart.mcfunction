function wz_reception:jupe_ici
scoreboard players set #pas wz_rec 0
execute if blocks ~ ~ ~ ~ ~ ~ ~1 ~ ~ all positioned ~1 ~ ~ run function wz_reception:jupe_px
scoreboard players set #pas wz_rec 0
execute if blocks ~ ~ ~ ~ ~ ~ ~-1 ~ ~ all positioned ~-1 ~ ~ run function wz_reception:jupe_nx
scoreboard players set #pas wz_rec 0
execute if blocks ~ ~ ~ ~ ~ ~ ~ ~ ~1 all positioned ~ ~ ~1 run function wz_reception:jupe_pz
scoreboard players set #pas wz_rec 0
execute if blocks ~ ~ ~ ~ ~ ~ ~ ~ ~-1 all positioned ~ ~ ~-1 run function wz_reception:jupe_nz
tellraw @s {"text":"Jupe posée sur la table du buffet. Pour l'enlever : /function wz_reception:jupe_retirer","color":"gold"}
