summon marker ~0.5 ~0.5 ~0.5 {Tags:["wz_rec_lum","wz_rec_lum_app","wz_rec_part"]}
execute unless score #lum wz_rec matches 0 if block ~ ~ ~ air run setblock ~ ~ ~ light[level=13]
