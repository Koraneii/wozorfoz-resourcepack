give @s barrier[item_model="wozorfoz:tireuse",item_name={text:"Tireuse à bière",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:bouteilles",item_name={text:"Rangée de bouteilles",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:verres_suspendus",item_name={text:"Verres suspendus",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:tabouret",item_name={text:"Tabouret de bar",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:comptoir",item_name={text:"Élément de comptoir",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:buffet",item_name={text:"Buffet d'arrière-bar",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:miroir",item_name={text:"Miroir d'arrière-bar",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:corniche",item_name={text:"Corniche d'arrière-bar",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:susp_globe",item_name={text:"Suspension globe ambré",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:susp_abat_jour",item_name={text:"Suspension abat-jour vert",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:susp_abat_jour_long",item_name={text:"Abat-jour vert (tige longue, sous un caisson)",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:susp_lustre",item_name={text:"Lustre à quatre tulipes",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:etagere_murale",item_name={text:"Étagère murale garnie",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:horloge",item_name={text:"Horloge murale",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:plafond",item_name={text:"Caisson de plafond",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:plafond_bordure",item_name={text:"Caisson de plafond (bordure)",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:fauteuil",item_name={text:"Fauteuil club",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:table_basse",item_name={text:"Guéridon",color:"gold"}] 16
tellraw @s {"text":"Tabouret et fauteuil : clic droit pour s'asseoir, accroupi pour se lever. Tireuse : sur le comptoir. Bouteilles : sur une étagère. Verres et suspensions : sous une poutre ou un plafond. Arrière-bar : contre le mur, buffet en bas, miroir juste au-dessus (il fait 2 blocs de haut), corniche 2 blocs au-dessus du miroir. Tapis : /function wz_bar:tapis_poser. Plafond : caissons au plafond, la bordure côté salle (posée depuis la salle). Horloge : contre le mur, elle fait 2 blocs de diamètre. Mal tourné : /function wz_bar:tourner","color":"gold"}
