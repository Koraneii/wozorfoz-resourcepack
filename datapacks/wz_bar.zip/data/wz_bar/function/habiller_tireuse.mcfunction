# (au coin du bloc barriere) ajoute le modele tireuse, tourne vers le joueur
execute if entity @s[y_rotation=-45..45] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_bar_obj","wz_bar_tireuse"],Rotation:[180f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:tireuse"}}}
execute if entity @s[y_rotation=45..135] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_bar_obj","wz_bar_tireuse"],Rotation:[-90f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:tireuse"}}}
execute if entity @s[y_rotation=135..180] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_bar_obj","wz_bar_tireuse"],Rotation:[0f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:tireuse"}}}
execute if entity @s[y_rotation=-180..-135] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_bar_obj","wz_bar_tireuse"],Rotation:[0f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:tireuse"}}}
execute if entity @s[y_rotation=-135..-45] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_bar_obj","wz_bar_tireuse"],Rotation:[90f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:tireuse"}}}
summon interaction ~0.5 ~-0.05 ~0.5 {width:1.1f,height:1.1f,response:1b,Tags:["wz_bar_clic","wz_bar_part"]}
tellraw @s {"text":"Tireuse posée : un clic droit sert une bière pression.","color":"gold"}
