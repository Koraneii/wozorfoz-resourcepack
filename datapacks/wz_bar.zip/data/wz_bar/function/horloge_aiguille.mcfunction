$execute if score #sens_horloge wz_bar matches 1 run return run function wz_bar:horloge/a_p_$(k)
$function wz_bar:horloge/a_n_$(k)
