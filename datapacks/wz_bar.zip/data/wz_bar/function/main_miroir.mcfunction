# (en tant que le joueur qui vient de poser l'objet) retrouve le bloc pose sous son regard et l'habille
advancement revoke @s only wz_bar:pose_miroir
scoreboard players set #ray wz_bar 0
execute anchored eyes positioned ^ ^ ^ run function wz_bar:rayon_miroir
