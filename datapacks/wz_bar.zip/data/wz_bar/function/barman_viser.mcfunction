# (contexte : tourne vers le client) angle de la tete par rapport au corps, limite a 70 degres
tp @e[type=marker,tag=wz_bar_viseur,limit=1] ~ ~ ~ ~ ~
execute store result score #ty wz_bar run data get entity @e[type=marker,tag=wz_bar_viseur,limit=1] Rotation[0]
execute store result score #by wz_bar run data get entity @s Rotation[0]
scoreboard players operation #ty wz_bar -= #by wz_bar
scoreboard players add #ty wz_bar 540
scoreboard players operation #ty wz_bar %= #360 wz_bar
scoreboard players remove #ty wz_bar 180
execute if score #ty wz_bar matches 71.. run scoreboard players set #ty wz_bar 70
execute if score #ty wz_bar matches ..-71 run scoreboard players set #ty wz_bar -70
scoreboard players operation #ty wz_bar *= #sens wz_bar
scoreboard players set #cible wz_bar 1
