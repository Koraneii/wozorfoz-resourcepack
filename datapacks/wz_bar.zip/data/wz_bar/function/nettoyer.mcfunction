# Retire les objets dont le bloc barriere a ete casse a la main
execute as @e[type=item_display,tag=wz_bar_obj] at @s unless block ~ ~-0.5 ~ barrier run kill @s
execute as @e[type=interaction,tag=wz_bar_part] at @s unless block ~ ~0.1 ~ barrier run kill @s
execute as @e[type=item_display,tag=wz_bar_part] at @s unless entity @e[type=item_display,tag=wz_bar_obj,distance=..0.1] run kill @s
execute as @e[type=marker,tag=wz_bar_lum] at @s unless block ~ ~1 ~ barrier run function wz_bar:lum_retirer
tellraw @s {"text":"Objets du bar orphelins nettoyés.","color":"gold"}
