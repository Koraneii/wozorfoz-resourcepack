# (chaque seconde) lit l'heure et place les aiguilles de toutes les horloges chargees
execute unless entity @e[type=item_display,tag=wz_horloge] run return run schedule function wz_bar:horloge_boucle 20t replace
execute if score #h wz_temps matches 0..23 run function wz_bar:horloge_heure_reelle
execute unless score #h wz_temps matches 0..23 run function wz_bar:horloge_heure_jeu
# aiguille des heures : un cran (6 degres) toutes les 12 minutes
scoreboard players operation #kh wz_bar = #h wz_bar
scoreboard players operation #kh wz_bar %= #douze wz_bar
scoreboard players operation #kh wz_bar *= #soixante wz_bar
scoreboard players operation #kh wz_bar += #m wz_bar
scoreboard players operation #kh wz_bar /= #douze wz_bar
execute store result storage wz_bar:h k int 1 run scoreboard players get #kh wz_bar
execute as @e[type=item_display,tag=wz_horloge_h] run function wz_bar:horloge_aiguille with storage wz_bar:h
execute store result storage wz_bar:h k int 1 run scoreboard players get #m wz_bar
execute as @e[type=item_display,tag=wz_horloge_m] run function wz_bar:horloge_aiguille with storage wz_bar:h
execute store result storage wz_bar:h k int 1 run scoreboard players get #s wz_bar
execute as @e[type=item_display,tag=wz_horloge_s] run function wz_bar:horloge_aiguille with storage wz_bar:h
schedule function wz_bar:horloge_boucle 20t replace
