# Si le barman tourne la tete du mauvais cote
scoreboard players operation #sens wz_bar *= #moins_un wz_bar
