data merge entity @s {Pose:{Body:[0f,0f,0f],RightArm:[-73.0f,-24.0f,0f],LeftArm:[-59.2f,22f,0f]}}
