data merge entity @s {Pose:{Body:[0f,0f,0f],RightArm:[-59.5f,-19.4f,0f],LeftArm:[-56.5f,22f,0f]}}
