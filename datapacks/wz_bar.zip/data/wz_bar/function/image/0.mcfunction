data merge entity @s {Pose:{Body:[0f,0f,0f],RightArm:[-66.0f,-12.0f,0f],LeftArm:[-57.2f,22f,0f]}}
