data merge entity @s {Pose:{Body:[0f,0f,0f],RightArm:[-59.5f,-28.6f,0f],LeftArm:[-57.2f,22f,0f]}}
