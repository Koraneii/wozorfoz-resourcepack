data merge entity @s {Pose:{Body:[0f,0f,0f],RightArm:[-61.1f,-32.5f,0f],LeftArm:[-57.7f,22f,0f]}}
