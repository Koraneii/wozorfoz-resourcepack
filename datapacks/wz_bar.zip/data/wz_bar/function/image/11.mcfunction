data merge entity @s {Pose:{Body:[0f,0f,0f],RightArm:[-72.5f,-28.6f,0f],LeftArm:[-59.5f,22f,0f]}}
