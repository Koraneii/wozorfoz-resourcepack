data merge entity @s {Pose:{Body:[0f,0f,0f],RightArm:[-70.9f,-32.5f,0f],LeftArm:[-59.5f,22f,0f]}}
