data merge entity @s {Pose:{Body:[0f,0f,0f],RightArm:[-72.5f,-19.4f,0f],LeftArm:[-58.8f,22f,0f]}}
