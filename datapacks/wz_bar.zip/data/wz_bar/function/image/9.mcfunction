data merge entity @s {Pose:{Body:[0f,0f,0f],RightArm:[-68.7f,-35.1f,0f],LeftArm:[-59.3f,22f,0f]}}
