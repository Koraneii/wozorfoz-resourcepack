data merge entity @s {Pose:{Body:[0f,0f,0f],RightArm:[-66.0f,-36.0f,0f],LeftArm:[-58.8f,22f,0f]}}
