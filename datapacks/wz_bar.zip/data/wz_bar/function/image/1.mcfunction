data merge entity @s {Pose:{Body:[0f,0f,0f],RightArm:[-63.3f,-12.9f,0f],LeftArm:[-56.7f,22f,0f]}}
