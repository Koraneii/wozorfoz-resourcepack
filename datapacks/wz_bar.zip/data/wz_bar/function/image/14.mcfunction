data merge entity @s {Pose:{Body:[0f,0f,0f],RightArm:[-70.9f,-15.5f,0f],LeftArm:[-58.3f,22f,0f]}}
