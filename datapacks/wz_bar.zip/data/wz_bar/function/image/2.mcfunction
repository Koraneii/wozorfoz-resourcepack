data merge entity @s {Pose:{Body:[0f,0f,0f],RightArm:[-61.1f,-15.5f,0f],LeftArm:[-56.5f,22f,0f]}}
