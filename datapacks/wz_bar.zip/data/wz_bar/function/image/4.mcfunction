data merge entity @s {Pose:{Body:[0f,0f,0f],RightArm:[-59.0f,-24.0f,0f],LeftArm:[-56.8f,22f,0f]}}
