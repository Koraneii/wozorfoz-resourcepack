data merge entity @s {Pose:{Body:[0f,0f,0f],RightArm:[-63.3f,-35.1f,0f],LeftArm:[-58.3f,22f,0f]}}
