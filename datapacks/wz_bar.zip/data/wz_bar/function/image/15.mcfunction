data merge entity @s {Pose:{Body:[0f,0f,0f],RightArm:[-68.7f,-12.9f,0f],LeftArm:[-57.7f,22f,0f]}}
