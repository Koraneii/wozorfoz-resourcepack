$function wz_bar:image/$(f)
