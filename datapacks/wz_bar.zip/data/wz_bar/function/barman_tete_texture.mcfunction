# Usage : /function wz_bar:barman_tete_texture {valeur:"eyJ0ZXh0dXJlcyI6..."}
# (la valeur « textures » d'une tete, en base64, par ex. copiee depuis minecraft-heads.com : champ Value)
$execute as @e[type=armor_stand,tag=wz_barman,sort=nearest,limit=1] run function wz_bar:barman_tete_texture_un {valeur:"$(valeur)"}
tellraw @s {"text":"Tête du barman changée.","color":"gold"}
