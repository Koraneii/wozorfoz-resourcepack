# (en tant que le siege clique) ne reagit qu'au joueur qui l'a clique
execute store success score #moi wz_bar on target if entity @s[tag=wz_bar_assis]
data remove entity @s interaction
execute unless score #moi wz_bar matches 1 run return 0
execute on passengers run return 0
ride @a[tag=wz_bar_assis,limit=1] mount @s
