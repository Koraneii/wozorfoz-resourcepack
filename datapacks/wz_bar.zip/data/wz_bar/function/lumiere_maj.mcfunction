# les objets du bar prennent la lumière de la pièce ; seules les suspensions brillent, quand elles sont allumées
execute as @e[type=item_display,tag=wz_bar_obj] run data remove entity @s brightness
execute as @e[type=item_display,tag=wz_bar_part] run data remove entity @s brightness
execute as @e[type=item_display,tag=wz_bar_tapis] run data remove entity @s brightness
execute unless score #lum wz_bar matches 0 as @e[type=item_display,tag=wz_bar_susp_globe] run data merge entity @s {brightness:{sky:15,block:15}}
execute unless score #lum wz_bar matches 0 as @e[type=item_display,tag=wz_bar_susp_abat_jour] run data merge entity @s {brightness:{sky:15,block:15}}
execute unless score #lum wz_bar matches 0 as @e[type=item_display,tag=wz_bar_susp_abat_jour_long] run data merge entity @s {brightness:{sky:15,block:15}}
execute unless score #lum wz_bar matches 0 as @e[type=item_display,tag=wz_bar_susp_lustre] run data merge entity @s {brightness:{sky:15,block:15}}
