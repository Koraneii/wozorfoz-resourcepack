execute as @e[type=item_display,tag=wz_bar_obj] at @s run function wz_bar:retirer_ici
tellraw @s {"text":"Tous les objets du bar sont retirés.","color":"gold"}
