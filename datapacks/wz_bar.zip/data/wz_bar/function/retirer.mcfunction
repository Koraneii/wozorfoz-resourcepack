# Retire l'objet du bar le plus proche (3 blocs), avec son bloc barriere
execute as @e[type=item_display,tag=wz_bar_obj,distance=..3,sort=nearest,limit=1] at @s run function wz_bar:retirer_ici
