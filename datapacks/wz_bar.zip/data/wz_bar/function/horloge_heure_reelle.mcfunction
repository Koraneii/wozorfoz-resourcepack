scoreboard players operation #h wz_bar = #h wz_temps
scoreboard players operation #m wz_bar = #m wz_temps
scoreboard players operation #s wz_bar = #s wz_temps
