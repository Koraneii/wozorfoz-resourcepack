# (en tant que le joueur qui vient de cliquer la tireuse)
advancement revoke @s only wz_bar:tireuse_clic
execute as @e[type=interaction,tag=wz_bar_clic,distance=..8] if data entity @s interaction run data remove entity @s interaction
give @s honey_bottle[item_name={text:"Bière pression",color:"gold"},item_model="wozorfoz:biere",lore=[{text:"Tirée au bar de l'Empire",color:"gray",italic:false},{text:"Buffet du Couronnement",color:"dark_red",italic:false}],food={nutrition:3,saturation:1.2f,can_always_eat:true}] 1
playsound minecraft:item.bottle.fill player @a ~ ~ ~ 0.7 0.75
playsound minecraft:block.bubble_column.upwards_ambient player @a ~ ~ ~ 0.4 1.6
