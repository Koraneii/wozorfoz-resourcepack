scoreboard objectives add wz_bar dummy
scoreboard objectives add wz_bar_f dummy
scoreboard objectives add wz_bar_h dummy
scoreboard objectives add wz_bar_p dummy
scoreboard players set #seize wz_bar 16
scoreboard players set #360 wz_bar 360
scoreboard players set #moins_un wz_bar -1
execute unless score #sens wz_bar matches -1..1 run scoreboard players set #sens wz_bar 1
schedule function wz_bar:boucle 20t replace
scoreboard objectives add wz_temps dummy
scoreboard players set #douze wz_bar 12
scoreboard players set #soixante wz_bar 60
scoreboard players set #mille wz_bar 1000
scoreboard players set #vingt_quatre wz_bar 24
execute unless score #sens_horloge wz_bar matches -1..1 run scoreboard players set #sens_horloge wz_bar -1
schedule function wz_bar:horloge_boucle 20t replace
