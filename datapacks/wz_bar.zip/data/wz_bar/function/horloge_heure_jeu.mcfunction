# heure du jeu : 0 = 6 h du matin, 1000 = une heure
execute store result score #t wz_bar run time query daytime
scoreboard players operation #h wz_bar = #t wz_bar
scoreboard players operation #h wz_bar /= #mille wz_bar
scoreboard players add #h wz_bar 6
scoreboard players operation #h wz_bar %= #vingt_quatre wz_bar
scoreboard players operation #m wz_bar = #t wz_bar
scoreboard players operation #m wz_bar %= #mille wz_bar
scoreboard players operation #m wz_bar *= #soixante wz_bar
scoreboard players operation #m wz_bar /= #mille wz_bar
scoreboard players set #s wz_bar 0
