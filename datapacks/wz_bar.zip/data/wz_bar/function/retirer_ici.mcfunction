execute if block ~ ~-0.5 ~ barrier run setblock ~ ~-0.5 ~ air
execute as @e[type=marker,tag=wz_bar_lum,distance=..1.1] at @s if block ~ ~ ~ light run setblock ~ ~ ~ air
kill @e[tag=wz_bar_part,distance=..1.1]
kill @s
