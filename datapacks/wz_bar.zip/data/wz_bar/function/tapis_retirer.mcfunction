kill @e[type=item_display,tag=wz_bar_tapis,distance=..4,sort=nearest,limit=1]
tellraw @s {"text":"Tapis retiré.","color":"gold"}
