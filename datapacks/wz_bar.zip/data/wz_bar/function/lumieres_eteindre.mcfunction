# Eteint les suspensions du bar
scoreboard players set #lum wz_bar 0
execute as @e[type=marker,tag=wz_bar_lum] at @s if block ~ ~ ~ light run setblock ~ ~ ~ air
tellraw @s {"text":"Suspensions du bar éteintes.","color":"gold"}
