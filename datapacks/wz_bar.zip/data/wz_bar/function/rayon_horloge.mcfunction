execute if block ~ ~ ~ barrier align xyz unless entity @e[type=item_display,tag=wz_bar_obj,dx=0,dy=0,dz=0] run return run function wz_bar:habiller_horloge
scoreboard players add #ray wz_bar 1
execute if score #ray wz_bar matches ..140 positioned ^ ^ ^0.05 run function wz_bar:rayon_horloge
