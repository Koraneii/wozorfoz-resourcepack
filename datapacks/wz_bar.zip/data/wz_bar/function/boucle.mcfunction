# (toutes les 2 ticks) anime les barmen
execute as @e[type=armor_stand,tag=wz_barman] at @s run function wz_bar:barman_anim
# barman charge : image suivante dans 2 ticks ; sinon (morceau de carte decharge, serveur qui redemarre)
# on reverifie chaque seconde, pour qu'il reprenne des que quelqu'un revient au bar
execute if entity @e[type=armor_stand,tag=wz_barman] run return run schedule function wz_bar:boucle 2t replace
schedule function wz_bar:boucle 20t replace
