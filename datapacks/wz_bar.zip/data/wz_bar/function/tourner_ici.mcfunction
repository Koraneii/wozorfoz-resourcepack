tp @s ~ ~ ~ ~90 0
execute if entity @s[tag=wz_horloge] as @e[type=item_display,tag=wz_bar_part,distance=..0.1] at @s run tp @s ~ ~ ~ ~90 0
