# Tourne d'un quart de tour l'objet du bar le plus proche (3 blocs), avec ses aiguilles si c'est l'horloge
execute as @e[type=item_display,tag=wz_bar_obj,distance=..3,sort=nearest,limit=1] at @s run function wz_bar:tourner_ici
