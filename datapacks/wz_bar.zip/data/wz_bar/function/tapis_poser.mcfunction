# Le tapis (4 x 6 blocs) se pose centre sur le bloc ou vous etes, dans le sens de votre regard ; on marche dessus
execute align xz positioned ~0.5 ~ ~0.5 run summon item_display ~ ~ ~ {Tags:["wz_bar_tapis","wz_bar_tapis_neuf"],item_display:"fixed",brightness:{sky:15,block:11},view_range:2f,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,1.02f,0f],scale:[2f,2f,2f]},item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:tapis"}}}
execute as @e[type=item_display,tag=wz_bar_tapis_neuf] at @s run function wz_bar:tapis_orienter
tag @e[type=item_display,tag=wz_bar_tapis_neuf] remove wz_bar_tapis_neuf
tellraw @s {"text":"Tapis posé. Pour le retirer : /function wz_bar:tapis_retirer (debout dessus).","color":"gold"}
