scoreboard players add @s wz_bar_f 1
scoreboard players operation @s wz_bar_f %= #seize wz_bar
execute store result storage wz_bar:a f int 1 run scoreboard players get @s wz_bar_f
function wz_bar:barman_image with storage wz_bar:a
# la tete : vers le client le plus proche (6 blocs), sinon penchee sur le verre
scoreboard players set #cible wz_bar 0
execute if entity @a[distance=..6,gamemode=!spectator] facing entity @p[distance=..6,gamemode=!spectator] eyes run function wz_bar:barman_viser
execute if score #cible wz_bar matches 0 run scoreboard players set #ty wz_bar 0
execute if score #cible wz_bar matches 0 run scoreboard players set #tp wz_bar 25
execute if score #cible wz_bar matches 1 run scoreboard players set #tp wz_bar 0
# rapproche doucement la tete de sa cible (12 degres par image au plus)
scoreboard players operation #d wz_bar = #ty wz_bar
scoreboard players operation #d wz_bar -= @s wz_bar_h
execute if score #d wz_bar matches 13.. run scoreboard players set #d wz_bar 12
execute if score #d wz_bar matches ..-13 run scoreboard players set #d wz_bar -12
scoreboard players operation @s wz_bar_h += #d wz_bar
scoreboard players operation #d wz_bar = #tp wz_bar
scoreboard players operation #d wz_bar -= @s wz_bar_p
execute if score #d wz_bar matches 6.. run scoreboard players set #d wz_bar 5
execute if score #d wz_bar matches ..-6 run scoreboard players set #d wz_bar -5
scoreboard players operation @s wz_bar_p += #d wz_bar
execute store result storage wz_bar:a hy int 1 run scoreboard players get @s wz_bar_h
execute store result storage wz_bar:a hp int 1 run scoreboard players get @s wz_bar_p
function wz_bar:barman_tete_pose with storage wz_bar:a
