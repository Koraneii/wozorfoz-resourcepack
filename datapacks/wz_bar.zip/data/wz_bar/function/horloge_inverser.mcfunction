# Si les aiguilles tournent a l'envers
scoreboard players operation #sens_horloge wz_bar *= #moins_un wz_bar
