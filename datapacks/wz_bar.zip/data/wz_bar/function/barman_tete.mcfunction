# Usage : /function wz_bar:barman_tete {joueur:"Pseudo"}  (le barman le plus proche porte la tete de ce joueur)
$execute as @e[type=armor_stand,tag=wz_barman,sort=nearest,limit=1] run function wz_bar:barman_tete_un {joueur:"$(joueur)"}
