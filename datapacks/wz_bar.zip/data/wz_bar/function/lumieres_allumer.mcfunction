scoreboard players set #lum wz_bar 1
execute as @e[type=marker,tag=wz_bar_lum] at @s if block ~ ~ ~ air run setblock ~ ~ ~ light[level=15]
tellraw @s {"text":"Suspensions du bar allumées.","color":"gold"}
