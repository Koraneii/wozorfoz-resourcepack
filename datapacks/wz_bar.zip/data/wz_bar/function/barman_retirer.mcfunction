kill @e[type=armor_stand,tag=wz_barman,distance=..5,sort=nearest,limit=1]
execute unless entity @e[type=armor_stand,tag=wz_barman] run kill @e[type=marker,tag=wz_bar_viseur]
tellraw @s {"text":"Barman retiré.","color":"gold"}
