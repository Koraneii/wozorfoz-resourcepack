$data merge entity @s {Pose:{Head:[$(hp)f,$(hy)f,0f]}}
