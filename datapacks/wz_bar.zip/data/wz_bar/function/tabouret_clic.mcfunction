# (en tant que le joueur qui vient de cliquer un tabouret) il s'assoit, si la place est libre
advancement revoke @s only wz_bar:tabouret_clic
tag @s add wz_bar_assis
execute as @e[type=interaction,tag=wz_bar_assise,distance=..8] if data entity @s interaction run function wz_bar:tabouret_asseoir
tag @s remove wz_bar_assis
