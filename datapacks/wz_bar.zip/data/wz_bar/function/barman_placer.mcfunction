# Le barman apparait a vos pieds, tourne dans la direction de votre regard (placez-vous derriere le comptoir, face a la salle)
summon armor_stand ~ ~ ~ {Tags:["wz_barman","wz_barman_neuf"],CustomName:{text:"Aldric Malaen",color:"gold"},CustomNameVisible:1b,ShowArms:1b,NoBasePlate:1b,Invulnerable:1b,DisabledSlots:4144959,equipment:{head:{id:"minecraft:player_head",count:1},chest:{id:"minecraft:leather_chestplate",count:1,components:{"minecraft:item_model":"wozorfoz:veste","minecraft:equippable":{slot:"chest",asset_id:"wozorfoz:choriste"}}},legs:{id:"minecraft:leather_leggings",count:1,components:{"minecraft:item_model":"wozorfoz:pantalon","minecraft:equippable":{slot:"legs",asset_id:"wozorfoz:musicien"}}},feet:{id:"minecraft:leather_boots",count:1,components:{"minecraft:item_model":"wozorfoz:bottes","minecraft:equippable":{slot:"feet",asset_id:"wozorfoz:musicien"}}},mainhand:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"wozorfoz:torchon"}},offhand:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"wozorfoz:verre_main"}}}}
tp @e[type=armor_stand,tag=wz_barman_neuf,limit=1] ~ ~ ~ ~ 0
scoreboard players set @e[type=armor_stand,tag=wz_barman_neuf] wz_bar_h 0
scoreboard players set @e[type=armor_stand,tag=wz_barman_neuf] wz_bar_p 25
execute store result score @e[type=armor_stand,tag=wz_barman_neuf,limit=1] wz_bar_f run random value 0..15
tag @e[type=armor_stand,tag=wz_barman_neuf] remove wz_barman_neuf
execute unless entity @e[type=marker,tag=wz_bar_viseur] run summon marker ~ ~ ~ {Tags:["wz_bar_viseur"]}
schedule function wz_bar:boucle 2t replace
tellraw @s {"text":"Aldric Malaen est derrière son comptoir.","color":"gold"}
