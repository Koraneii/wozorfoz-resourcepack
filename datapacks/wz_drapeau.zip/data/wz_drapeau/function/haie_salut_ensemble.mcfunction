# Tous les soldats saluent en meme temps
scoreboard players set @e[type=armor_stand,tag=wz_soldat] wz_haie_d 0
tag @e[type=armor_stand,tag=wz_soldat] add wz_salut_force
function wz_drapeau:haie_anim_demarrer
