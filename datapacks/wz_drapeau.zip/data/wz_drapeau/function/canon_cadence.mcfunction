# Usage : function wz_drapeau:canon_cadence {n:8}  -> n salves, une toutes les 3 s (tempo de la marche)
$scoreboard players set #cn wz_drapeau $(n)
function wz_drapeau:canon_cadence_pas
