function wz_drapeau:canon_salve
scoreboard players remove #cn wz_drapeau 1
execute if score #cn wz_drapeau matches 1.. run schedule function wz_drapeau:canon_cadence_pas 60t replace
