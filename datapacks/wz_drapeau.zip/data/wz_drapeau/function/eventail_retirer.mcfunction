kill @e[type=marker,tag=wz_eventail]
tellraw @s {"text":"Points de tir d'éventail retirés.","color":"gold"}
