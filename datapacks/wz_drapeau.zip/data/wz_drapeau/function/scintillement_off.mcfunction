scoreboard players set #scint wz_drapeau 0
tellraw @s {"text":"Scintillement desactive.","color":"gold"}
