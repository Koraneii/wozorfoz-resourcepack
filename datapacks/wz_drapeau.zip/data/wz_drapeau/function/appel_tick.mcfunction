# lumiere au-dessus de chaque personne appelee, ou qu'elle soit (sa place, l'allee, l'escalier...)
execute as @a[tag=wz_appel,gamemode=!spectator] at @s positioned ~ ~1 ~ align xyz if block ~ ~ ~ air run function wz_drapeau:poursuite_poser
# arrivee sur la scene : la poursuite de scene prend le relais
$tag @a[tag=wz_appel,x=$(bx),y=$(by),z=$(bz),dx=$(dx),dy=$(dy),dz=$(dz)] remove wz_appel
