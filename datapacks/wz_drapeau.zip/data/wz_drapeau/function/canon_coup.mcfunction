# (a la position d'un canon) un coup de canon
particle flame ~ ~1.2 ~ 0.3 0.2 0.3 0.08 12 force
particle explosion ~ ~1.2 ~ 0.6 0.4 0.6 0 6 force
particle campfire_cosy_smoke ~ ~1 ~ 0.4 0.2 0.4 0.01 6 force
particle large_smoke ~ ~1 ~ 0.4 0.2 0.4 0.02 10 force
function wz_drapeau:canon_son with storage wz_drapeau:config
