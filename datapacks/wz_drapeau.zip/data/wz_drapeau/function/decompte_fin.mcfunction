bossbar set wz_drapeau:decompte name {"text":"La cérémonie commence","color":"gold","bold":true}
bossbar set wz_drapeau:decompte color yellow
bossbar set wz_drapeau:decompte value 0
schedule function wz_drapeau:decompte_stop 100t replace
