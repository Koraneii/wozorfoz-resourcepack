kill @e[type=item_display,tag=wz_lutrin,distance=..6,sort=nearest,limit=1]
tellraw @s {"text":"Habillage du lutrin retiré.","color":"gold"}
