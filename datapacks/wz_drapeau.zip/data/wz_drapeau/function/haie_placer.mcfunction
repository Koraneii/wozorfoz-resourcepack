# Usage : /function wz_drapeau:haie_placer {n:6}
# Debout au debut de l'allee, en regardant vers l'estrade : pose n paires de soldats face a face,
# a 3 blocs de part et d'autre de vous, un tous les 3 blocs (n = 1 a 12).
$scoreboard players set #hn wz_drapeau $(n)
execute rotated ~ 0 run function wz_drapeau:haie_poser
$tellraw @s {"text":"Haie d'honneur de $(n) paires placee.","color":"gold"}
