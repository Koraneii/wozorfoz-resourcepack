# Retire toutes les sentinelles et tous les guides (la haie d'honneur reste)
execute as @e[type=armor_stand,tag=wz_sentinelle] at @s run function wz_drapeau:sentinelle_retirer_ici
tellraw @s {"text":"Sentinelles et guides retirés.","color":"gold"}
