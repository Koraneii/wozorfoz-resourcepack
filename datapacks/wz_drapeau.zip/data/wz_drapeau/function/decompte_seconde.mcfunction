# (programme, chaque seconde) met la barre a jour pour tous les joueurs connectes
bossbar set wz_drapeau:decompte players @a
execute store result bossbar wz_drapeau:decompte value run scoreboard players get #dsec wz_drapeau
scoreboard players operation #dmin wz_drapeau = #dsec wz_drapeau
scoreboard players add #dmin wz_drapeau 59
scoreboard players operation #dmin wz_drapeau /= #soixante wz_drapeau
execute if score #dsec wz_drapeau matches 60.. run bossbar set wz_drapeau:decompte name ["",{"text":"Couronnement du Co-Consul — début dans ","color":"gold"},{"score":{"name":"#dmin","objective":"wz_drapeau"},"color":"yellow","bold":true},{"text":" min","color":"gold"}]
execute if score #dsec wz_drapeau matches 1..59 run bossbar set wz_drapeau:decompte name ["",{"text":"Couronnement du Co-Consul — début dans ","color":"gold"},{"score":{"name":"#dsec","objective":"wz_drapeau"},"color":"yellow","bold":true},{"text":" s","color":"gold"}]
execute if score #dsec wz_drapeau matches 1..59 run bossbar set wz_drapeau:decompte color red
execute if score #dsec wz_drapeau matches 50 if score #dcar wz_drapeau matches 1 run function wz_drapeau:carillon
execute if score #dsec wz_drapeau matches ..0 run return run function wz_drapeau:decompte_fin
scoreboard players remove #dsec wz_drapeau 1
schedule function wz_drapeau:decompte_seconde 20t replace
