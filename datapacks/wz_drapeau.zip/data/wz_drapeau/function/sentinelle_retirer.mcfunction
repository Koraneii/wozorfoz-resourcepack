# Retire la sentinelle ou le guide le plus proche (à moins de 3 blocs)
execute as @e[type=armor_stand,tag=wz_sentinelle,distance=..3,sort=nearest,limit=1] at @s run function wz_drapeau:sentinelle_retirer_ici
