$execute as @e[type=marker,tag=wz_lum] at @s if block ~ ~ ~ #wz_drapeau:remplacable run setblock ~ ~ ~ light[level=$(n)]
