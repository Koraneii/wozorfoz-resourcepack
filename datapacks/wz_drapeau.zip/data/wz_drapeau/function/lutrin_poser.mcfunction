# (au coin du lutrin vise) remplace un eventuel habillage, puis oriente le modele comme le lutrin
scoreboard players set #rtrouve wz_drapeau 1
kill @e[type=item_display,tag=wz_lutrin,dx=0,dy=0,dz=0]
execute if block ~ ~ ~ lectern[facing=north] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_lutrin"],Rotation:[0f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:lutrin"}}}
execute if block ~ ~ ~ lectern[facing=east] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_lutrin"],Rotation:[90f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:lutrin"}}}
execute if block ~ ~ ~ lectern[facing=south] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_lutrin"],Rotation:[180f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:lutrin"}}}
execute if block ~ ~ ~ lectern[facing=west] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_lutrin"],Rotation:[-90f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:lutrin"}}}
tellraw @a[distance=..8] {"text":"Lutrin de discours habillé. S'il est tourné à l'envers : /function wz_drapeau:lutrin_tourner","color":"gold"}
