# (en tant que sentinelle ou guide) uniforme complet de la Garde, comme la haie ; le guide garde sa lanterne
function wz_drapeau:haie_uniforme_soldat
data merge entity @s[tag=wz_guide] {DisabledSlots:0}
item replace entity @s[tag=wz_guide] weapon.offhand from entity @s weapon.mainhand
item replace entity @s[tag=wz_guide] weapon.mainhand with lantern
data merge entity @s[tag=wz_guide] {DisabledSlots:4144959}
