$data modify storage wz_drapeau:tmp a set from storage wz_drapeau:heraut invites[$(n)]
