# Debout au centre de l'entree : place le point d'annonce (detection a 3 blocs) et active le heraut
kill @e[type=marker,tag=wz_entree]
summon marker ~ ~ ~ {Tags:["wz_entree"]}
scoreboard players set #heraut wz_drapeau 1
schedule function wz_drapeau:boucle_rapide 2t replace
tellraw @s {"text":"Héraut placé à l'entrée et activé.","color":"gold"}
