summon item ~ ~0.3 ~ {Item:{id:"minecraft:stone",count:1},PickupDelay:40,Tags:["wz_depot"]}
$item replace entity @e[type=item,tag=wz_depot,limit=1,sort=nearest] contents from entity @s $(slot)
tag @e[type=item,tag=wz_depot] remove wz_depot
