playsound minecraft:block.note_block.bell master @a ~ ~ ~ 2 0.7
