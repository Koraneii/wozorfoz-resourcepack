scoreboard players set #lucioles wz_drapeau 1
schedule function wz_drapeau:lucioles_boucle 1t replace
tellraw @s {"text":"Lucioles allumées.","color":"gold"}
