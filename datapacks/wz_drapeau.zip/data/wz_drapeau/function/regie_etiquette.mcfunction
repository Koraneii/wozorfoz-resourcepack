# Usage : regardez une regie (bloc de commande) a moins de 6 blocs, puis :
#   /function wz_drapeau:regie_etiquette {texte:"T19 - Drapeau final (100,1 s)"}
$data modify storage wz_drapeau:regie texte set value "$(texte)"
scoreboard players set #rmode wz_drapeau 1
function wz_drapeau:regie_viser
