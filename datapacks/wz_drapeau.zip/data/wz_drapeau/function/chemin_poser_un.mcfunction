execute positioned ~ ~1 ~ if block ~ ~ ~ air run setblock ~ ~ ~ light[level=12]
particle minecraft:end_rod ~ ~0.4 ~ 0.25 0.1 0.25 0.015 10
playsound minecraft:block.amethyst_block.chime master @a[distance=..24] ~ ~ ~ 0.5 1.4
