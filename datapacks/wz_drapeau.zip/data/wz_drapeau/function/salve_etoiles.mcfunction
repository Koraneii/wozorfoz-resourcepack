execute as @e[type=marker,tag=wz_tir,sort=random,limit=3] at @s run function wz_drapeau:tir_etoile
