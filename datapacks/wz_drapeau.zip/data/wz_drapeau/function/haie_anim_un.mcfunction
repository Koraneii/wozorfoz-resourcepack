# --- le bras : vers le salut si le soldat voit quelqu'un (vigie) ou si le salut est ordonne, sinon vers le repos
tag @s remove wz_doit
execute if entity @s[tag=wz_voit] run tag @s add wz_doit
execute if entity @s[tag=wz_salut_force] unless score @s wz_haie_d matches 1.. run tag @s add wz_doit
execute if score @s wz_haie_d matches 1.. run scoreboard players remove @s wz_haie_d 1
scoreboard players operation @s wz_haie_p = @s wz_haie_f
execute unless score @s wz_haie_f matches 0.. run scoreboard players set @s wz_haie_f 0
execute if entity @s[tag=wz_doit] if score @s wz_haie_f matches ..4 run scoreboard players add @s wz_haie_f 1
execute if entity @s[tag=!wz_doit] if score @s wz_haie_f matches 1.. run scoreboard players remove @s wz_haie_f 1
execute unless score @s wz_haie_f = @s wz_haie_p run function wz_drapeau:haie_bras
execute if score @s wz_haie_f matches 5 unless score @s wz_haie_p matches 5 run playsound minecraft:item.armor.equip_iron neutral @a ~ ~ ~ 0.5 1.2
execute if score @s wz_haie_f matches 1.. run scoreboard players set #actif wz_drapeau 1
execute if entity @s[tag=wz_salut_force] run scoreboard players set #actif wz_drapeau 1
# --- la tete : suit la personne honoree (vigie, ou joueur marque wz_honneur pendant un salut)
scoreboard players set #cible wz_drapeau 0
execute if score #vigie wz_drapeau matches 1 if entity @a[distance=..10,gamemode=!spectator] facing entity @p[distance=..10,gamemode=!spectator] eyes run function wz_drapeau:haie_viser
execute if score #vigie wz_drapeau matches 2 if entity @a[distance=..10,tag=wz_honneur,gamemode=!spectator] facing entity @p[distance=..10,tag=wz_honneur,gamemode=!spectator] eyes run function wz_drapeau:haie_viser
execute if score #cible wz_drapeau matches 0 if score #vigie wz_drapeau matches 0 if entity @s[tag=wz_salut_force] if entity @a[distance=..12,tag=wz_honneur] facing entity @p[distance=..12,tag=wz_honneur] eyes run function wz_drapeau:haie_viser
execute if score #cible wz_drapeau matches 0 run scoreboard players set #ty wz_drapeau 0
execute unless score @s wz_haie_h matches -180..180 run scoreboard players set @s wz_haie_h 0
scoreboard players operation #dh wz_drapeau = #ty wz_drapeau
scoreboard players operation #dh wz_drapeau -= @s wz_haie_h
execute if score #dh wz_drapeau matches 9.. run scoreboard players set #dh wz_drapeau 9
execute if score #dh wz_drapeau matches ..-9 run scoreboard players set #dh wz_drapeau -9
execute unless score #dh wz_drapeau matches 0 run function wz_drapeau:haie_tourner
execute unless score @s wz_haie_h matches 0 run scoreboard players set #actif wz_drapeau 1
