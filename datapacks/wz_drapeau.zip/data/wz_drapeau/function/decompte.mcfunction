# Usage : /function wz_drapeau:decompte {minutes:30,carillon:1}
#   minutes  : temps restant avant le debut (lancer par ex. a 20 h 30 avec 30)
#   carillon : 1 = la volee de cloches part toute seule 50 s avant la fin et se tait a l heure ; 0 = non
$scoreboard players set #dsec wz_drapeau $(minutes)
scoreboard players operation #dsec wz_drapeau *= #soixante wz_drapeau
$scoreboard players set #dcar wz_drapeau $(carillon)
bossbar remove wz_drapeau:decompte
bossbar add wz_drapeau:decompte ""
bossbar set wz_drapeau:decompte color yellow
bossbar set wz_drapeau:decompte style notched_10
execute store result bossbar wz_drapeau:decompte max run scoreboard players get #dsec wz_drapeau
schedule function wz_drapeau:decompte_seconde 1t replace
$tellraw @s {"text":"Compte à rebours lancé : $(minutes) min.","color":"gold"}
