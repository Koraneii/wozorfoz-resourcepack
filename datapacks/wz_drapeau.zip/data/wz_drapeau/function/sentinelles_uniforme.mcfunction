# Rhabille toutes les sentinelles et tous les guides déjà posés avec l'uniforme complet de la Garde
execute as @e[type=armor_stand,tag=wz_sentinelle] run function wz_drapeau:sentinelle_habiller
tellraw @s {"text":"Sentinelles et guides en uniforme de la Garde.","color":"gold"}
