# Retire la barre (a la main : arrete aussi le compte a rebours en cours)
schedule clear wz_drapeau:decompte_seconde
bossbar remove wz_drapeau:decompte
function wz_drapeau:carillon_stop
