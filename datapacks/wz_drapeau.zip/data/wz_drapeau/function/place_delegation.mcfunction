# Usage : /function wz_drapeau:place_delegation {texte:"..."}   (Délégations étrangères)
# Debout sur la place : petite etiquette (moins d'un bloc de large, texte sur 2 lignes) au-dessus du siege.
$summon text_display ~ ~1.9 ~ {Tags:["wz_place"],billboard:"center",text:{text:"$(texte)",color:"#EC7C13",bold:false},background:1610612736,shadow:1b,line_width:80,alignment:"center",brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]}}
tellraw @s {"text":"Étiquette posée.","color":"gold"}
