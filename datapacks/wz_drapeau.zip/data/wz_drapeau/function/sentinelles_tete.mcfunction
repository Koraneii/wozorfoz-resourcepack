# Usage : /function wz_drapeau:sentinelles_tete {joueur:"NomDuJoueur"}
# Tête (skin) de ce joueur pour toutes les sentinelles et tous les guides du chemin (la haie garde la sienne)
$execute as @e[type=armor_stand,tag=wz_sentinelle] run item replace entity @s armor.head with player_head[profile={name:"$(joueur)"}]
$tellraw @s {"text":"Les sentinelles et les guides portent maintenant la tête de $(joueur).","color":"gold"}
