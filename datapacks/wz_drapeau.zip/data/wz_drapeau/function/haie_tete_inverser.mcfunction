# Si les soldats tournent la tete du mauvais cote, inverse le sens (a faire une seule fois)
scoreboard players operation #signe_tete wz_drapeau *= #moins_un wz_drapeau
tellraw @s {"text":"Sens du regard des soldats inversé.","color":"gold"}
