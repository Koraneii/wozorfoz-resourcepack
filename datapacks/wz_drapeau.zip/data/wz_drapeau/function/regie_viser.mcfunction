scoreboard players set #ray wz_drapeau 0
scoreboard players set #rtrouve wz_drapeau 0
execute anchored eyes positioned ^ ^ ^ run function wz_drapeau:regie_rayon
execute if score #rtrouve wz_drapeau matches 0 run tellraw @s {"text":"Aucune régie visée : regardez un bloc de commande à moins de 6 blocs.","color":"red"}
