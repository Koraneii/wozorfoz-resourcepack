kill @e[type=armor_stand,tag=wz_soldat]
tellraw @s {"text":"Haie d'honneur retiree.","color":"gold"}
