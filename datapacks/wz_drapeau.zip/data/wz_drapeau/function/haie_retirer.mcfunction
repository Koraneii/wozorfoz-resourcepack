kill @e[type=armor_stand,tag=wz_soldat,tag=!wz_sentinelle]
tellraw @s {"text":"Haie d'honneur retiree (les sentinelles du chemin restent : sentinelles_retirer).","color":"gold"}
