scoreboard players operation @s wz_haie_d = @s wz_haie_r
scoreboard players operation @s wz_haie_d *= #deux wz_drapeau
