$data merge entity @s {Pose:{Head:[$(t),$(h),0f]}}
