function wz_drapeau:arreter
function wz_drapeau:eteindre
kill @e[type=marker,tag=wz_drapeau]
kill @e[type=marker,tag=wz_sol]
tellraw @s {"text":"Repere du drapeau supprime.","color":"gold"}
