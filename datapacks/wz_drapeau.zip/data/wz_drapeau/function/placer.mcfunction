# A lancer par un joueur place parmi le public, en regardant vers l'endroit du ciel voulu.
# Le drapeau sera dessine 80 blocs devant lui, face au public, a 40 blocs de haut.
kill @e[type=marker,tag=wz_drapeau]
kill @e[type=marker,tag=wz_sol]
execute rotated ~ 0 positioned ^ ^ ^80 run summon marker ~ ~ ~ {Tags:["wz_sol"]}
execute rotated ~ 0 positioned ^ ^ ^80 run summon marker ~ ~40 ~ {Tags:["wz_drapeau"]}
execute rotated ~ 0 positioned ^ ^ ^80 run tp @e[type=marker,tag=wz_drapeau,limit=1,sort=nearest] ~ ~40 ~ ~ ~
tellraw @s {"text":"Repere du drapeau place (40 blocs de haut). Testez avec /function wz_drapeau:lancer","color":"gold"}
