# Les emplacements verrouilles (DisabledSlots) empechent Minecraft d'y placer une armure :
# on les deverrouille le temps de l'habillage, puis on les reverrouille.
data merge entity @s {DisabledSlots:0}
item replace entity @s armor.head with leather_helmet[item_model="wozorfoz:casque",equippable={slot:"head",asset_id:"wozorfoz:uniforme"},item_name={text:"Casque de la Garde",color:"dark_green"}]
item replace entity @s armor.chest with leather_chestplate[item_model="wozorfoz:veste",equippable={slot:"chest",asset_id:"wozorfoz:uniforme"},item_name={text:"Veste de la Garde",color:"dark_green"}]
item replace entity @s armor.legs with leather_leggings[item_model="wozorfoz:pantalon",equippable={slot:"legs",asset_id:"wozorfoz:uniforme"},item_name={text:"Pantalon de la Garde",color:"dark_green"}]
item replace entity @s armor.feet with leather_boots[item_model="wozorfoz:bottes",equippable={slot:"feet",asset_id:"wozorfoz:uniforme"},item_name={text:"Bottes de la Garde",color:"dark_green"}]
item replace entity @s weapon.mainhand with stick[item_model="wozorfoz:fusil",item_name={text:"Fusil de la Garde",color:"dark_green"},max_stack_size=1]
data merge entity @s {DisabledSlots:4144959}
