execute if block ~ ~ ~ #wz_drapeau:regie align xyz run return run function wz_drapeau:regie_poser
scoreboard players add #ray wz_drapeau 1
execute if score #ray wz_drapeau matches ..60 positioned ^ ^ ^0.1 run function wz_drapeau:regie_rayon
