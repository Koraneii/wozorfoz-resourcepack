# (au coin du bloc barriere trouve) ajoute le modele lanterne_murale, oriente en travers du regard du joueur
execute if entity @s[y_rotation=-45..45] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_barriere","wz_lanterne"],Rotation:[180f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:lanterne_murale"}},brightness:{sky:15,block:12}}
execute if entity @s[y_rotation=45..135] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_barriere","wz_lanterne"],Rotation:[270f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:lanterne_murale"}},brightness:{sky:15,block:12}}
execute if entity @s[y_rotation=135..180] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_barriere","wz_lanterne"],Rotation:[360f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:lanterne_murale"}},brightness:{sky:15,block:12}}
execute if entity @s[y_rotation=-180..-135] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_barriere","wz_lanterne"],Rotation:[360f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:lanterne_murale"}},brightness:{sky:15,block:12}}
execute if entity @s[y_rotation=-135..-45] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_barriere","wz_lanterne"],Rotation:[90f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:lanterne_murale"}},brightness:{sky:15,block:12}}
execute unless entity @e[type=marker,tag=wz_lum_neuf] if block ~ ~1 ~ #wz_drapeau:remplacable run summon marker ~0.5 ~1 ~0.5 {Tags:["wz_lum","wz_lum_neuf"]}
execute unless entity @e[type=marker,tag=wz_lum_neuf] if block ~ ~-1 ~ #wz_drapeau:remplacable run summon marker ~0.5 ~-1 ~0.5 {Tags:["wz_lum","wz_lum_neuf"]}
execute if score #lant wz_drapeau matches 1 as @e[type=marker,tag=wz_lum_neuf] at @s if block ~ ~ ~ air run setblock ~ ~ ~ light[level=15]
tag @e[type=marker,tag=wz_lum_neuf] remove wz_lum_neuf
execute if score #lant wz_drapeau matches 1 if score #vac wz_drapeau matches 1 run schedule function wz_drapeau:lanternes_boucle 4t replace
