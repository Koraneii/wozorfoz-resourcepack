# Annule tous les appels en cours (la personne n'est pas montee, erreur de nom...)
tag @a remove wz_appel
tellraw @s {"text":"Appels annulés.","color":"gold"}
