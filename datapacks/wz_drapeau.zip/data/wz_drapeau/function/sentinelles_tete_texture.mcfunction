# Usage : /function wz_drapeau:sentinelles_tete_texture {valeur:"eyJ0ZXh0dXJlcyI6..."}
# Tête personnalisée (champ « Value » des sites de têtes, ex. minecraft-heads.com) pour sentinelles et guides
$execute as @e[type=armor_stand,tag=wz_sentinelle] run item replace entity @s armor.head with player_head[profile={properties:[{name:"textures",value:"$(valeur)"}]}]
tellraw @s {"text":"Tête personnalisée appliquée aux sentinelles et aux guides.","color":"gold"}
