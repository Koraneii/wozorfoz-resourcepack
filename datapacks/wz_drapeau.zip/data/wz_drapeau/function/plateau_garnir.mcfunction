# Mets ou boisson en main (y compris un brassin BreweryX), regardez un plateau a moins de 6 blocs
execute unless items entity @s weapon.mainhand * run return run tellraw @s {"text":"Tenez en main ce que le plateau doit servir.","color":"red"}
scoreboard players set #ray wz_drapeau 0
scoreboard players set #garni wz_drapeau 0
tag @s add wz_garnit
execute anchored eyes positioned ^ ^ ^ run function wz_drapeau:plateau_rayon
tag @s remove wz_garnit
execute if score #garni wz_drapeau matches 0 run tellraw @s {"text":"Aucun plateau dans votre regard (6 blocs maximum).","color":"red"}
