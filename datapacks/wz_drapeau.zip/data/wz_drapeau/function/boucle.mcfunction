execute as @e[type=marker,tag=wz_drapeau] at @s run function wz_drapeau:dessin
scoreboard players operation #grp wz_drapeau = #timer wz_drapeau
scoreboard players operation #grp wz_drapeau %= #huit wz_drapeau
execute if score #scint wz_drapeau matches 1 as @e[type=marker,tag=wz_drapeau] at @s run function wz_drapeau:etincelles
scoreboard players add #timer wz_drapeau 1
execute if score #timer wz_drapeau < #max wz_drapeau run schedule function wz_drapeau:boucle 4t replace
execute if score #timer wz_drapeau >= #max wz_drapeau run schedule function wz_drapeau:eteindre 40t replace
