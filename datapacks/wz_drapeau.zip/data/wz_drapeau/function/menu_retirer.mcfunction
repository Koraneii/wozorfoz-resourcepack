kill @e[tag=wz_menu,distance=..3]
tellraw @s {"text":"Menu retiré.","color":"gold"}
