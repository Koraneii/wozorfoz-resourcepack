# Flamme fixe : la lumiere des lanternes ne bouge plus (pleine intensite)
scoreboard players set #vac wz_drapeau 0
schedule clear wz_drapeau:lanternes_boucle
execute as @e[type=marker,tag=wz_lum] at @s if block ~ ~ ~ light run setblock ~ ~ ~ light[level=15]
tellraw @s {"text":"Vacillement des lanternes arrêté.","color":"gold"}
