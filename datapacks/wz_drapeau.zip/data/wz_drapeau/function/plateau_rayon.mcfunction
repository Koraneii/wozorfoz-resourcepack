execute as @e[type=item_display,tag=wz_plat,distance=..0.6,limit=1,sort=nearest] run return run function wz_drapeau:plateau_garnir_ici
scoreboard players add #ray wz_drapeau 1
execute if score #ray wz_drapeau matches ..40 positioned ^ ^ ^0.15 run function wz_drapeau:plateau_rayon
