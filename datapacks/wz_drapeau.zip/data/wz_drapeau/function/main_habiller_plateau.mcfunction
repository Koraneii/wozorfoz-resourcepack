# (au coin du bloc barriere trouve) ajoute le modele plateau, oriente en travers du regard du joueur
execute if entity @s[y_rotation=-45..45] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_barriere"],Rotation:[0f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:plateau"}}}
execute if entity @s[y_rotation=45..135] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_barriere"],Rotation:[90f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:plateau"}}}
execute if entity @s[y_rotation=135..180] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_barriere"],Rotation:[180f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:plateau"}}}
execute if entity @s[y_rotation=-180..-135] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_barriere"],Rotation:[180f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:plateau"}}}
execute if entity @s[y_rotation=-135..-45] run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_barriere"],Rotation:[-90f,0f],item_display:"fixed",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:plateau"}}}
summon interaction ~0.5 ~-0.05 ~0.5 {width:1.1f,height:1.1f,response:1b,Tags:["wz_plateau","wz_plateau_part"]}
summon item_display ~0.5 ~0.37 ~0.5 {Tags:["wz_plat","wz_plateau_part","wz_plat_neuf"],item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.65f,0.65f,0.65f]}}
rotate @e[type=item_display,tag=wz_plat_neuf,limit=1] facing entity @s
data modify entity @e[type=item_display,tag=wz_plat_neuf,limit=1] Rotation[1] set value 0f
tag @e[type=item_display,tag=wz_plat_neuf] remove wz_plat_neuf
tellraw @s {"text":"Plateau posé. Mets en main, regardez-le : /function wz_drapeau:plateau_garnir","color":"gold"}
