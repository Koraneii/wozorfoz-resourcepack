# Coin 2 de la zone a eclairer (debout a ce coin, au plus haut niveau de la scene)
kill @e[type=marker,tag=wz_scene2]
summon marker ~ ~ ~ {Tags:["wz_scene2"]}
tellraw @s {"text":"Coin 2 de la scène placé.","color":"gold"}
