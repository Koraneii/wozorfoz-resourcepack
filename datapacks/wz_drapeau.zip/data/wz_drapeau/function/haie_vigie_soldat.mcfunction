# (en tant que soldat) detecte un joueur proche selon le mode ; le mouvement est fait par haie_anim
tag @s remove wz_voit
execute if score #vigie wz_drapeau matches 1 if entity @a[distance=..5,gamemode=!spectator] run tag @s add wz_voit
execute if score #vigie wz_drapeau matches 2 if entity @a[distance=..5,tag=wz_honneur,gamemode=!spectator] run tag @s add wz_voit
