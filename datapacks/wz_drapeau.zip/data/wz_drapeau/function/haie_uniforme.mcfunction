# Habille et arme tous les soldats de la haie (uniforme et fusil du resource pack)
execute as @e[type=armor_stand,tag=wz_soldat] run function wz_drapeau:haie_uniforme_soldat
