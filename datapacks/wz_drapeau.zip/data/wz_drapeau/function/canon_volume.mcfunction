# Usage : /function wz_drapeau:canon_volume {v:2}
# 1 = discret (entendu jusqu'a ~16 blocs), 2 = defaut, 3 = fort, 5 = tres fort (porte a ~80 blocs)
$data modify storage wz_drapeau:config v set value $(v)
$tellraw @s {"text":"Volume des canons regle a $(v).","color":"gold"}
