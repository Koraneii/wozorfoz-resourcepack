# Bouffee de fumee rouge et orange qui monte, avec un peu de fumee grise (a la position courante)
particle entity_effect{color:[0.765,0.125,0.094,1.0]} ~ ~0.5 ~ 0.5 0.4 0.5 0.05 30 force
particle entity_effect{color:[0.925,0.486,0.075,1.0]} ~ ~0.5 ~ 0.5 0.4 0.5 0.05 30 force
particle campfire_cosy_smoke ~ ~0.3 ~ 0.4 0.1 0.4 0.01 6 force
