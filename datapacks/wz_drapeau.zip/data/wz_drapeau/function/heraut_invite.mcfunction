# Usage : /function wz_drapeau:heraut_invite {joueur:"Innovant",titre:"Son Excellence Innovant",delegation:"Délégation de FRT"}
$execute store result score $(joueur) wz_invite run data get storage wz_drapeau:heraut invites
$data modify storage wz_drapeau:heraut invites append value {titre:"$(titre)",delegation:"$(delegation)"}
$tellraw @s {"text":"Invité enregistré : $(joueur) -> $(titre) / $(delegation)","color":"gold"}
