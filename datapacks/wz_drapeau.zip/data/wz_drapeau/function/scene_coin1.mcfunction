# Coin 1 de la zone a eclairer (debout a ce coin, au sol)
kill @e[type=marker,tag=wz_scene1]
summon marker ~ ~ ~ {Tags:["wz_scene1"]}
tellraw @s {"text":"Coin 1 de la scène placé.","color":"gold"}
