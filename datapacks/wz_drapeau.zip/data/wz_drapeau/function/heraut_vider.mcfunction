# Efface la liste des invites
data remove storage wz_drapeau:heraut invites
scoreboard objectives remove wz_invite
scoreboard objectives add wz_invite dummy
tellraw @s {"text":"Liste des invités vidée.","color":"gold"}
