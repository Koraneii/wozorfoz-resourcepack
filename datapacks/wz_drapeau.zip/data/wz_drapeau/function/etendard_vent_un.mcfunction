# (en tant qu'un etendard) chacun recoit au hasard son propre decalage de rythme, une fois pour toutes
execute unless score @s wz_vent matches 0.. store result score @s wz_vent run random value 0..11
scoreboard players operation #k wz_drapeau = #vent wz_drapeau
scoreboard players operation #k wz_drapeau += @s wz_vent
scoreboard players operation #k wz_drapeau %= #douze wz_drapeau
execute store result storage wz_drapeau:vent k int 1 run scoreboard players get #k wz_drapeau
function wz_drapeau:etendard_vent_m with storage wz_drapeau:vent
