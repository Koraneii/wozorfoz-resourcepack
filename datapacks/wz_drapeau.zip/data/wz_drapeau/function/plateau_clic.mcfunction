# (en tant que le joueur qui vient de cliquer un plateau)
advancement revoke @s only wz_drapeau:plateau_clic
tag @s add wz_client
execute as @e[type=interaction,tag=wz_plateau,distance=..8] if data entity @s interaction at @s run function wz_drapeau:plateau_servir
tag @s remove wz_client
