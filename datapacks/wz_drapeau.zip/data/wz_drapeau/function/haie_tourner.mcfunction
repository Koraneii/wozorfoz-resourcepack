scoreboard players operation @s wz_haie_h += #dh wz_drapeau
execute store result storage wz_drapeau:haie h float 1 run scoreboard players get @s wz_haie_h
execute if score @s wz_haie_f matches 4.. run data modify storage wz_drapeau:haie t set value -4f
execute unless score @s wz_haie_f matches 4.. run data modify storage wz_drapeau:haie t set value 0f
function wz_drapeau:haie_tete_m with storage wz_drapeau:haie
