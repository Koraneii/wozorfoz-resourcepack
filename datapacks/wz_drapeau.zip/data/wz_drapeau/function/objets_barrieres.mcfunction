give @s barrier[item_model="wozorfoz:cordon",item_name={text:"Cordon d'honneur",color:"gold"}] 64
give @s barrier[item_model="wozorfoz:barriere",item_name={text:"Barrière de sécurité",color:"gold"}] 64
