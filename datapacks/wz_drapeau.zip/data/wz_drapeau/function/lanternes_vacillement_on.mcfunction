scoreboard players set #vac wz_drapeau 1
execute if score #lant wz_drapeau matches 1 run schedule function wz_drapeau:lanternes_boucle 4t replace
tellraw @s {"text":"Vacillement des lanternes relancé.","color":"gold"}
