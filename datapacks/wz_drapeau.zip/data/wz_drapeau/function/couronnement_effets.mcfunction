# Au moment ou la couronne est posee : cloche, scintillement d'or, la haie d'honneur leve l'epee
execute at @a[tag=wz_recoit,limit=1] run playsound wozorfoz:cloche.bourdon master @a ~ ~ ~ 4 1
execute at @a[tag=wz_recoit,limit=1] run particle minecraft:totem_of_undying ~ ~1.2 ~ 0.6 0.9 0.6 0.25 120
function wz_drapeau:haie_salut
