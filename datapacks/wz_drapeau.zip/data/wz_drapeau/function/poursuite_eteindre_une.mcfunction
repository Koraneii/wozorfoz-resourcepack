execute if block ~ ~ ~ light[level=15] run setblock ~ ~ ~ air
kill @s
