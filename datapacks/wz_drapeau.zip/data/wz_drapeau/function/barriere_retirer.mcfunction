# Retire l'element de barriere ou de cordon le plus proche (a moins de 3 blocs)
execute as @e[type=item_display,tag=wz_barriere,distance=..3,sort=nearest,limit=1] at @s run function wz_drapeau:barriere_retirer_ici
