give @s polished_blackstone[item_model="wozorfoz:pupitre",item_name={text:"Pupitre d'activation",color:"gold"}] 16
give @s polished_blackstone_button[item_name={text:"Bouton d'activation",color:"red"}] 16
