# cale la sentinelle sur le sol (un bloc plus haut ou plus bas si le terrain monte ou descend)
execute if block ~ ~ ~ #minecraft:replaceable unless block ~ ~-1 ~ #minecraft:replaceable run return run function wz_drapeau:sentinelle_chemin_poser_ici
execute unless block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable positioned ~ ~1 ~ run return run function wz_drapeau:sentinelle_chemin_poser_ici
execute if block ~ ~-1 ~ #minecraft:replaceable unless block ~ ~-2 ~ #minecraft:replaceable positioned ~ ~-1 ~ run return run function wz_drapeau:sentinelle_chemin_poser_ici
function wz_drapeau:sentinelle_chemin_poser_ici
