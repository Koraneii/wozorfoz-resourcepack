# (contexte : tourne vers la personne) angle de la tete par rapport au corps, limite a 60 degres
tp @e[type=marker,tag=wz_viseur,limit=1] ~ ~ ~ ~ ~
execute store result score #ty wz_drapeau run data get entity @e[type=marker,tag=wz_viseur,limit=1] Rotation[0]
execute store result score #by wz_drapeau run data get entity @s Rotation[0]
scoreboard players operation #ty wz_drapeau -= #by wz_drapeau
scoreboard players add #ty wz_drapeau 540
scoreboard players operation #ty wz_drapeau %= #trois_cent_soixante wz_drapeau
scoreboard players remove #ty wz_drapeau 180
execute if score #ty wz_drapeau matches 61.. run scoreboard players set #ty wz_drapeau 60
execute if score #ty wz_drapeau matches ..-61 run scoreboard players set #ty wz_drapeau -60
scoreboard players operation #ty wz_drapeau *= #signe_tete wz_drapeau
scoreboard players set #cible wz_drapeau 1
