particle firework ~ ~0.3 ~ 0.195 0.979 0.059 0.76 0 force
particle firework ~ ~0.3 ~ 0.141 0.964 0.224 0.70 0 force
particle firework ~ ~0.3 ~ -0.094 0.977 0.193 0.59 0 force
particle firework ~ ~0.3 ~ -0.158 0.986 0.055 0.78 0 force
particle firework ~ ~0.3 ~ -0.201 0.965 -0.166 0.63 0 force
particle firework ~ ~0.3 ~ 0.006 0.963 -0.271 0.77 0 force
particle firework ~ ~0.3 ~ 0.201 0.966 -0.159 0.65 0 force
particle small_flame ~ ~0.2 ~ 0.08 0.05 0.08 0.02 2 force
