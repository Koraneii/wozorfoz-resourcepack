execute at @e[type=marker,tag=wz_luciole] run particle minecraft:firefly ~ ~1.5 ~ 7 1.2 7 0 5
execute if score #lucioles wz_drapeau matches 1 run schedule function wz_drapeau:lucioles_boucle 10t replace
