function wz_drapeau:scene_coords
function wz_drapeau:scene_eteindre_zone with storage wz_drapeau:scene
scoreboard players set #fniv wz_drapeau 0
tellraw @s {"text":"Éclairage de la scène éteint.","color":"gold"}
