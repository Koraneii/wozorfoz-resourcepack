scoreboard players set #lucioles wz_drapeau 0
schedule clear wz_drapeau:lucioles_boucle
tellraw @s {"text":"Lucioles éteintes.","color":"gold"}
