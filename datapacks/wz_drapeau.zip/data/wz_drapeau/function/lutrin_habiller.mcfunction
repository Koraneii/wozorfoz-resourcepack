# Regardez le lutrin de la scene (a moins de 6 blocs) puis lancez cette fonction
scoreboard players set #ray wz_drapeau 0
scoreboard players set #rtrouve wz_drapeau 0
execute anchored eyes positioned ^ ^ ^ run function wz_drapeau:lutrin_rayon
execute if score #rtrouve wz_drapeau matches 0 run tellraw @s {"text":"Aucun lutrin visé : regardez un lutrin à moins de 6 blocs.","color":"red"}
