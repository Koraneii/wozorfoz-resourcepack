execute as @e[type=marker,tag=wz_tir] at @s run function wz_drapeau:bouquet_v3
