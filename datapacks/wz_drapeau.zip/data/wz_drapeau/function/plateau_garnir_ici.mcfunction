# (en tant que le mets du plateau) copie de l'objet tenu ; le joueur garde le sien
item replace entity @s contents from entity @a[tag=wz_garnit,limit=1] weapon.mainhand
data modify entity @s item.count set value 1
scoreboard players set #garni wz_drapeau 1
tellraw @a[tag=wz_garnit] {"text":"Plateau garni : un clic droit dessus en sert une portion.","color":"gold"}
