# Regardez une regie : affiche au-dessus la commande qu'elle contient
scoreboard players set #rmode wz_drapeau 0
function wz_drapeau:regie_viser
