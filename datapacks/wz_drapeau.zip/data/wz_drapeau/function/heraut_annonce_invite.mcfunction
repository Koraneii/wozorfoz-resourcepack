execute store result storage wz_drapeau:tmp n int 1 run scoreboard players get @s wz_invite
function wz_drapeau:heraut_charger with storage wz_drapeau:tmp
title @a[distance=..120] subtitle {"storage":"wz_drapeau:tmp","nbt":"a.delegation","color":"white"}
title @a[distance=..120] title {"storage":"wz_drapeau:tmp","nbt":"a.titre","color":"gold"}
tellraw @a[distance=..120] ["",{"text":"[Héraut] ","color":"gold"},{"storage":"wz_drapeau:tmp","nbt":"a.titre","color":"yellow"},{"text":" - ","color":"gray"},{"storage":"wz_drapeau:tmp","nbt":"a.delegation","color":"white"}]
