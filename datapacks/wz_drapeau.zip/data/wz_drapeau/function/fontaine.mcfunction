# Usage : function wz_drapeau:fontaine {s:16}  -> toutes les fontaines jaillissent pendant s secondes
$scoreboard players set #freste wz_drapeau $(s)
scoreboard players operation #freste wz_drapeau *= #vingt wz_drapeau
execute at @e[type=marker,tag=wz_fontaine] run playsound minecraft:entity.firework_rocket.launch block @a ~ ~ ~ 2 0.6
function wz_drapeau:fontaine_boucle
