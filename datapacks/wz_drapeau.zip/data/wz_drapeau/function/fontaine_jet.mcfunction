execute if score #fjet wz_drapeau matches 0 run function wz_drapeau:fontaine_jet_0
execute if score #fjet wz_drapeau matches 1 run function wz_drapeau:fontaine_jet_1
execute if score #fjet wz_drapeau matches 2 run function wz_drapeau:fontaine_jet_2
execute if score #fjet wz_drapeau matches 3 run function wz_drapeau:fontaine_jet_3
