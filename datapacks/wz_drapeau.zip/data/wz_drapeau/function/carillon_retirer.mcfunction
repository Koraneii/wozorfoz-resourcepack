kill @e[type=marker,tag=wz_cloche]
tellraw @s {"text":"Clocher retiré.","color":"gold"}
