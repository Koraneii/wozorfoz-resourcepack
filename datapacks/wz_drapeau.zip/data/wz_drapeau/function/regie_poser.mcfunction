# (au coin du bloc vise) remplace l'etiquette existante, puis en cree une nouvelle
scoreboard players set #rtrouve wz_drapeau 1
kill @e[type=text_display,tag=wz_regie_label,dx=0,dy=2,dz=0]
execute if block ~ ~ ~ command_block run summon text_display ~0.5 ~1.2 ~0.5 {Tags:["wz_regie_label","wz_regie_neuf"],billboard:"center",text:{text:"",color:"#FF9A1E"},background:1610612736,line_width:140,brightness:{sky:15,block:15},view_range:0.13f,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]}}
execute if block ~ ~ ~ chain_command_block run summon text_display ~0.5 ~1.2 ~0.5 {Tags:["wz_regie_label","wz_regie_neuf"],billboard:"center",text:{text:"",color:"#3CDC5A"},background:1610612736,line_width:140,brightness:{sky:15,block:15},view_range:0.13f,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]}}
execute if block ~ ~ ~ repeating_command_block run summon text_display ~0.5 ~1.2 ~0.5 {Tags:["wz_regie_label","wz_regie_neuf"],billboard:"center",text:{text:"",color:"#B05AFF"},background:1610612736,line_width:140,brightness:{sky:15,block:15},view_range:0.13f,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]}}
execute if score #rmode wz_drapeau matches 1 run data modify entity @e[type=text_display,tag=wz_regie_neuf,limit=1] text.text set from storage wz_drapeau:regie texte
execute if score #rmode wz_drapeau matches 0 run data modify entity @e[type=text_display,tag=wz_regie_neuf,limit=1] text.text set from block ~ ~ ~ Command
tag @e[type=text_display,tag=wz_regie_neuf] remove wz_regie_neuf
tellraw @a[distance=..8] {"text":"Étiquette de régie posée.","color":"gold"}
