# Les canons tirent l'un apres l'autre, 0,15 s d'ecart (roulement de batterie)
tag @e[type=marker,tag=wz_canon] remove wz_tire
function wz_drapeau:canon_roulement_pas
