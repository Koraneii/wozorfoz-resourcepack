scoreboard players set #heraut wz_drapeau 0
tellraw @s {"text":"Héraut désactivé.","color":"gold"}
