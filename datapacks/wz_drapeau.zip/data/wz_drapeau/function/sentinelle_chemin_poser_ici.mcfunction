summon armor_stand ~ ~ ~ {Tags:["wz_soldat","wz_sentinelle","wz_nouveau"],ShowArms:1b,NoBasePlate:1b,Invulnerable:1b,DisabledSlots:4144959,equipment:{head:{id:"minecraft:iron_helmet"},chest:{id:"minecraft:leather_chestplate",components:{"minecraft:dyed_color":12787736}},legs:{id:"minecraft:leather_leggings",components:{"minecraft:dyed_color":4925970}},feet:{id:"minecraft:leather_boots",components:{"minecraft:dyed_color":4925970}},mainhand:{id:"minecraft:iron_sword"}},Pose:{RightArm:[-75f,0f,0f],LeftArm:[0f,0f,-5f]}}
execute as @e[type=armor_stand,tag=wz_nouveau] at @s run tp @s ~ ~ ~ facing entity @e[type=marker,tag=wz_courant,limit=1] feet
execute as @e[type=armor_stand,tag=wz_nouveau] at @s run tp @s ~ ~ ~ ~ 0
execute as @e[type=armor_stand,tag=wz_nouveau] at @s run function wz_drapeau:sentinelle_finir
scoreboard players add #sposees wz_drapeau 1
