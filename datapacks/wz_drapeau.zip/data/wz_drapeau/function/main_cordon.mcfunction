# (en tant que le joueur qui vient de poser l'objet) retrouve le bloc pose sous son regard et l'habille
advancement revoke @s only wz_drapeau:pose_cordon
scoreboard players set #ray wz_drapeau 0
execute anchored eyes positioned ^ ^ ^ run function wz_drapeau:main_rayon_cordon
