$playsound minecraft:entity.generic.explode block @a ~ ~ ~ $(v) 0.55
