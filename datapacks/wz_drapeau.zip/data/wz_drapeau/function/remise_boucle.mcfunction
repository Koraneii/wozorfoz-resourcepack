scoreboard players enable @a wz_remise
execute as @a[scores={wz_remise=1}] at @s run function wz_drapeau:couronner
execute as @a[scores={wz_remise=2}] at @s run function wz_drapeau:remettre_sceptre
execute as @a[scores={wz_remise=3}] at @s run function wz_drapeau:remettre_sceau
scoreboard players set @a[scores={wz_remise=1..}] wz_remise 0
schedule function wz_drapeau:remise_boucle 5t replace
