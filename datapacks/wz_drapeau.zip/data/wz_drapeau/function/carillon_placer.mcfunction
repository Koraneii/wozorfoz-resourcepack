# Place le clocher a vos pieds (le son part de la ; il s'entend jusqu'a ~100 blocs)
kill @e[type=marker,tag=wz_cloche]
summon marker ~ ~ ~ {Tags:["wz_cloche"]}
tellraw @s {"text":"Clocher placé. Testez avec /function wz_drapeau:carillon","color":"gold"}
