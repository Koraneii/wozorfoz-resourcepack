function wz_drapeau:remettre {modele:"couronne",slot:"armor.head",nom:"la couronne"}
