# Usage (bloc de commande) : function wz_drapeau:lancer_duree {s:28}
# Lance le drapeau en reglant d'abord sa duree d'affichage, en secondes.
$scoreboard players set #max wz_drapeau $(s)
scoreboard players operation #max wz_drapeau *= #cinq wz_drapeau
function wz_drapeau:lancer
