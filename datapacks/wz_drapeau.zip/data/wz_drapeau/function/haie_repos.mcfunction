# Les soldats reposent l'arme (en douceur)
tag @e[type=armor_stand,tag=wz_soldat] remove wz_salut_force
function wz_drapeau:haie_anim_demarrer
