data merge entity @s {DisabledSlots:0}
