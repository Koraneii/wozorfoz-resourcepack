# Boucle autonome (toutes les 2 ticks) pour la poursuite et le heraut ; s'arrete quand les deux sont coupes
function wz_drapeau:tick
execute if score #spot wz_drapeau matches 1 run schedule function wz_drapeau:boucle_rapide 2t replace
execute if score #heraut wz_drapeau matches 1 run schedule function wz_drapeau:boucle_rapide 2t replace
