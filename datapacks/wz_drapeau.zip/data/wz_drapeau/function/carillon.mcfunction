# Carillon (50 s, silence au zero) a l'emplacement du clocher (carillon_placer) ; entendu a ~100 blocs
execute at @e[type=marker,tag=wz_cloche] run playsound wozorfoz:carillon.volee block @a ~ ~ ~ 6 1
