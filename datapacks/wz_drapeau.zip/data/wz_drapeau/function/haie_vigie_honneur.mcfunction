# Les soldats ne saluent que les joueurs marques : /tag <joueur> add wz_honneur
scoreboard players set #vigie wz_drapeau 2
function wz_drapeau:haie_vigie_boucle
function wz_drapeau:haie_anim_demarrer
tellraw @s {"text":"Vigie activee : les soldats saluent seulement les joueurs marques wz_honneur.","color":"gold"}
