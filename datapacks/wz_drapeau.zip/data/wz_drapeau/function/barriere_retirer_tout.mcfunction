execute as @e[type=item_display,tag=wz_barriere] at @s run function wz_drapeau:barriere_retirer_ici
tellraw @s {"text":"Toutes les barrières sont retirées.","color":"gold"}
