scoreboard players add #fjet wz_drapeau 1
execute if score #fjet wz_drapeau matches 4.. run scoreboard players set #fjet wz_drapeau 0
execute at @e[type=marker,tag=wz_fontaine] run function wz_drapeau:fontaine_jet
scoreboard players remove #freste wz_drapeau 1
execute if score #freste wz_drapeau matches 1.. run schedule function wz_drapeau:fontaine_boucle 1t replace
