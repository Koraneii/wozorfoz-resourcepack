# Retire l'etiquette de regie la plus proche (a moins de 4 blocs)
kill @e[type=text_display,tag=wz_regie_label,distance=..4,sort=nearest,limit=1]
