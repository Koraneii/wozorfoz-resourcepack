execute as @e[type=marker,tag=wz_fusee] at @s run function wz_drapeau:fusee_pas
execute if entity @e[type=marker,tag=wz_fusee] run schedule function wz_drapeau:montee 1t replace
execute unless entity @e[type=marker,tag=wz_fusee] run function wz_drapeau:apparition
