# Retire les modeles dont le bloc barriere a ete casse a la main
execute as @e[type=item_display,tag=wz_barriere] at @s unless block ~ ~-0.5 ~ barrier unless block ~ ~-0.5 ~ polished_blackstone run kill @s
execute as @e[tag=wz_plateau_part] at @s unless block ~ ~0.1 ~ barrier run kill @s
execute as @e[type=marker,tag=wz_lum] at @s unless entity @e[type=item_display,tag=wz_lanterne,distance=..3.6] run function wz_drapeau:lanterne_lum_retirer
tellraw @s {"text":"Barrières orphelines nettoyées.","color":"gold"}
