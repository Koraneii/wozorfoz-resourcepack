function wz_drapeau:fontaine_arreter
kill @e[type=marker,tag=wz_fontaine]
tellraw @s {"text":"Fontaines retirées.","color":"gold"}
