execute if block ~ ~ ~ lectern align xyz run return run function wz_drapeau:lutrin_poser
scoreboard players add #ray wz_drapeau 1
execute if score #ray wz_drapeau matches ..120 positioned ^ ^ ^0.05 run function wz_drapeau:lutrin_rayon
