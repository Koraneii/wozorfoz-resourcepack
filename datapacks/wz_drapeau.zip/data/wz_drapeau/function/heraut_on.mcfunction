scoreboard players set #heraut wz_drapeau 1
schedule function wz_drapeau:boucle_rapide 2t replace
tellraw @s {"text":"Héraut activé.","color":"gold"}
