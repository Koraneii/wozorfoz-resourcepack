# Retire l'etiquette (et la tete) la plus proche (placez-vous sur le siege concerne)
kill @e[type=text_display,tag=wz_place,distance=..2.5,sort=nearest,limit=1]
kill @e[type=item_display,tag=wz_place,distance=..2.5,sort=nearest,limit=1]
tellraw @s {"text":"Étiquette la plus proche retirée.","color":"gold"}
