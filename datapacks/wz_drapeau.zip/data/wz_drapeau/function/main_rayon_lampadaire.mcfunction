execute if block ~ ~ ~ barrier align xyz unless entity @e[type=item_display,tag=wz_barriere,dx=0,dy=0,dz=0] run return run function wz_drapeau:main_habiller_lampadaire
scoreboard players add #ray wz_drapeau 1
execute if score #ray wz_drapeau matches ..140 positioned ^ ^ ^0.05 run function wz_drapeau:main_rayon_lampadaire
