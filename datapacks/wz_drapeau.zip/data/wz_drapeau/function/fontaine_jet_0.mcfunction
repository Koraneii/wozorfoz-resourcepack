particle firework ~ ~0.3 ~ 0.109 0.994 -0.012 0.65 0 force
particle firework ~ ~0.3 ~ 0.064 0.996 0.063 0.65 0 force
particle firework ~ ~0.3 ~ -0.083 0.962 0.260 0.74 0 force
particle firework ~ ~0.3 ~ -0.096 0.994 0.045 0.62 0 force
particle firework ~ ~0.3 ~ -0.089 0.996 -0.031 0.60 0 force
particle firework ~ ~0.3 ~ -0.036 0.961 -0.273 0.75 0 force
particle firework ~ ~0.3 ~ 0.136 0.969 -0.204 0.63 0 force
particle small_flame ~ ~0.2 ~ 0.08 0.05 0.08 0.02 2 force
particle lava ~ ~0.3 ~ 0.05 0.05 0.05 0 1 force
playsound minecraft:block.fire.ambient block @a ~ ~ ~ 1.5 1.8
