execute store result storage wz_drapeau:scene x1 int 1 run data get entity @e[type=marker,tag=wz_scene1,limit=1] Pos[0]
execute store result storage wz_drapeau:scene y1 int 1 run data get entity @e[type=marker,tag=wz_scene1,limit=1] Pos[1]
execute store result storage wz_drapeau:scene z1 int 1 run data get entity @e[type=marker,tag=wz_scene1,limit=1] Pos[2]
execute store result storage wz_drapeau:scene x2 int 1 run data get entity @e[type=marker,tag=wz_scene2,limit=1] Pos[0]
execute store result score #sy wz_drapeau run data get entity @e[type=marker,tag=wz_scene2,limit=1] Pos[1]
execute store result storage wz_drapeau:scene y2b int 1 run scoreboard players get #sy wz_drapeau
scoreboard players add #sy wz_drapeau 3
execute store result storage wz_drapeau:scene y2 int 1 run scoreboard players get #sy wz_drapeau
execute store result storage wz_drapeau:scene z2 int 1 run data get entity @e[type=marker,tag=wz_scene2,limit=1] Pos[2]
execute store result score #lo wz_drapeau run data get storage wz_drapeau:scene x1
execute store result score #hi wz_drapeau run data get storage wz_drapeau:scene x2
scoreboard players operation #m wz_drapeau = #lo wz_drapeau
scoreboard players operation #m wz_drapeau < #hi wz_drapeau
execute store result storage wz_drapeau:scene bx int 1 run scoreboard players get #m wz_drapeau
scoreboard players operation #hi wz_drapeau -= #lo wz_drapeau
execute if score #hi wz_drapeau matches ..-1 run scoreboard players operation #hi wz_drapeau *= #moinsun wz_drapeau
execute store result storage wz_drapeau:scene dx int 1 run scoreboard players get #hi wz_drapeau
execute store result score #lo wz_drapeau run data get storage wz_drapeau:scene y1
execute store result score #hi wz_drapeau run data get storage wz_drapeau:scene y2
scoreboard players operation #m wz_drapeau = #lo wz_drapeau
scoreboard players operation #m wz_drapeau < #hi wz_drapeau
execute store result storage wz_drapeau:scene by int 1 run scoreboard players get #m wz_drapeau
scoreboard players operation #hi wz_drapeau -= #lo wz_drapeau
execute if score #hi wz_drapeau matches ..-1 run scoreboard players operation #hi wz_drapeau *= #moinsun wz_drapeau
execute store result storage wz_drapeau:scene dy int 1 run scoreboard players get #hi wz_drapeau
execute store result score #lo wz_drapeau run data get storage wz_drapeau:scene z1
execute store result score #hi wz_drapeau run data get storage wz_drapeau:scene z2
scoreboard players operation #m wz_drapeau = #lo wz_drapeau
scoreboard players operation #m wz_drapeau < #hi wz_drapeau
execute store result storage wz_drapeau:scene bz int 1 run scoreboard players get #m wz_drapeau
scoreboard players operation #hi wz_drapeau -= #lo wz_drapeau
execute if score #hi wz_drapeau matches ..-1 run scoreboard players operation #hi wz_drapeau *= #moinsun wz_drapeau
execute store result storage wz_drapeau:scene dz int 1 run scoreboard players get #hi wz_drapeau
