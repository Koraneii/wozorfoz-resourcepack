# Usage : /function wz_drapeau:duree {s:23}   (duree d'affichage du drapeau, en secondes)
$scoreboard players set #max wz_drapeau $(s)
scoreboard players operation #max wz_drapeau *= #cinq wz_drapeau
$tellraw @s {"text":"Le drapeau restera affiche $(s) secondes.","color":"gold"}
