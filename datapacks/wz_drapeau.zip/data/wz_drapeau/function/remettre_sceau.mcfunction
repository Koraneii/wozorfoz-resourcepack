function wz_drapeau:remettre {modele:"sceau",slot:"weapon.mainhand",nom:"le sceau"}
