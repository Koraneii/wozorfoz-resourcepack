schedule clear wz_drapeau:boucle
schedule clear wz_drapeau:montee
function wz_drapeau:eteindre
kill @e[type=marker,tag=wz_fusee]
scoreboard players set #timer wz_drapeau 100000
