execute as @e[type=marker,tag=wz_canon] at @s run function wz_drapeau:canon_coup
