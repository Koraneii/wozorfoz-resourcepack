# Permet d'annoncer de nouveau tout le monde (a lancer juste avant l'ouverture des portes)
tag @a remove wz_annonce
tellraw @s {"text":"Le héraut annoncera de nouveau chaque invité.","color":"gold"}
