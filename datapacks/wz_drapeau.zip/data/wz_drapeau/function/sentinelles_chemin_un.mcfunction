# point courant (#ck) et point voisin qui donne la direction du chemin (le suivant, ou le précédent en bout de chemin)
execute as @e[type=marker,tag=wz_chemin] if score @s wz_drapeau = #ck wz_drapeau run tag @s add wz_courant
scoreboard players operation #ck1 wz_drapeau = #ck wz_drapeau
scoreboard players add #ck1 wz_drapeau 1
execute as @e[type=marker,tag=wz_chemin] if score @s wz_drapeau = #ck1 wz_drapeau run tag @s add wz_cible
scoreboard players remove #ck1 wz_drapeau 2
execute unless entity @e[type=marker,tag=wz_cible] as @e[type=marker,tag=wz_chemin] if score @s wz_drapeau = #ck1 wz_drapeau run tag @s add wz_cible
execute at @e[type=marker,tag=wz_courant,limit=1] if entity @e[type=marker,tag=wz_cible] facing entity @e[type=marker,tag=wz_cible,limit=1] feet rotated ~ 0 run function wz_drapeau:sentinelle_chemin_poser
tag @e[type=marker,tag=wz_cible] remove wz_cible
tag @e[type=marker,tag=wz_courant] remove wz_courant
scoreboard players add #cote wz_drapeau 1
scoreboard players operation #cote wz_drapeau %= #deux wz_drapeau
