function wz_drapeau:canon_arreter
kill @e[type=marker,tag=wz_canon]
tellraw @s {"text":"Canons supprimes.","color":"gold"}
