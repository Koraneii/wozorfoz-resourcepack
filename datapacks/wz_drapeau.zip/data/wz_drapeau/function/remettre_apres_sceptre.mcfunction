playsound minecraft:block.amethyst_block.chime master @a ~ ~ ~ 2 0.8
