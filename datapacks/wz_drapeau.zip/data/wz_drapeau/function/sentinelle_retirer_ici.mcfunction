execute if entity @s[tag=wz_guide] if block ~ ~1 ~ light run setblock ~ ~1 ~ air
kill @s
