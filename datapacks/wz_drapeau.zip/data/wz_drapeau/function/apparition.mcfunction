scoreboard players set #timer wz_drapeau 0
schedule function wz_drapeau:boucle 6t replace
