# (en tant que le mets du plateau) une copie tombe aux pieds du joueur, ramassee aussitot, par lui seul
execute at @a[tag=wz_client,limit=1] run summon item ~ ~0.3 ~ {Item:{id:"minecraft:stone",count:1},PickupDelay:0,Tags:["wz_portion"]}
item replace entity @e[type=item,tag=wz_portion,limit=1] contents from entity @s contents
data modify entity @e[type=item,tag=wz_portion,limit=1] Owner set from entity @a[tag=wz_client,limit=1] UUID
tag @e[type=item,tag=wz_portion] remove wz_portion
execute at @a[tag=wz_client,limit=1] run playsound minecraft:item.bundle.insert player @a[tag=wz_client] ~ ~ ~ 0.8 1.1
