# Usage : /function wz_drapeau:haie_tete {joueur:"NomDuJoueur"}
# Remplace le casque de tous les soldats par la tete (le skin) de ce joueur Minecraft.
$execute as @e[type=armor_stand,tag=wz_soldat] run item replace entity @s armor.head with player_head[profile={name:"$(joueur)"}]
$tellraw @s {"text":"Les soldats portent maintenant la tete de $(joueur).","color":"gold"}
