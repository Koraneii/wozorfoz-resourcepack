# Remet le casque de la Garde (uniforme complet) aux sentinelles et aux guides
execute as @e[type=armor_stand,tag=wz_sentinelle] run function wz_drapeau:sentinelle_habiller
tellraw @s {"text":"Casques de la Garde remis.","color":"gold"}
