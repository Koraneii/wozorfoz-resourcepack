# Remet le casque de fer d'origine aux sentinelles et aux guides
execute as @e[type=armor_stand,tag=wz_sentinelle] run item replace entity @s armor.head with iron_helmet
tellraw @s {"text":"Casques remis.","color":"gold"}
