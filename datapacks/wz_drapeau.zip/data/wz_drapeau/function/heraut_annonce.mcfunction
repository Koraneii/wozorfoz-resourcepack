# (en tant que l'invite qui entre)
tag @s add wz_annonce
playsound minecraft:item.goat_horn.sound.1 player @a[distance=..120] ~ ~ ~ 4 1
title @a[distance=..120] times 10 70 20
execute if score @s wz_invite matches 0.. run function wz_drapeau:heraut_annonce_invite
execute unless score @s wz_invite matches 0.. run function wz_drapeau:heraut_annonce_simple
