# (programme) un cran vers le niveau vise, execute au coin de scene pour agir dans le bon monde
execute if score #fniv wz_drapeau = #fcible wz_drapeau run return 0
execute store result storage wz_drapeau:scene de int 1 run scoreboard players get #fniv wz_drapeau
execute if score #fniv wz_drapeau < #fcible wz_drapeau run scoreboard players add #fniv wz_drapeau 1
execute if score #fniv wz_drapeau > #fcible wz_drapeau run scoreboard players remove #fniv wz_drapeau 1
execute store result storage wz_drapeau:scene vers int 1 run scoreboard players get #fniv wz_drapeau
execute at @e[type=marker,tag=wz_scene1,limit=1] run function wz_drapeau:scene_fondu_cran with storage wz_drapeau:scene
execute unless score #fniv wz_drapeau = #fcible wz_drapeau run schedule function wz_drapeau:scene_fondu_pas 3t replace
