# Pour les etendards poses avant cette version : les marque pour qu'ils ondulent
execute as @e[type=item_display,tag=wz_barriere] if data entity @s {item:{components:{"minecraft:item_model":"wozorfoz:etendard"}}} run tag @s add wz_etendard
schedule function wz_drapeau:etendard_vent 2t replace
tellraw @s {"text":"Étendards existants marqués : ils ondulent désormais.","color":"gold"}
