# (toutes les 2 ticks) chaque soldat avance d'une image vers le salut ou vers le repos, et tourne la tete
scoreboard players set #actif wz_drapeau 0
execute as @e[type=armor_stand,tag=wz_soldat] at @s run function wz_drapeau:haie_anim_un
execute if score #vigie wz_drapeau matches 1.. run scoreboard players set #actif wz_drapeau 1
execute if score #actif wz_drapeau matches 1 run schedule function wz_drapeau:haie_anim 2t replace
execute if score #actif wz_drapeau matches 0 run scoreboard players set #haie_anim wz_drapeau 0
