# Feu intercalaire : un eventail de 3 cometes qui crepitent en or et blanc (~26 blocs), explosion 1,75 s apres le tir
execute as @e[type=marker,tag=wz_eventail,sort=random,limit=1] at @s run function wz_drapeau:tir_leger
