scoreboard players set #spot wz_drapeau 0
function wz_drapeau:poursuite_effacer
tellraw @s {"text":"Poursuite désactivée.","color":"gold"}
