# Toutes les 2 ticks, tant qu'il reste au moins un etendard pose : image suivante (0 a 11)
# aucun etendard charge (ex. demarrage du serveur, personne a proximite) : on reverifie chaque seconde au lieu de s'arreter
execute unless entity @e[type=item_display,tag=wz_etendard] run return run schedule function wz_drapeau:etendard_vent 20t replace
scoreboard players add #vent wz_drapeau 1
execute if score #vent wz_drapeau matches 12.. run scoreboard players set #vent wz_drapeau 0
execute as @e[type=item_display,tag=wz_etendard] run function wz_drapeau:etendard_vent_un
schedule function wz_drapeau:etendard_vent 2t replace
