execute unless entity @e[type=marker,tag=wz_viseur] at @e[type=armor_stand,tag=wz_soldat,limit=1] run summon marker ~ ~ ~ {Tags:["wz_viseur"]}
scoreboard players set #haie_anim wz_drapeau 1
schedule function wz_drapeau:haie_anim 1t replace
