summon marker ^0 ^-0 ^-1 {Tags:["wz_fusee","wz_orange"]}
summon marker ^-24 ^-5 ^-1 {Tags:["wz_fusee","wz_rouge"]}
summon marker ^24 ^-9 ^-1 {Tags:["wz_fusee","wz_rouge"]}
summon marker ^-44 ^-14 ^-1 {Tags:["wz_fusee","wz_orange"]}
summon marker ^44 ^-18 ^-1 {Tags:["wz_fusee","wz_orange"]}
playsound minecraft:entity.firework_rocket.launch ambient @a ~ ~ ~ 6 1
playsound minecraft:entity.firework_rocket.launch ambient @a ^-24 ^ ^ 6 0.9
playsound minecraft:entity.firework_rocket.launch ambient @a ^24 ^ ^ 6 1.1
execute positioned ^0 ^ ^-1 run function wz_drapeau:fumee_ici
execute positioned ^-24 ^ ^-1 run function wz_drapeau:fumee_ici
execute positioned ^24 ^ ^-1 run function wz_drapeau:fumee_ici
execute positioned ^-44 ^ ^-1 run function wz_drapeau:fumee_ici
execute positioned ^44 ^ ^-1 run function wz_drapeau:fumee_ici
