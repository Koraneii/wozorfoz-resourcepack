execute as @e[type=marker,tag=wz_drapeau] at @s run function wz_drapeau:eclairer_ici
