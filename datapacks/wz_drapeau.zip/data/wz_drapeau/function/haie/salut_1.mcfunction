data merge entity @s {Pose:{RightArm:[-92f,-10f,0f],LeftArm:[-18f,10f,-5f]}}
