data merge entity @s {Pose:{RightArm:[-120f,-15f,0f],LeftArm:[-26f,15f,-5f]}}
