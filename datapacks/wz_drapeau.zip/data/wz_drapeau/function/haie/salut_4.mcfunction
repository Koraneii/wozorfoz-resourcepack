data merge entity @s {Pose:{RightArm:[-166f,0f,0f],LeftArm:[-2f,0f,-5f]}}
