data merge entity @s {Pose:{RightArm:[-75f,0f,0f],LeftArm:[0f,0f,-5f]}}
