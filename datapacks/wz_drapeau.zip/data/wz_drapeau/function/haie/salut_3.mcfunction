data merge entity @s {Pose:{RightArm:[-148f,-8f,0f],LeftArm:[-12f,8f,-5f]}}
