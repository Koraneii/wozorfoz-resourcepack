# Usage : /function wz_drapeau:place_tete {joueur:"Innovant"}
# Ajoute la tete du joueur au-dessus de l'etiquette posee au meme endroit (places d'honneur).
$summon item_display ~ ~2.4 ~ {Tags:["wz_place"],billboard:"vertical",item_display:"head",item:{id:"minecraft:player_head",count:1,components:{"minecraft:profile":{name:"$(joueur)"}}},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}}
$tellraw @s {"text":"Tête de $(joueur) ajoutée.","color":"gold"}
