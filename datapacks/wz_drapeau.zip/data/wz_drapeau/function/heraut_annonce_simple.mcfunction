title @a[distance=..120] subtitle {"text":"est accueilli à la cérémonie","color":"white"}
title @a[distance=..120] title {"selector":"@s","color":"gold"}
tellraw @a[distance=..120] ["",{"text":"[Héraut] ","color":"gold"},{"selector":"@s","color":"yellow"},{"text":" est accueilli à la cérémonie.","color":"white"}]
