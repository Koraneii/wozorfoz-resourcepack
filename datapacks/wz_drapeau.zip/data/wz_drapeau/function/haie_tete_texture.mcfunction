# Usage : /function wz_drapeau:haie_tete_texture {valeur:"eyJ0ZXh0dXJlcyI6..."}
# Tete personnalisee a partir d'une valeur de texture (champ "Value" des sites de tetes, ex. minecraft-heads.com).
$execute as @e[type=armor_stand,tag=wz_soldat] run item replace entity @s armor.head with player_head[profile={properties:[{name:"textures",value:"$(valeur)"}]}]
tellraw @s {"text":"Tete personnalisee appliquee aux soldats.","color":"gold"}
