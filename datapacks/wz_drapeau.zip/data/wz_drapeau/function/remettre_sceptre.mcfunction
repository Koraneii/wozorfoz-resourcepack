function wz_drapeau:remettre {modele:"sceptre",slot:"weapon.mainhand",nom:"le sceptre"}
