# Fusees qui montent depuis le sol, explosent, puis le drapeau apparait
execute unless entity @e[type=marker,tag=wz_drapeau] run tellraw @s {"text":"[Drapeau] Aucun repere : lancez d'abord /function wz_drapeau:placer","color":"red"}
function wz_drapeau:arreter
schedule clear wz_drapeau:eteindre
function wz_drapeau:eclairer
execute as @e[type=marker,tag=wz_drapeau] at @s positioned as @e[type=marker,tag=wz_sol,limit=1] run function wz_drapeau:lancer_fusees
execute as @e[type=marker,tag=wz_drapeau] store result score #cible wz_drapeau run data get entity @s Pos[1]
scoreboard players add #cible wz_drapeau 24
schedule function wz_drapeau:montee 1t replace
