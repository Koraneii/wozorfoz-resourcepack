# 1) eteint les lumieres dont la personne est partie (plus personne dans le bloc juste en dessous)
execute as @e[type=marker,tag=wz_spot] at @s positioned ~ ~-1 ~ unless entity @a[dx=0,dy=0,dz=0] at @s run function wz_drapeau:poursuite_eteindre_une
# 2) allume une lumiere au-dessus de chaque personne presente dans la zone (si pas deja allumee)
$execute as @a[x=$(bx),y=$(by),z=$(bz),dx=$(dx),dy=$(dy),dz=$(dz),gamemode=!spectator] at @s positioned ~ ~1 ~ align xyz if block ~ ~ ~ air run function wz_drapeau:poursuite_poser
