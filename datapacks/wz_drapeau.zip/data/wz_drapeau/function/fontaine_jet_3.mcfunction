particle firework ~ ~0.3 ~ 0.132 0.982 0.134 0.58 0 force
particle firework ~ ~0.3 ~ 0.005 0.998 0.067 0.74 0 force
particle firework ~ ~0.3 ~ -0.149 0.980 0.136 0.63 0 force
particle firework ~ ~0.3 ~ -0.093 0.995 -0.021 0.56 0 force
particle firework ~ ~0.3 ~ -0.072 0.975 -0.209 0.79 0 force
particle firework ~ ~0.3 ~ 0.127 0.973 -0.192 0.55 0 force
particle firework ~ ~0.3 ~ 0.122 0.992 -0.011 0.74 0 force
particle small_flame ~ ~0.2 ~ 0.08 0.05 0.08 0.02 2 force
