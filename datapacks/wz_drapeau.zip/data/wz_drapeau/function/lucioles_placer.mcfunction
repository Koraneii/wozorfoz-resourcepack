# Debout au centre d'une zone (gradins, buffet...) : ajoute un nid de lucioles (environ 12 blocs autour). Plusieurs possibles.
summon marker ~ ~ ~ {Tags:["wz_luciole"]}
tellraw @s {"text":"Nid de lucioles placé.","color":"gold"}
