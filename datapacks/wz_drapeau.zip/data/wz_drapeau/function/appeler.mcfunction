# Usage : /function wz_drapeau:appeler {joueur:"Pseudo"}  (a lancer au moment ou on l'invite a monter)
execute unless entity @e[type=marker,tag=wz_scene1] run return run tellraw @s {"text":"Zone de scène non définie : /function wz_drapeau:scene_coin1 puis scene_coin2","color":"red"}
$execute unless entity @a[name="$(joueur)"] run return run tellraw @s {"text":"Joueur introuvable : $(joueur)","color":"red"}
$tag @a[name="$(joueur)"] add wz_appel
function wz_drapeau:scene_coords
scoreboard players set #spot wz_drapeau 1
schedule function wz_drapeau:boucle_rapide 2t replace
$tellraw @s {"text":"Lumière sur $(joueur) jusqu'à son arrivée sur scène.","color":"gold"}
