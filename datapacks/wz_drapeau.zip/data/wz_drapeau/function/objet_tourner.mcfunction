# Tourne d'un quart de tour l'objet pose le plus proche (lanterne, etendard, plateau, barriere...)
execute as @e[type=item_display,tag=wz_barriere,distance=..4,sort=nearest,limit=1] at @s run tp @s ~ ~ ~ ~90 ~
