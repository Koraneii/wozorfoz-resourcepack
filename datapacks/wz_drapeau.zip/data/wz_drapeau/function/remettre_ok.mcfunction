# l'objet que la personne avait deja a cet emplacement tombe a ses pieds (rien n'est perdu)
$execute as @a[tag=wz_recoit,limit=1] at @s if items entity @s $(slot) * run function wz_drapeau:remettre_deposer {slot:"$(slot)"}
$item replace entity @a[tag=wz_recoit,limit=1] $(slot) from entity @s weapon.mainhand
item replace entity @s weapon.mainhand with air
execute at @a[tag=wz_recoit,limit=1] run particle minecraft:end_rod ~ ~2.1 ~ 0.35 0.25 0.35 0.02 30
execute at @a[tag=wz_recoit,limit=1] run particle minecraft:wax_on ~ ~2.1 ~ 0.4 0.3 0.4 1 20
execute at @a[tag=wz_recoit,limit=1] run playsound minecraft:item.armor.equip_gold master @a ~ ~ ~ 1.5 1
$function wz_drapeau:remettre_apres_$(modele)
