$fill $(x1) $(y1) $(z1) $(x2) $(y1) $(z2) light[level=$(n)] replace air
$fill $(x1) $(y2b) $(z1) $(x2) $(y2b) $(z2) light[level=$(n)] replace air
