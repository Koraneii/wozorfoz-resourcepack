execute store result score #r wz_drapeau run random value 0..11
execute if score #r wz_drapeau matches 6..8 run setblock ~ ~ ~ light[level=15]
execute if score #r wz_drapeau matches 9..10 run setblock ~ ~ ~ light[level=14]
execute if score #r wz_drapeau matches 11 run setblock ~ ~ ~ light[level=13]
