setblock ~ ~ ~ light[level=15]
summon marker ~ ~ ~ {Tags:["wz_spot"]}
