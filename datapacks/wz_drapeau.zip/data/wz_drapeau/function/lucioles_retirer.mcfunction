function wz_drapeau:lucioles_off
kill @e[type=marker,tag=wz_luciole]
tellraw @s {"text":"Nids de lucioles retirés.","color":"gold"}
