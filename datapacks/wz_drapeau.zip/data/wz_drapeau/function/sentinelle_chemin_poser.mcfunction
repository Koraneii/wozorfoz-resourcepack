execute if score #cote wz_drapeau matches 0 positioned ^2 ^ ^ run function wz_drapeau:sentinelle_chemin_sol
execute if score #cote wz_drapeau matches 1 positioned ^-2 ^ ^ run function wz_drapeau:sentinelle_chemin_sol
