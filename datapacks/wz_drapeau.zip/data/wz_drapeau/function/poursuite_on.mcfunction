# Chaque joueur qui monte dans la zone de la scene (coins 1 et 2) est suivi par une lumiere
function wz_drapeau:scene_coords
scoreboard players set #spot wz_drapeau 1
schedule function wz_drapeau:boucle_rapide 2t replace
execute unless entity @e[type=marker,tag=wz_scene1] run tellraw @s {"text":"Coin 1 manquant : /function wz_drapeau:scene_coin1","color":"red"}
execute unless entity @e[type=marker,tag=wz_scene2] run tellraw @s {"text":"Coin 2 manquant : /function wz_drapeau:scene_coin2","color":"red"}
tellraw @s ["",{"text":"Poursuite activée. Zone : ","color":"gold"},{"storage":"wz_drapeau:scene","nbt":"bx"},{"text":" "},{"storage":"wz_drapeau:scene","nbt":"by"},{"text":" "},{"storage":"wz_drapeau:scene","nbt":"bz"},{"text":" + "},{"storage":"wz_drapeau:scene","nbt":"dx"},{"text":" / "},{"storage":"wz_drapeau:scene","nbt":"dy"},{"text":" / "},{"storage":"wz_drapeau:scene","nbt":"dz"}]
