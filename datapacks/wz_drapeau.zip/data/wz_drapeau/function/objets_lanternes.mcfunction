give @s barrier[item_model="wozorfoz:lanterne",item_name={text:"Lanterne",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:lanterne_murale",item_name={text:"Lanterne murale",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:lanterne_suspendue",item_name={text:"Lanterne suspendue",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:lampadaire",item_name={text:"Lampadaire",color:"gold"}] 16
tellraw @s {"text":"Lanterne posée : sur un muret ou une table. Murale : face au mur. Suspendue : sous un plafond. Mal tournée : /function wz_drapeau:objet_tourner","color":"gold"}
