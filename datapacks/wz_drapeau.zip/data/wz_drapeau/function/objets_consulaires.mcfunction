give @s golden_helmet[item_model="wozorfoz:couronne",equippable={slot:"head"},item_name={text:"Couronne Consulaire",color:"gold"},rarity="epic"]
give @s blaze_rod[item_model="wozorfoz:sceptre",item_name={text:"Sceptre Consulaire",color:"gold"},rarity="epic"]
give @s paper[item_model="wozorfoz:sceau",item_name={text:"Sceau de la Charge Consulaire",color:"gold"},rarity="epic",max_stack_size=1]
