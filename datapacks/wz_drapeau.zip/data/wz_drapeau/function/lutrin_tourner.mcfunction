# Fait pivoter de 180 degres l'habillage du lutrin le plus proche (si le sceau est du mauvais cote)
execute as @e[type=item_display,tag=wz_lutrin,distance=..6,sort=nearest,limit=1] at @s run tp @s ~ ~ ~ ~180 ~
