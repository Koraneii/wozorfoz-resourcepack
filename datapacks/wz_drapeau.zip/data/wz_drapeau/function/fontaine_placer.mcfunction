# Place une fontaine a vos pieds (posez-la sur le sol, a l'ecart du public)
summon marker ~ ~ ~ {Tags:["wz_fontaine"]}
tellraw @s {"text":"Fontaine placée.","color":"gold"}
