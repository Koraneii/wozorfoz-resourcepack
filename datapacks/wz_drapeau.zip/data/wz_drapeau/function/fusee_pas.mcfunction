tp @s ~ ~1.2 ~
particle firework ~ ~ ~ 0.03 0.15 0.03 0.01 2 force
particle flame ~ ~-0.6 ~ 0.02 0.1 0.02 0.005 1 force
execute store result score #y wz_drapeau run data get entity @s Pos[1]
execute if score #y wz_drapeau >= #cible wz_drapeau run function wz_drapeau:fusee_explose
