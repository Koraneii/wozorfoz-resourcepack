# Usage : /function wz_drapeau:scene_fondu {niveau:11}   (0 = fondu au noir ; 1 a 14). Environ 2 s pour 0 -> 11.
execute unless entity @e[type=marker,tag=wz_scene1] run return run tellraw @s {"text":"Zone de scène non définie : scene_coin1 puis scene_coin2","color":"red"}
function wz_drapeau:scene_coords
$scoreboard players set #fcible wz_drapeau $(niveau)
schedule function wz_drapeau:scene_fondu_pas 1t replace
$tellraw @s {"text":"Fondu de la scène vers le niveau $(niveau).","color":"gold"}
