# Debout à l'endroit voulu, en regardant vers où la sentinelle doit regarder (le chemin) : pose une sentinelle
execute rotated ~ 0 run summon armor_stand ~ ~ ~ {Tags:["wz_soldat","wz_sentinelle","wz_nouveau"],ShowArms:1b,NoBasePlate:1b,Invulnerable:1b,DisabledSlots:4144959,equipment:{head:{id:"minecraft:iron_helmet"},chest:{id:"minecraft:leather_chestplate",components:{"minecraft:dyed_color":12787736}},legs:{id:"minecraft:leather_leggings",components:{"minecraft:dyed_color":4925970}},feet:{id:"minecraft:leather_boots",components:{"minecraft:dyed_color":4925970}},mainhand:{id:"minecraft:iron_sword"}},Pose:{RightArm:[-75f,0f,0f],LeftArm:[0f,0f,-5f]}}
execute rotated ~ 0 run tp @e[type=armor_stand,tag=wz_nouveau,limit=1] ~ ~ ~ ~ 0
execute as @e[type=armor_stand,tag=wz_nouveau] at @s run function wz_drapeau:sentinelle_finir
tellraw @s {"text":"Sentinelle posée.","color":"gold"}
