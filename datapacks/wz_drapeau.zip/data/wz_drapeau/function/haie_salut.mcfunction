# Salut en vague : les paires levent l'arme l'une apres l'autre, depuis l'entree vers l'estrade (0,2 s d'ecart)
execute as @e[type=armor_stand,tag=wz_soldat] run function wz_drapeau:haie_salut_un
tag @e[type=armor_stand,tag=wz_soldat] add wz_salut_force
function wz_drapeau:haie_anim_demarrer
