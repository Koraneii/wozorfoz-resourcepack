# Usage : /function wz_drapeau:sentinelles_chemin {ecart:2}
# Pose une sentinelle tous les <ecart> points du chemin, à 2 blocs du milieu, en alternant gauche et droite,
# tournée vers le chemin. Le chemin doit avoir été tracé avec chemin_point.
execute unless entity @e[type=marker,tag=wz_chemin] run return run tellraw @s {"text":"Aucun chemin : pose d'abord les points avec chemin_point.","color":"red"}
$scoreboard players set #secart wz_drapeau $(ecart)
execute unless score #secart wz_drapeau matches 1.. run scoreboard players set #secart wz_drapeau 2
scoreboard players set #ck wz_drapeau 0
scoreboard players set #cote wz_drapeau 0
scoreboard players set #sposees wz_drapeau 0
function wz_drapeau:sentinelles_chemin_pas
tellraw @s ["",{"score":{"name":"#sposees","objective":"wz_drapeau"},"color":"gold"},{"text":" sentinelles posées le long du chemin.","color":"gold"}]
