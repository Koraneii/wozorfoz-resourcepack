kill @e[tag=wz_place]
tellraw @s {"text":"Toutes les étiquettes de places sont retirées.","color":"gold"}
