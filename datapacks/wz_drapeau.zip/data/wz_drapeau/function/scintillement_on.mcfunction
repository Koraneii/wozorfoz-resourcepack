scoreboard players set #scint wz_drapeau 1
tellraw @s {"text":"Scintillement active.","color":"gold"}
