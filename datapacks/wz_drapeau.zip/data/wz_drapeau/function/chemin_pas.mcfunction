scoreboard players add #cpas wz_drapeau 1
execute as @e[type=marker,tag=wz_chemin] if score @s wz_drapeau = #cpas wz_drapeau at @s run function wz_drapeau:chemin_poser_un
execute if score #cpas wz_drapeau < #chemin wz_drapeau run schedule function wz_drapeau:chemin_pas 5t replace
