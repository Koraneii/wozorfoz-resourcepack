execute if block ~ ~-0.5 ~ barrier run setblock ~ ~-0.5 ~ air
execute if block ~ ~-0.5 ~ polished_blackstone run setblock ~ ~-0.5 ~ air
kill @e[tag=wz_plateau_part,distance=..0.9]
execute if entity @s[tag=wz_lanterne] as @e[type=marker,tag=wz_lum,distance=..3.6,sort=nearest,limit=1] at @s run function wz_drapeau:lanterne_lum_retirer
kill @s
