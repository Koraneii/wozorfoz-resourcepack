$function wz_drapeau:haie/salut_$(f)
