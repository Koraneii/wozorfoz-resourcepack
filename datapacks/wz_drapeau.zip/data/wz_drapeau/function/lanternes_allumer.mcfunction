# Les lanternes s'allument en fondu (environ 1,5 s)
scoreboard players set #lant wz_drapeau 1
scoreboard players set #lcible wz_drapeau 15
execute unless score #lniv wz_drapeau matches 0..15 run scoreboard players set #lniv wz_drapeau 0
schedule clear wz_drapeau:lanternes_boucle
schedule function wz_drapeau:lanternes_fondu 1t replace
tellraw @s {"text":"Lanternes allumées.","color":"gold"}
