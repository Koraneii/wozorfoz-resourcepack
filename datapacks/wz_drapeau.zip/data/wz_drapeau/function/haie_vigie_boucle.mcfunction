execute as @e[type=armor_stand,tag=wz_soldat] at @s run function wz_drapeau:haie_vigie_soldat
execute if score #vigie wz_drapeau matches 1.. unless score #haie_anim wz_drapeau matches 1 run function wz_drapeau:haie_anim_demarrer
execute if score #vigie wz_drapeau matches 1.. run schedule function wz_drapeau:haie_vigie_boucle 4t replace
