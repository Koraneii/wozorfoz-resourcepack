# Grand bouquet : 3 vagues depuis tous les points de tir (wz_tir).
# Explosions etalees de +2,2 s a +4,7 s apres le declenchement ; grosse boule finale a +4,5 s.
execute as @e[type=marker,tag=wz_tir] at @s run function wz_drapeau:bouquet_v1
schedule function wz_drapeau:bouquet_t2 20t
schedule function wz_drapeau:bouquet_t3 40t
