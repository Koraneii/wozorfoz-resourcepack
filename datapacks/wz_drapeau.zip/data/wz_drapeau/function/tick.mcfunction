# « at » le coin de scene : la detection se fait dans le monde de la scene (et non le monde principal)
execute if score #spot wz_drapeau matches 1 at @e[type=marker,tag=wz_scene1,limit=1] run function wz_drapeau:poursuite_tick with storage wz_drapeau:scene
execute if entity @a[tag=wz_appel] at @e[type=marker,tag=wz_scene1,limit=1] run function wz_drapeau:appel_tick with storage wz_drapeau:scene
execute if score #heraut wz_drapeau matches 1 at @e[type=marker,tag=wz_entree] as @a[distance=..3,tag=!wz_annonce,gamemode=!spectator] at @s run function wz_drapeau:heraut_annonce
