# (toutes les 2 ticks) un cran vers le niveau vise ; le vacillement reprend une fois allumees
execute if score #lniv wz_drapeau < #lcible wz_drapeau run scoreboard players add #lniv wz_drapeau 1
execute if score #lniv wz_drapeau > #lcible wz_drapeau run scoreboard players remove #lniv wz_drapeau 1
execute if score #lniv wz_drapeau matches 0 as @e[type=marker,tag=wz_lum] at @s if block ~ ~ ~ light run setblock ~ ~ ~ air
execute store result storage wz_drapeau:lant n int 1 run scoreboard players get #lniv wz_drapeau
execute if score #lniv wz_drapeau matches 1.. run function wz_drapeau:lanternes_niveau_m with storage wz_drapeau:lant
execute unless score #lniv wz_drapeau = #lcible wz_drapeau run return run schedule function wz_drapeau:lanternes_fondu 2t replace
execute if score #lant wz_drapeau matches 1 if score #vac wz_drapeau matches 1 run schedule function wz_drapeau:lanternes_boucle 4t replace
