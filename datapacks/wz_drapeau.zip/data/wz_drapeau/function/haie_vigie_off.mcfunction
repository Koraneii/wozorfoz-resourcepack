scoreboard players set #vigie wz_drapeau 0
schedule clear wz_drapeau:haie_vigie_boucle
tag @e[type=armor_stand,tag=wz_soldat] remove wz_voit
function wz_drapeau:haie_repos
tellraw @s {"text":"Vigie desactivee.","color":"gold"}
