scoreboard players add #ck wz_drapeau 1
execute if score #ck wz_drapeau > #chemin wz_drapeau run return 0
scoreboard players operation #m wz_drapeau = #ck wz_drapeau
scoreboard players operation #m wz_drapeau %= #secart wz_drapeau
execute if score #m wz_drapeau matches 0 run function wz_drapeau:sentinelles_chemin_un
function wz_drapeau:sentinelles_chemin_pas
