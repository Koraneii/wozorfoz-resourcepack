schedule clear wz_drapeau:chemin_pas
execute as @e[type=marker,tag=wz_chemin] at @s positioned ~ ~1 ~ if block ~ ~ ~ light run setblock ~ ~ ~ air
