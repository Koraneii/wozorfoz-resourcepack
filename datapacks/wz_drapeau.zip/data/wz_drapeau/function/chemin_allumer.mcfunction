# Allume le chemin pas a pas (un point toutes les 5 ticks, soit 4 par seconde)
function wz_drapeau:chemin_eteindre
scoreboard players set #cpas wz_drapeau 0
schedule function wz_drapeau:chemin_pas 1t replace
