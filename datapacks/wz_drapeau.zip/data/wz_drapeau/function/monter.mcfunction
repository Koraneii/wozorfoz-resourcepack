function wz_drapeau:eteindre
execute as @e[type=marker,tag=wz_drapeau] at @s run tp @s ~ ~5 ~
function wz_drapeau:eclairer
tellraw @s {"text":"Drapeau monte de 5 blocs.","color":"gold"}
