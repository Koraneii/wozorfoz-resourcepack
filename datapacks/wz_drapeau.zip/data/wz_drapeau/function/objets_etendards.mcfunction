give @s barrier[item_model="wozorfoz:etendard",item_name={text:"Étendard de l'Empire",color:"gold"}] 16
give @s barrier[item_model="wozorfoz:etendard_grand",item_name={text:"Grand étendard de l'Empire",color:"gold"}] 16
