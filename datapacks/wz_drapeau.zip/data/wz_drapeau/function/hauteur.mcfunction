# Usage : /function wz_drapeau:hauteur {h:60}   (h = hauteur du bas du drapeau au-dessus du sol)
function wz_drapeau:eteindre
$execute as @e[type=marker,tag=wz_drapeau] at @e[type=marker,tag=wz_sol,limit=1] run tp @s ~ ~$(h) ~
function wz_drapeau:eclairer
$tellraw @s {"text":"Bas du drapeau place a $(h) blocs au-dessus du sol.","color":"gold"}
