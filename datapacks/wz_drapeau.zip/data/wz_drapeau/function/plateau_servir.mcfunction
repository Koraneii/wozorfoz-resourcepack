# (en tant que la zone cliquable) ne sert que si c'est bien ce joueur qui l'a cliquee
execute store success score #moi wz_drapeau on target if entity @s[tag=wz_client]
execute unless score #moi wz_drapeau matches 1 run return 0
data remove entity @s interaction
execute as @e[type=item_display,tag=wz_plat,distance=..1,limit=1,sort=nearest] if items entity @s contents * run function wz_drapeau:plateau_donner
