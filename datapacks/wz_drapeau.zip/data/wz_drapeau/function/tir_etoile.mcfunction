summon firework_rocket ~ ~1 ~ {Motion:[0.0d,1.4d,0.0d],ShotAtAngle:1b,LifeTime:40,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:3,explosions:[{shape:"star",colors:[I;15498259],fade_colors:[I;4925970],has_trail:true},{shape:"star",colors:[I;16766720],fade_colors:[I;15498259],has_twinkle:true}]}}}}
function wz_drapeau:fumee_ici
