# Place un point de tir reserve aux eventails (feux intercalaires) a vos pieds
summon marker ~ ~ ~ {Tags:["wz_eventail"]}
tellraw @s {"text":"Point de tir d'éventail placé.","color":"gold"}
