kill @e[type=marker,tag=wz_entree]
scoreboard players set #heraut wz_drapeau 0
tellraw @s {"text":"Héraut retiré.","color":"gold"}
