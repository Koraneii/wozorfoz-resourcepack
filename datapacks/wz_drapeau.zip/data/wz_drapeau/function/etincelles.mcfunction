execute if score #grp wz_drapeau matches 0 run function wz_drapeau:etincelles_0
execute if score #grp wz_drapeau matches 1 run function wz_drapeau:etincelles_1
execute if score #grp wz_drapeau matches 2 run function wz_drapeau:etincelles_2
execute if score #grp wz_drapeau matches 3 run function wz_drapeau:etincelles_3
execute if score #grp wz_drapeau matches 4 run function wz_drapeau:etincelles_4
execute if score #grp wz_drapeau matches 5 run function wz_drapeau:etincelles_5
execute if score #grp wz_drapeau matches 6 run function wz_drapeau:etincelles_6
execute if score #grp wz_drapeau matches 7 run function wz_drapeau:etincelles_7
