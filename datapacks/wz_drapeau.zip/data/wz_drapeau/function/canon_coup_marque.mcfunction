function wz_drapeau:canon_coup
tag @s add wz_tire
