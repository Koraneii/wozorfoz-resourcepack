# Pose le panneau du menu 2 blocs devant vous, tourne vers vous
execute rotated ~ 0 positioned ^ ^ ^2 align xz positioned ~0.5 ~ ~0.5 run function wz_drapeau:menu_poser_ici
tellraw @s {"text":"Menu posé. Pour le retirer : /function wz_drapeau:menu_retirer (a moins de 3 blocs)","color":"gold"}
