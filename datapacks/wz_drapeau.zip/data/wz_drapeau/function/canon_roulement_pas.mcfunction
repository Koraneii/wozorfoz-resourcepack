execute as @e[type=marker,tag=wz_canon,tag=!wz_tire,sort=random,limit=1] at @s run function wz_drapeau:canon_coup_marque
execute if entity @e[type=marker,tag=wz_canon,tag=!wz_tire] run schedule function wz_drapeau:canon_roulement_pas 3t replace
