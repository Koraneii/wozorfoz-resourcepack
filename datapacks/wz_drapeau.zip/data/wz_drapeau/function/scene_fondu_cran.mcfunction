# 0 -> 1 : on pose la couche ; n -> 0 : on la retire ; sinon on change seulement le niveau (la poursuite, niveau 15, n'est pas touchee)
$execute if data storage wz_drapeau:scene {de:0} run return run function wz_drapeau:scene_fondu_m {de:"air",vers:"light[level=$(vers)]",x1:$(x1),x2:$(x2),y1:$(y1),y2b:$(y2b),z1:$(z1),z2:$(z2)}
$execute if data storage wz_drapeau:scene {vers:0} run return run function wz_drapeau:scene_fondu_m {de:"light[level=$(de)]",vers:"air",x1:$(x1),x2:$(x2),y1:$(y1),y2b:$(y2b),z1:$(z1),z2:$(z2)}
$function wz_drapeau:scene_fondu_m {de:"light[level=$(de)]",vers:"light[level=$(vers)]",x1:$(x1),x2:$(x2),y1:$(y1),y2b:$(y2b),z1:$(z1),z2:$(z2)}
