# Place un canon a vos pieds (le coup part de la, a hauteur de bouche ~1 bloc au-dessus du sol)
summon marker ~ ~ ~ {Tags:["wz_canon"]}
tellraw @s {"text":"Canon place.","color":"gold"}
