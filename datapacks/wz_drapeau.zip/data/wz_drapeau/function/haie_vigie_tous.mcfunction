# Les soldats saluent n'importe quel joueur qui passe pres d'eux
scoreboard players set #vigie wz_drapeau 1
function wz_drapeau:haie_vigie_boucle
function wz_drapeau:haie_anim_demarrer
tellraw @s {"text":"Vigie activee : les soldats saluent tous les joueurs.","color":"gold"}
