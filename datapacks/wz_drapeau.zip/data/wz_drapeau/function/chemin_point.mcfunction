# Debout sur le chemin, au sol : ajoute le point suivant (en partant de la scene ; un point tous les 3 a 4 blocs)
summon marker ~ ~ ~ {Tags:["wz_chemin","wz_chemin_neuf"]}
scoreboard players add #chemin wz_drapeau 1
scoreboard players operation @e[type=marker,tag=wz_chemin_neuf] wz_drapeau = #chemin wz_drapeau
tag @e[type=marker,tag=wz_chemin_neuf] remove wz_chemin_neuf
tellraw @s ["",{"text":"Point de chemin n° ","color":"gold"},{"score":{"name":"#chemin","objective":"wz_drapeau"},"color":"gold"}]
