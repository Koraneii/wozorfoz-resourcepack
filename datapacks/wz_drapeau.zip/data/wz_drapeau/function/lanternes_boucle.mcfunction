# (toutes les 4 ticks) la flamme de chaque lanterne vacille legerement
execute as @e[type=marker,tag=wz_lum] at @s if block ~ ~ ~ light run function wz_drapeau:lanterne_vacille
execute if score #lant wz_drapeau matches 1 if score #vac wz_drapeau matches 1 if entity @e[type=marker,tag=wz_lum] run schedule function wz_drapeau:lanternes_boucle 4t replace
