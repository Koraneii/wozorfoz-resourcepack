scoreboard objectives add wz_drapeau dummy
# étiquettes de régie : lisibles de près seulement (environ 5 blocs)
execute as @e[type=text_display,tag=wz_regie_label] run data merge entity @s {view_range:0.08f}
# plateaux de service : ils prennent la lumière de la salle (pas de luminosité imposée)
execute as @e[type=item_display,tag=wz_plat] run data remove entity @s brightness
execute as @e[type=item_display,tag=wz_barriere] if items entity @s contents *[minecraft:item_model="wozorfoz:plateau"] run data remove entity @s brightness
execute unless score #scint wz_drapeau matches 0.. run scoreboard players set #scint wz_drapeau 1
scoreboard players set #huit wz_drapeau 8
scoreboard players set #cinq wz_drapeau 5
scoreboard players set #moinsun wz_drapeau -1
scoreboard players set #vingt wz_drapeau 20
scoreboard objectives add wz_invite dummy
execute if score #vigie wz_drapeau matches 1.. run schedule function wz_drapeau:haie_vigie_boucle 20t replace
scoreboard objectives add wz_haie_f dummy
scoreboard objectives add wz_haie_p dummy
scoreboard objectives add wz_haie_d dummy
scoreboard objectives add wz_haie_h dummy
scoreboard objectives add wz_haie_r dummy
scoreboard players set #deux wz_drapeau 2
scoreboard players set #moins_un wz_drapeau -1
scoreboard players set #trois_cent_soixante wz_drapeau 360
execute unless score #signe_tete wz_drapeau matches -1..1 run scoreboard players set #signe_tete wz_drapeau 1
execute if score #spot wz_drapeau matches 1 run function wz_drapeau:scene_coords
schedule function wz_drapeau:boucle_rapide 20t replace
schedule function wz_drapeau:etendard_vent 20t replace
scoreboard objectives add wz_vent dummy
scoreboard objectives add wz_remise trigger
execute unless score #fniv wz_drapeau matches 0.. run scoreboard players set #fniv wz_drapeau 0
scoreboard players set #soixante wz_drapeau 60
execute unless score #lant wz_drapeau matches 0.. run scoreboard players set #lant wz_drapeau 1
execute unless score #vac wz_drapeau matches 0.. run scoreboard players set #vac wz_drapeau 1
execute unless score #lniv wz_drapeau matches 0..15 run scoreboard players set #lniv wz_drapeau 15
execute if score #lant wz_drapeau matches 1 if score #vac wz_drapeau matches 1 run schedule function wz_drapeau:lanternes_boucle 20t replace
execute if score #lucioles wz_drapeau matches 1 run schedule function wz_drapeau:lucioles_boucle 20t replace
schedule function wz_drapeau:remise_boucle 20t replace
scoreboard players set #douze wz_drapeau 12
execute unless data storage wz_drapeau:config v run data modify storage wz_drapeau:config v set value 2
execute unless score #max wz_drapeau matches 1.. run scoreboard players set #max wz_drapeau 50
