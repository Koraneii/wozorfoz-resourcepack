# Supprime tout le chemin (pour le retracer depuis le debut)
function wz_drapeau:chemin_eteindre
kill @e[type=marker,tag=wz_chemin]
scoreboard players set #chemin wz_drapeau 0
tellraw @s {"text":"Chemin effacé.","color":"gold"}
