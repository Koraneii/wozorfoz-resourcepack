execute store result storage wz_drapeau:haie f int 1 run scoreboard players get @s wz_haie_f
function wz_drapeau:haie_pose_m with storage wz_drapeau:haie
