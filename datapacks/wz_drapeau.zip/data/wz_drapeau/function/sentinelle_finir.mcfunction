# (en tant que nouvelle sentinelle) même tête que la haie d'honneur si elle en porte une, prête pour la vigie
scoreboard players set @s wz_haie_r 0
function wz_drapeau:sentinelle_habiller
execute if entity @e[type=armor_stand,tag=wz_soldat,tag=!wz_nouveau,limit=1] run item replace entity @s armor.head from entity @e[type=armor_stand,tag=wz_soldat,tag=!wz_nouveau,limit=1] armor.head
execute if entity @s[tag=wz_guide] if block ~ ~1 ~ air run setblock ~ ~1 ~ light[level=13]
tag @s remove wz_nouveau
