execute at @e[type=marker,tag=wz_spot] if block ~ ~ ~ light[level=15] run setblock ~ ~ ~ air
kill @e[type=marker,tag=wz_spot]
