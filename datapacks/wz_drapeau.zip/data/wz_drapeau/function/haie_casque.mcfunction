# Remet le casque de fer a tous les soldats
execute as @e[type=armor_stand,tag=wz_soldat] run item replace entity @s armor.head with iron_helmet
