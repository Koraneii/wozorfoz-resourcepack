$data modify entity @s item.components."minecraft:item_model" set value "wozorfoz:etendard_$(k)"
