# Usage : /function wz_drapeau:scene_allumer {niveau:11}   (1 = faible ... 14 ; le niveau 15 est reserve a la poursuite)
# Pose une couche de lumiere invisible au ras du sol de la scene (niveau du coin 1 et du coin 2).
function wz_drapeau:scene_coords
$data modify storage wz_drapeau:scene n set value $(niveau)
function wz_drapeau:scene_eteindre_zone with storage wz_drapeau:scene
function wz_drapeau:scene_remplir with storage wz_drapeau:scene
$scoreboard players set #fniv wz_drapeau $(niveau)
$tellraw @s {"text":"Scène éclairée (niveau $(niveau)).","color":"gold"}
