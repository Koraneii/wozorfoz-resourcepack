function wz_drapeau:fumee_ici
summon firework_rocket ~ ~1 ~ {Motion:[0.47d,1.2d,0.0d],ShotAtAngle:1b,LifeTime:44,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:3,explosions:[{shape:"star",colors:[I;15498259],fade_colors:[I;4925970],has_trail:true}]}}}}
summon firework_rocket ~ ~1 ~ {Motion:[-0.47d,1.2d,0.0d],ShotAtAngle:1b,LifeTime:50,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:3,explosions:[{shape:"star",colors:[I;15498259],fade_colors:[I;4925970],has_trail:true}]}}}}
