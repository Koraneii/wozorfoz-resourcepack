# (en tant que celui qui remet) l'insigne quitte sa main et va a la personne qu'il regarde
$execute unless items entity @s weapon.mainhand *[minecraft:item_model="wozorfoz:$(modele)"] run return run tellraw @s {"text":"Tenez $(nom) en main, puis regardez la personne à qui la remettre.","color":"red"}
tag @s add wz_remet
execute at @s rotated ~ 0 positioned ^ ^ ^1.8 run tag @p[tag=!wz_remet,distance=..1.6,gamemode=!spectator] add wz_recoit
execute unless entity @a[tag=wz_recoit] run tellraw @s {"text":"Personne devant vous : placez-vous face à elle, à 1 ou 2 blocs.","color":"red"}
$execute if entity @a[tag=wz_recoit] run function wz_drapeau:remettre_ok {modele:"$(modele)",slot:"$(slot)"}
tag @s remove wz_remet
tag @a remove wz_recoit
