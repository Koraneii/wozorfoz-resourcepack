# signes avant-coureurs pendant 4 s, puis apparition
tag @s add wz_nat_wprep
scoreboard players set @s wz_nat_wv 4
