# (au sol, derrière le joueur ; @s = le joueur)
summon item_display ~ ~0.5 ~ {Tags:["wz_nat_wendigo","wz_nat_wderriere","wz_nat_wneuf"],item_display:"fixed",view_range:2f,teleport_duration:20,item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:nature_wendigo"}}}
summon item_display ~ ~0.5 ~ {Tags:["wz_nat_wyeux","wz_nat_wneuf"],item_display:"fixed",view_range:2f,teleport_duration:20,brightness:{sky:15,block:15},item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:nature_wendigo_yeux"}}}
scoreboard players operation @e[type=item_display,tag=wz_nat_wneuf] wz_nat_wid = #id wz_nat
scoreboard players set @e[type=item_display,tag=wz_nat_wneuf] wz_nat_wt 0
execute as @e[type=item_display,tag=wz_nat_wneuf] at @s facing entity @p[gamemode=!spectator] feet rotated ~-90 0 run tp @s ~ ~ ~ ~ 0
tag @e[type=item_display,tag=wz_nat_wneuf] remove wz_nat_wneuf
playsound minecraft:block.wood.break hostile @s ~ ~1 ~ 0.4 0.5
