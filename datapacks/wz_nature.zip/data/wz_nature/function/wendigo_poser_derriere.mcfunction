# (au sol, derrière le joueur ; @s = le joueur)
summon item_display ~ ~0.5 ~ {Tags:["wz_nat_wendigo","wz_nat_wderriere","wz_nat_wneuf"],item_display:"fixed",view_range:2f,teleport_duration:20,item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:nature_wendigo"}}}
summon item_display ~ ~0.5 ~ {Tags:["wz_nat_wyeux","wz_nat_wneuf"],item_display:"fixed",view_range:2f,teleport_duration:20,brightness:{sky:15,block:15},item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:nature_wendigo_yeux"}}}
scoreboard players operation @e[type=item_display,tag=wz_nat_wneuf] wz_nat_wid = #id wz_nat
scoreboard players set @e[type=item_display,tag=wz_nat_wneuf] wz_nat_wt 0
# mode « fonce » : demi-seconde d'immobilité dans le dos, puis il charge (déplacements toutes les 2 ticks)
execute if score #mode wz_nat matches 1 as @e[type=item_display,tag=wz_nat_wneuf] run tag @s remove wz_nat_wderriere
execute if score #mode wz_nat matches 1 as @e[type=item_display,tag=wz_nat_wneuf,tag=wz_nat_wendigo] run tag @s add wz_nat_wfonce
execute if score #mode wz_nat matches 1 as @e[type=item_display,tag=wz_nat_wneuf] run data merge entity @s {teleport_duration:2}
execute if score #mode wz_nat matches 1 run scoreboard players set @e[type=item_display,tag=wz_nat_wneuf] wz_nat_wt -5
execute as @e[type=item_display,tag=wz_nat_wneuf] at @s facing entity @p[gamemode=!spectator] feet rotated ~-90 0 run tp @s ~ ~ ~ ~ 0
tag @e[type=item_display,tag=wz_nat_wneuf] remove wz_nat_wneuf
playsound minecraft:block.wood.break hostile @s ~ ~1 ~ 0.4 0.5
