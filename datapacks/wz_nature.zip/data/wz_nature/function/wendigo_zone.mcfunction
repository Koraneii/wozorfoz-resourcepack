# (en tant que point du wendigo, la nuit) zone d'oppression sur 24 blocs : la forêt se tait, l'obscurité pulse,
# des cendres flottent ; plus large (40 blocs) quand il est là
tag @a[distance=..24,gamemode=!spectator] add wz_nat_scene
# l'obscurité pèse tant qu'il n'est pas là, et se lève d'un coup quand il surgit (pour qu'on le voie bien)
execute if entity @s[tag=!wz_nat_wvisible] run effect give @a[distance=..24,gamemode=!spectator] minecraft:darkness 2 0 true
execute if entity @s[tag=wz_nat_wvisible] run effect clear @a[distance=..40] minecraft:darkness
execute if entity @a[distance=..30] run particle minecraft:white_ash ~ ~3 ~ 10 3 10 0 40
execute if predicate {condition:"minecraft:random_chance",chance:0.03} run playsound minecraft:ambient.cave ambient @a[distance=..24] ~ ~3 ~ 0.6 0.5
