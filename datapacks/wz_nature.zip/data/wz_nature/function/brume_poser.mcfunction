# Usage : /function wz_nature:brume_poser {nappes:6,rayon:8}
# Pose <nappes> nappes de brume (12 x 12 blocs chacune) au hasard dans un rayon de <rayon> blocs autour de vous,
# entre le sol (vos pieds) et 1,5 bloc de haut.
$scoreboard players set #n wz_nat $(nappes)
$scoreboard players set #rb wz_nat $(rayon)
execute if score #n wz_nat matches 1.. run function wz_nature:brume_une
$tellraw @s {"text":"$(nappes) nappes de brume posées.","color":"dark_green"}
