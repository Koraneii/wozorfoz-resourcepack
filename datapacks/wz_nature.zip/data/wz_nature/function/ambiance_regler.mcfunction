# volume = rayon / 16 (Minecraft fait porter un son de 16 blocs par point de volume) ; départ décalé au hasard
execute store result score #r wz_nat run data get entity @s data.rayon 100
scoreboard players set #seize wz_nat 16
scoreboard players operation #r wz_nat /= #seize wz_nat
execute store result entity @s data.volume float 0.01 run scoreboard players get #r wz_nat
execute store result score @s wz_nat_amb run random value 1..17
tag @s remove wz_nat_amb_neuf
