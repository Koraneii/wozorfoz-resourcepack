# (en tant que corps du wendigo) un pas lent vers le joueur le plus proche (glissé sur 1 s), en suivant le relief
execute if entity @a[distance=..2.5,gamemode=!spectator] run tag @p[distance=..2.5,gamemode=!spectator] add wz_nat_peur
execute if entity @a[distance=..2.5,gamemode=!spectator] run return run scoreboard players set #cacher wz_nat 1
execute unless entity @a[distance=..60,gamemode=!spectator] run return run scoreboard players set #cacher wz_nat 1
# il accélère en approchant : 1,1 bloc/s au loin, 1,7 à moins de 12 blocs, 2,4 (il charge) à moins de 6
scoreboard players set #vit wz_nat 1
execute if entity @a[distance=..12,gamemode=!spectator] run scoreboard players set #vit wz_nat 2
execute if entity @a[distance=..6,gamemode=!spectator] run scoreboard players set #vit wz_nat 3
execute if score #vit wz_nat matches 1 facing entity @p[gamemode=!spectator] feet rotated ~ 0 run tp @s ^ ^ ^1.1
execute if score #vit wz_nat matches 2 facing entity @p[gamemode=!spectator] feet rotated ~ 0 run tp @s ^ ^ ^1.7
execute if score #vit wz_nat matches 3 facing entity @p[gamemode=!spectator] feet rotated ~ 0 run tp @s ^ ^ ^2.4
execute if score #vit wz_nat matches 3 at @s run playsound minecraft:entity.warden.step hostile @a[distance=..40] ~ ~ ~ 1.8 0.55
execute at @s unless block ~ ~-0.5 ~ #minecraft:replaceable run tp @s ~ ~1 ~
execute at @s if block ~ ~-1.5 ~ #minecraft:replaceable run tp @s ~ ~-1 ~
execute at @s facing entity @p[gamemode=!spectator] feet rotated ~-90 0 run tp @s ~ ~ ~ ~ 0
tag @s add wz_nat_wcourant
execute as @e[type=item_display,tag=wz_nat_wyeux] if score @s wz_nat_wid = #id wz_nat run tp @s @e[type=item_display,tag=wz_nat_wcourant,limit=1]
tag @s remove wz_nat_wcourant
execute at @s run playsound minecraft:entity.warden.step hostile @a[distance=..40] ~ ~ ~ 1.6 0.65
# il murmure le nom du joueur qu'il suit (deux fois au plus par apparition)
execute unless score @s wz_nat_wm matches 2.. if predicate {condition:"minecraft:random_chance",chance:0.15} run function wz_nature:wendigo_murmure
execute if predicate {condition:"minecraft:random_chance",chance:0.2} at @s run playsound minecraft:entity.horse.breathe hostile @a[distance=..40] ~ ~2.8 ~ 1.8 0.45
execute if predicate {condition:"minecraft:random_chance",chance:0.06} at @s run playsound minecraft:entity.warden.sniff hostile @a[distance=..30] ~ ~2.8 ~ 1.2 0.6
