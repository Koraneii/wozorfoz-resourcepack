scoreboard players add #wid wz_nat 1
scoreboard players operation @s wz_nat_wid = #wid wz_nat
