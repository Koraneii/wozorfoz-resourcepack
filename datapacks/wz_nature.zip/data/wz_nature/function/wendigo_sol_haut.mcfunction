execute unless block ~ ~ ~ #minecraft:replaceable if score #sol wz_nat matches ..4 positioned ~ ~1 ~ run return run function wz_nature:wendigo_sol_haut_pas
scoreboard players set #sol wz_nat 0
function wz_nature:wendigo_sol_bas
