# (en tant que corps qui guette, toutes les 2 ticks) le joueur le regarde-t-il ?
scoreboard players operation #id wz_nat = @s wz_nat_wid
tag @s add wz_nat_wcourant
execute as @a[distance=..14,gamemode=!spectator] at @s anchored eyes positioned ^ ^ ^5 if entity @e[type=item_display,tag=wz_nat_wcourant,distance=..2.8] run tag @s add wz_nat_vu
tag @s remove wz_nat_wcourant
execute if entity @a[tag=wz_nat_vu] run function wz_nature:wendigo_bondir
