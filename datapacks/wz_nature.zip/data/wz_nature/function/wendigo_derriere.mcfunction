scoreboard players operation #id wz_nat = @s wz_nat_wid
scoreboard players set #sol wz_nat 0
execute as @p[distance=..40,gamemode=!spectator] at @s rotated ~ 0 positioned ^ ^ ^-5.5 run function wz_nature:wendigo_sol_haut
tag @s add wz_nat_wvisible
scoreboard players set @s wz_nat_wv 0
