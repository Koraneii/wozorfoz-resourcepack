execute at @e[type=item_display,tag=wz_nat_wendigo,distance=..1.5] run particle minecraft:large_smoke ~ ~1.5 ~ 0.5 1.2 0.5 0.02 30
execute if entity @e[type=item_display,tag=wz_nat_wendigo,distance=..1.5] run playsound minecraft:entity.phantom.flap hostile @a[distance=..40] ~ ~2 ~ 1.2 0.5
kill @e[type=item_display,tag=wz_nat_wendigo,distance=..1.5]
kill @e[type=item_display,tag=wz_nat_wyeux,distance=..1.5]
tag @s remove wz_nat_wvisible
execute store result score @s wz_nat_wc run random value 120..360
