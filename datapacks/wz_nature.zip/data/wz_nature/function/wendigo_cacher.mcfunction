# (en tant que point) le wendigo s'évanouit dans la fumée, puis se fait oublier 2 à 6 minutes
scoreboard players operation #id wz_nat = @s wz_nat_wid
execute as @e[type=item_display,tag=wz_nat_wendigo] if score @s wz_nat_wid = #id wz_nat at @s run function wz_nature:wendigo_fumee
execute as @e[type=item_display,tag=wz_nat_wyeux] if score @s wz_nat_wid = #id wz_nat run kill @s
tag @s remove wz_nat_wvisible
execute store result score @s wz_nat_wc run random value 120..360
execute if entity @a[tag=wz_nat_peur] run schedule function wz_nature:wendigo_cri_differe 30t append
