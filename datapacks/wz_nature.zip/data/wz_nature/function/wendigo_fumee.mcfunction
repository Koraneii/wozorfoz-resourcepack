particle minecraft:large_smoke ~ ~1.5 ~ 0.5 1.2 0.5 0.02 30
playsound minecraft:entity.phantom.flap hostile @a[distance=..40] ~ ~2 ~ 1.2 0.5
kill @s
