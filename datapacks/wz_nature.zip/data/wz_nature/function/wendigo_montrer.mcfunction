execute at @e[type=marker,tag=wz_nat_wpoint] run particle minecraft:soul_fire_flame ~ ~1 ~ 0.3 1 0.3 0 30 force @s
