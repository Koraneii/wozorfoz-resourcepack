schedule function wz_nature:boucle 20t replace
execute as @e[type=item_display,tag=wz_nat_animal] at @s run function wz_nature:vie
execute as @e[type=item_display,tag=wz_nat_hibou_tete] at @s run function wz_nature:vie_hibou_tete
execute unless score #amb wz_nat matches 0 as @e[type=marker,tag=wz_nat_amb] at @s run function wz_nature:ambiance_point
