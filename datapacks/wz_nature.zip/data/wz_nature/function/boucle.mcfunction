schedule function wz_nature:boucle 20t replace
execute as @e[type=item_display,tag=wz_nat_animal] at @s run function wz_nature:vie
execute as @e[type=item_display,tag=wz_nat_hibou_tete] at @s run function wz_nature:vie_hibou_tete
tag @a remove wz_nat_scene
execute if data storage wz_drapeau:scene dx run function wz_nature:scene_zone
execute as @a[tag=wz_nat_scene] run stopsound @s ambient wozorfoz:nature.ambiance_nuit
execute as @a[tag=wz_nat_scene] run stopsound @s ambient wozorfoz:nature.ambiance_eau
execute unless score #amb wz_nat matches 0 as @e[type=marker,tag=wz_nat_amb] at @s run function wz_nature:ambiance_point
execute unless score #brume wz_nat matches 0 as @e[type=item_display,tag=wz_nat_brume] if predicate {condition:"minecraft:random_chance",chance:0.07} run function wz_nature:brume_deriver
