# Retire les sapins dont la barrière a été cassée à la main
execute as @e[type=item_display,tag=wz_nat_sapin] at @s unless block ~ ~ ~ barrier run kill @s
tellraw @s {"text":"Sapins orphelins nettoyés.","color":"dark_green"}
