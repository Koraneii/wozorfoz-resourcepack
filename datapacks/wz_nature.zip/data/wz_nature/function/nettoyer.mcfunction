# Enlève les animaux dont la barrière a été cassée à la main
execute as @e[type=item_display,tag=wz_nat_animal] at @s unless block ~ ~ ~ barrier run function wz_nature:retirer_ici
execute as @e[type=item_display,tag=wz_nat_hibou_tete] at @s unless entity @e[type=item_display,tag=wz_nat_hibou,distance=..0.3] run kill @s
tellraw @s {"text":"Animaux orphelins nettoyés.","color":"dark_green"}
