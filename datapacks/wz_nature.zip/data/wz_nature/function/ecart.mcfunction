# petit écart d'orientation au hasard (entre -25° et +25°), pour un air naturel
execute store result score #y wz_nat run data get entity @s Rotation[0]
execute store result score #r wz_nat run random value -25..25
scoreboard players operation #y wz_nat += #r wz_nat
execute store result entity @s Rotation[0] float 1 run scoreboard players get #y wz_nat
