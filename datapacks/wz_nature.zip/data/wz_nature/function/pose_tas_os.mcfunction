advancement revoke @s only wz_nature:pose_tas_os
scoreboard players set #ray wz_nat 0
execute anchored eyes positioned ^ ^ ^ run function wz_nature:rayon_tas_os
