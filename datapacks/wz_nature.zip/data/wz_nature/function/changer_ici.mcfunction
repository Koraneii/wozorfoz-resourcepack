kill @e[type=item_display,tag=wz_nat_sapin,dx=0,dy=0,dz=0]
function wz_nature:habiller
