execute as @a[tag=wz_nat_cri] at @s run title @s title {text:"\ue003",font:"wozorfoz:jumpscare",color:"white"}
execute as @a[tag=wz_nat_cri] at @s run playsound minecraft:entity.enderman.scream master @s ~ ~ ~ 1 0.45
