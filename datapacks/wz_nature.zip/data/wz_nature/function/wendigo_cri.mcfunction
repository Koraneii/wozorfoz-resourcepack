# (en tant que joueur) le visage fonce vers l'écran, tremble, vire au rouge ; cris superposés ; puis noir, vertige, cœur qui bat
tag @s add wz_nat_cri
tag @s remove wz_nat_peur
title @s times 0 20 12
title @s subtitle ""
title @s title {text:"\ue001",font:"wozorfoz:jumpscare",color:"white"}
playsound minecraft:entity.ghast.scream master @s ~ ~ ~ 1 0.5
playsound minecraft:entity.enderman.scream master @s ~ ~ ~ 1 0.6
schedule function wz_nature:wendigo_cri_2 2t append
schedule function wz_nature:wendigo_cri_3 4t append
schedule function wz_nature:wendigo_cri_4 6t append
schedule function wz_nature:wendigo_cri_5 8t append
schedule function wz_nature:wendigo_cri_6 10t append
schedule function wz_nature:wendigo_cri_fin 14t append
