# (en tant que joueur trop proche) son visage surgit à l'écran, avec un cri
title @s times 0 12 10
title @s subtitle ""
title @s title {text:"\ue000",font:"wozorfoz:jumpscare",color:"white"}
playsound minecraft:entity.enderman.scream master @s ~ ~ ~ 1 0.5
playsound minecraft:entity.ghast.scream master @s ~ ~ ~ 0.6 0.6
tag @s remove wz_nat_peur
