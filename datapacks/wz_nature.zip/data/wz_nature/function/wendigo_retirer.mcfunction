# Enlève le point du wendigo le plus proche (à moins de 6 blocs)
execute as @e[type=marker,tag=wz_nat_wpoint,distance=..6,sort=nearest,limit=1] at @s run function wz_nature:wendigo_cacher
kill @e[type=marker,tag=wz_nat_wpoint,distance=..6,sort=nearest,limit=1]
tellraw @s {"text":"Point du wendigo retiré.","color":"dark_red"}
