summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_nat_animal","wz_nat_souche","wz_nat_neuf"],item_display:"fixed",view_range:1f,item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:nature_tas_os"}}}
execute as @e[type=item_display,tag=wz_nat_neuf] store result entity @s Rotation[0] float 1 run random value 0..359
tag @e[type=item_display,tag=wz_nat_neuf] remove wz_nat_neuf
