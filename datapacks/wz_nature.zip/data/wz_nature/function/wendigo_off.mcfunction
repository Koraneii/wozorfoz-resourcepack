scoreboard players set #wendigo wz_nat 0
tellraw @s {"text":"Wendigo endormi (plus d'apparitions).","color":"dark_red"}
