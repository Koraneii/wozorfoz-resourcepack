$execute positioned $(x) $(y) $(z) run tag @a[dx=$(dx),dy=$(dy),dz=$(dz)] add wz_nat_scene
