# Fait apparaître le wendigo tout de suite au point le plus proche (pour tester ; il reste une dizaine de secondes)
execute as @e[type=marker,tag=wz_nat_wpoint,tag=!wz_nat_wvisible,sort=nearest,limit=1] at @s run function wz_nature:wendigo_apparaitre
execute as @e[type=marker,tag=wz_nat_wpoint,sort=nearest,limit=1] run scoreboard players set @s wz_nat_wv 20
