# Cache toute la brume (sans la supprimer) ; brume_on la fait revenir en fondu
execute as @e[type=item_display,tag=wz_nat_brume] run data merge entity @s {start_interpolation:0,interpolation_duration:60,transformation:{scale:[0f,0f,0f]}}
scoreboard players set #brume wz_nat 0
tellraw @s {"text":"Brume cachée.","color":"dark_green"}
