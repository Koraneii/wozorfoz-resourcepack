# (en tant que point) oiseaux qui s'envolent, feuilles qui tombent, branches qui craquent de plus en plus près
scoreboard players remove @s wz_nat_wv 1
execute if score @s wz_nat_wv matches 3 run playsound minecraft:entity.parrot.fly ambient @a[distance=..48] ~ ~7 ~ 1.6 1.3
execute if score @s wz_nat_wv matches 3 run playsound minecraft:entity.bat.takeoff ambient @a[distance=..48] ~3 ~6 ~-2 1.4 0.8
execute if score @s wz_nat_wv matches 3 run particle minecraft:block{block_state:{Name:"minecraft:oak_leaves"}} ~ ~7 ~ 4 2 4 0 50
execute if score @s wz_nat_wv matches 3 run particle minecraft:white_ash ~ ~8 ~ 3 1 3 0.05 30
execute if score @s wz_nat_wv matches 2 run playsound minecraft:block.wood.break ambient @a[distance=..48] ~4 ~2 ~-3 1.3 0.55
execute if score @s wz_nat_wv matches 1 run playsound minecraft:block.wood.break ambient @a[distance=..48] ~-2 ~1 ~2 1.5 0.45
execute if score @s wz_nat_wv matches 1.. run return 0
tag @s remove wz_nat_wprep
execute if entity @a[distance=..40,gamemode=!spectator] if predicate {condition:"minecraft:random_chance",chance:0.25} run return run function wz_nature:wendigo_derriere
function wz_nature:wendigo_apparaitre
