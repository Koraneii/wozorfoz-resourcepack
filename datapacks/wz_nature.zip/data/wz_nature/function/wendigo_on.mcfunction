scoreboard players set #wendigo wz_nat 1
tellraw @s {"text":"Wendigo réveillé.","color":"dark_red"}
