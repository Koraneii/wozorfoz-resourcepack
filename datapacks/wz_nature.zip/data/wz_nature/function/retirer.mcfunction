# Retire le sapin le plus proche (à moins de 3 blocs) et sa barrière
execute as @e[type=item_display,tag=wz_nat_sapin,distance=..3,sort=nearest,limit=1] at @s run function wz_nature:retirer_ici
