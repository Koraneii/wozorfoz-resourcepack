# Enlève l'animal le plus proche (à moins de 4 blocs) et sa barrière
execute as @e[type=item_display,tag=wz_nat_animal,distance=..4,sort=nearest,limit=1] at @s run function wz_nature:retirer_ici
