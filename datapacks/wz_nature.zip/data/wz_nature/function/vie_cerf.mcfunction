execute if predicate {condition:"minecraft:random_chance",chance:0.03} store result score #a wz_nat run random value 1..5
execute if score #a wz_nat matches 1 run data merge entity @s {start_interpolation:0,interpolation_duration:40,transformation:{left_rotation:[0f,-0.1741f,0f,0.9847f]}}
execute if score #a wz_nat matches 2 run data merge entity @s {start_interpolation:0,interpolation_duration:40,transformation:{left_rotation:[0f,-0.0749f,0f,0.9972f]}}
execute if score #a wz_nat matches 3 run data merge entity @s {start_interpolation:0,interpolation_duration:40,transformation:{left_rotation:[0f,0.0f,0f,1.0f]}}
execute if score #a wz_nat matches 4 run data merge entity @s {start_interpolation:0,interpolation_duration:40,transformation:{left_rotation:[0f,0.0998f,0f,0.995f]}}
execute if score #a wz_nat matches 5 run data merge entity @s {start_interpolation:0,interpolation_duration:40,transformation:{left_rotation:[0f,0.1987f,0f,0.9801f]}}
scoreboard players set #a wz_nat 0
execute if predicate {condition:"minecraft:random_chance",chance:0.02} run playsound wozorfoz:nature.cerf_brame ambient @a[distance=..28] ~ ~ ~ 1.5 1
execute if predicate {condition:"minecraft:random_chance",chance:0.025} run playsound wozorfoz:nature.cerf_souffle ambient @a[distance=..14] ~ ~ ~ 0.8 1
