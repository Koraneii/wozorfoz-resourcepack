scoreboard players add @s wz_nat_wa 1
execute if entity @s[tag=wz_nat_wvite] run return run function wz_nature:wendigo_image
execute if score @s wz_nat_wa matches 2.. run function wz_nature:wendigo_image
execute if score @s wz_nat_wa matches 2.. run scoreboard players set @s wz_nat_wa 0
