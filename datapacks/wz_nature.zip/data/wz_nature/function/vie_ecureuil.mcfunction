execute if entity @s[tag=wz_nat_saut] run data merge entity @s {start_interpolation:0,interpolation_duration:3,transformation:{translation:[0f,0f,0f]}}
tag @s remove wz_nat_saut
execute if predicate {condition:"minecraft:random_chance",chance:0.05} run tag @s add wz_nat_bond
execute if entity @s[tag=wz_nat_bond] store result score #a wz_nat run random value 1..4
execute if entity @s[tag=wz_nat_bond] if score #a wz_nat matches 1 run data merge entity @s {start_interpolation:0,interpolation_duration:3,transformation:{left_rotation:[0f,-0.7174f,0f,0.6967f],translation:[0f,0.18f,0f]}}
execute if entity @s[tag=wz_nat_bond] if score #a wz_nat matches 2 run data merge entity @s {start_interpolation:0,interpolation_duration:3,transformation:{left_rotation:[0f,-0.3894f,0f,0.9211f],translation:[0f,0.18f,0f]}}
execute if entity @s[tag=wz_nat_bond] if score #a wz_nat matches 3 run data merge entity @s {start_interpolation:0,interpolation_duration:3,transformation:{left_rotation:[0f,0.3894f,0f,0.9211f],translation:[0f,0.18f,0f]}}
execute if entity @s[tag=wz_nat_bond] if score #a wz_nat matches 4 run data merge entity @s {start_interpolation:0,interpolation_duration:3,transformation:{left_rotation:[0f,0.7174f,0f,0.6967f],translation:[0f,0.18f,0f]}}
execute if entity @s[tag=wz_nat_bond] run tag @s add wz_nat_saut
tag @s remove wz_nat_bond
execute if predicate {condition:"minecraft:random_chance",chance:0.03} run playsound minecraft:entity.fox.ambient ambient @a[distance=..12] ~ ~ ~ 0.6 1.7
execute if predicate {condition:"minecraft:random_chance",chance:0.03} run playsound minecraft:block.cave_vines.step ambient @a[distance=..8] ~ ~ ~ 0.5 1.6
