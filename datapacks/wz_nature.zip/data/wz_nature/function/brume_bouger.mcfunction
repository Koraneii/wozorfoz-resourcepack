$data merge entity @s {start_interpolation:0,interpolation_duration:300,transformation:{translation:[$(x)f,0f,$(z)f]}}
