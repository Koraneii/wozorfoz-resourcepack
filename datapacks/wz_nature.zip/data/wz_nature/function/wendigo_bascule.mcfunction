# (en tant que point) il se dissipe devant le joueur, puis se reforme sans bruit dans son dos
execute as @e[type=item_display,tag=wz_nat_wendigo] if score @s wz_nat_wid = #id wz_nat at @s run particle minecraft:large_smoke ~ ~1.5 ~ 0.5 1.2 0.5 0.02 30
execute as @e[type=item_display,tag=wz_nat_wendigo] if score @s wz_nat_wid = #id wz_nat at @s run playsound minecraft:entity.phantom.flap hostile @a[distance=..30] ~ ~2 ~ 0.8 0.5
execute as @e[type=item_display,tag=wz_nat_wendigo] if score @s wz_nat_wid = #id wz_nat run kill @s
execute as @e[type=item_display,tag=wz_nat_wyeux] if score @s wz_nat_wid = #id wz_nat run kill @s
scoreboard players set #sol wz_nat 0
execute as @a[tag=wz_nat_cible,limit=1] at @s rotated ~ 0 positioned ^ ^ ^-5.5 run function wz_nature:wendigo_sol_haut
tag @a remove wz_nat_cible
