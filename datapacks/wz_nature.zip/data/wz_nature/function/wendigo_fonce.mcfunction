# (en tant que corps) charge vers le joueur : environ 5 blocs/s, jambes affolées, pas qui martèlent
scoreboard players add @s wz_nat_wt 1
scoreboard players operation #id wz_nat = @s wz_nat_wid
execute if score @s wz_nat_wt matches ..0 run return 0
execute if score @s wz_nat_wt matches 1 run playsound minecraft:entity.ravager.roar hostile @a[distance=..30] ~ ~2.5 ~ 1.3 0.6
execute if entity @a[distance=..1.8,gamemode=!spectator] run return run function wz_nature:wendigo_fonce_contact
execute if score @s wz_nat_wt matches 40.. run return run function wz_nature:wendigo_fonce_perdu
execute unless entity @a[distance=..24,gamemode=!spectator] run return run function wz_nature:wendigo_fonce_perdu
execute if entity @s[tag=!wz_nat_wbond] facing entity @p[gamemode=!spectator] feet rotated ~ 0 run tp @s ^ ^ ^0.5
execute if entity @s[tag=wz_nat_wbond] facing entity @p[gamemode=!spectator] feet rotated ~ 0 run tp @s ^ ^ ^0.9
execute at @s unless block ~ ~-0.5 ~ #minecraft:replaceable run tp @s ~ ~1 ~
execute at @s if block ~ ~-1.5 ~ #minecraft:replaceable run tp @s ~ ~-1 ~
execute at @s facing entity @p[gamemode=!spectator] feet rotated ~-90 0 run tp @s ~ ~ ~ ~ 0
tag @s add wz_nat_wcourant
execute as @e[type=item_display,tag=wz_nat_wyeux] if score @s wz_nat_wid = #id wz_nat run tp @s @e[type=item_display,tag=wz_nat_wcourant,limit=1]
tag @s remove wz_nat_wcourant
function wz_nature:wendigo_image
scoreboard players operation #m wz_nat = @s wz_nat_wt
scoreboard players set #trois wz_nat 3
scoreboard players operation #m wz_nat %= #trois wz_nat
execute if score #m wz_nat matches 0 at @s run playsound minecraft:entity.warden.step hostile @a[distance=..30] ~ ~ ~ 1.8 0.8
