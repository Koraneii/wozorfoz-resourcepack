# Enlève le point d'ambiance le plus proche (à moins de 4 blocs)
kill @e[type=marker,tag=wz_nat_amb,distance=..4,sort=nearest,limit=1]
tellraw @s {"text":"Point d'ambiance retiré.","color":"dark_green"}
