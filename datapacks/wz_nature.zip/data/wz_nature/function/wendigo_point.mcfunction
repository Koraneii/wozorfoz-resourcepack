# (en tant que point du wendigo)
execute if score #wendigo wz_nat matches 0 if entity @s[tag=wz_nat_wvisible] run return run function wz_nature:wendigo_cacher
execute if score #wendigo wz_nat matches 0 run return 0
execute if entity @s[tag=wz_nat_wvisible] run return run function wz_nature:wendigo_visible
execute if score @s wz_nat_wc matches 1.. run scoreboard players remove @s wz_nat_wc 1
execute if score @s wz_nat_wc matches 1.. run return 0
execute unless predicate {condition:"minecraft:time_check",value:{min:12500,max:23500},period:24000} run return 0
execute if entity @a[distance=..16,gamemode=!spectator] run return 0
execute unless entity @a[distance=..48,gamemode=!spectator] run return 0
execute if predicate {condition:"minecraft:random_chance",chance:0.12} run function wz_nature:wendigo_apparaitre
