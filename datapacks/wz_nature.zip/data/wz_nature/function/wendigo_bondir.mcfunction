# (en tant que corps qui guettait) bond immédiat, plus rapide que la charge (environ 9 blocs/s)
tag @a remove wz_nat_vu
tag @s remove wz_nat_wderriere
tag @s add wz_nat_wfonce
tag @s add wz_nat_wbond
data merge entity @s {teleport_duration:2}
execute as @e[type=item_display,tag=wz_nat_wyeux] if score @s wz_nat_wid = #id wz_nat run data merge entity @s {teleport_duration:2}
scoreboard players set @s wz_nat_wt 0
