execute if entity @s[tag=wz_nat_fouille] run data merge entity @s {start_interpolation:0,interpolation_duration:12,transformation:{left_rotation:[0f,0.0f,0f,1.0f]}}
tag @s remove wz_nat_fouille
execute if predicate {condition:"minecraft:random_chance",chance:0.025} store result score #a wz_nat run random value 1..3
execute if score #a wz_nat matches 1 run data merge entity @s {start_interpolation:0,interpolation_duration:30,transformation:{left_rotation:[0f,-0.1494f,0f,0.9888f]}}
execute if score #a wz_nat matches 2 run data merge entity @s {start_interpolation:0,interpolation_duration:30,transformation:{left_rotation:[0f,0.0f,0f,1.0f]}}
execute if score #a wz_nat matches 3 run data merge entity @s {start_interpolation:0,interpolation_duration:30,transformation:{left_rotation:[0f,0.1494f,0f,0.9888f]}}
scoreboard players set #a wz_nat 0
execute if predicate {condition:"minecraft:random_chance",chance:0.05} run tag @s add wz_nat_grogne
execute if entity @s[tag=wz_nat_grogne] run playsound wozorfoz:nature.sanglier ambient @a[distance=..20] ~ ~ ~ 1 1
execute if entity @s[tag=wz_nat_grogne] run data merge entity @s {start_interpolation:0,interpolation_duration:8,transformation:{left_rotation:[0f,0f,-0.065f,0.9979f]}}
execute if entity @s[tag=wz_nat_grogne] run tag @s add wz_nat_fouille
tag @s remove wz_nat_grogne
execute if predicate {condition:"minecraft:random_chance",chance:0.02} run playsound minecraft:entity.sniffer.digging ambient @a[distance=..10] ~ ~ ~ 0.6 1.2
