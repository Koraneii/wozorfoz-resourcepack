# (en tant que corps, dans le dos du joueur) immobile ; s'il se retourne vers lui, c'est fini ; sinon il s'efface sans bruit au bout de 15 s
scoreboard players add @s wz_nat_wt 1
execute unless entity @a[distance=..14,gamemode=!spectator] run return run scoreboard players set #cacher wz_nat 2
execute if score @s wz_nat_wt matches 15.. run return run scoreboard players set #cacher wz_nat 2
execute at @s facing entity @p[gamemode=!spectator] feet rotated ~-90 0 run tp @s ~ ~ ~ ~ 0
tag @s add wz_nat_wcourant
execute as @e[type=item_display,tag=wz_nat_wyeux] if score @s wz_nat_wid = #id wz_nat run tp @s @e[type=item_display,tag=wz_nat_wcourant,limit=1]
execute as @a[distance=..14,gamemode=!spectator] at @s anchored eyes positioned ^ ^ ^5 if entity @e[type=item_display,tag=wz_nat_wcourant,distance=..2.8] run tag @s add wz_nat_peur
tag @s remove wz_nat_wcourant
execute if entity @a[tag=wz_nat_peur] run return run scoreboard players set #cacher wz_nat 1
execute if predicate {condition:"minecraft:random_chance",chance:0.1} at @s run playsound minecraft:entity.horse.breathe hostile @a[distance=..8] ~ ~2.8 ~ 0.4 0.45
