tp @s ~ ~ ~ ~45 0
execute if entity @s[tag=wz_nat_hibou] as @e[type=item_display,tag=wz_nat_hibou_tete,distance=..0.3] run tp @s ~ ~ ~ ~45 0
