execute as @a[tag=wz_nat_cri] at @s run title @s title {text:"\ue004",font:"wozorfoz:jumpscare",color:"white"}
