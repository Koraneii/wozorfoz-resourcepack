execute if block ~ ~ ~ barrier align xyz if entity @e[type=item_display,tag=wz_nat_sapin,dx=0,dy=0,dz=0] run return run function wz_nature:changer_ici
scoreboard players add #ray wz_nat 1
execute if score #ray wz_nat matches ..120 positioned ^ ^ ^0.05 run function wz_nature:changer_rayon
