execute as @a[tag=wz_nat_cri] at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 0.9
