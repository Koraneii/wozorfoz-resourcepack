# il vous atteint : screamer immédiat (et une chance sur deux d'être emporté)
tag @p[distance=..2.5,gamemode=!spectator] add wz_nat_peur
function wz_nature:wendigo_cri_differe
scoreboard players set #cacher wz_nat 1
execute as @e[type=marker,tag=wz_nat_wpoint] if score @s wz_nat_wid = #id wz_nat at @s run function wz_nature:wendigo_cacher
