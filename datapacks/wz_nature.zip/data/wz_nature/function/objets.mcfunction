give @s barrier[item_model="wozorfoz:animal_cerf",item_name={text:"Cerf",color:"dark_green"}] 4
give @s barrier[item_model="wozorfoz:animal_biche",item_name={text:"Biche",color:"dark_green"}] 4
give @s barrier[item_model="wozorfoz:animal_sanglier",item_name={text:"Sanglier",color:"dark_green"}] 4
give @s barrier[item_model="wozorfoz:animal_hibou",item_name={text:"Hibou (sur une branche, un toit…)",color:"dark_green"}] 4
give @s barrier[item_model="wozorfoz:animal_ecureuil",item_name={text:"Écureuil",color:"dark_green"}] 4
give @s barrier[item_model="wozorfoz:nature_souche_moussue",item_name={text:"Souche moussue",color:"dark_green"}] 8
give @s barrier[item_model="wozorfoz:nature_souche_coupee",item_name={text:"Souche coupée",color:"dark_green"}] 8
give @s barrier[item_model="wozorfoz:nature_souche_creuse",item_name={text:"Souche creuse",color:"dark_green"}] 8
tellraw @s [{"text":"Animaux : ","color":"dark_green","bold":true},{"text":"pose la barrière à l'endroit des pattes, en regardant l'endroit d'où on les verra : l'animal se tourne vers toi (avec un léger écart au hasard). Le hibou se pose sur une branche, une clôture ou un toit. Tourner de 45° : /function wz_nature:tourner (le plus proche) ; enlever : /function wz_nature:retirer.","color":"gray","bold":false}]
