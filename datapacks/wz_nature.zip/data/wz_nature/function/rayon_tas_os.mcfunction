execute if block ~ ~ ~ barrier align xyz unless entity @e[type=item_display,tag=wz_nat_animal,dx=0,dy=0,dz=0] run return run function wz_nature:habiller_tas_os
scoreboard players add #ray wz_nat 1
execute if score #ray wz_nat matches ..140 positioned ^ ^ ^0.05 run function wz_nature:rayon_tas_os
