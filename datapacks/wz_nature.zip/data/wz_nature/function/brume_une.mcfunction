summon item_display ~ ~ ~ {Tags:["wz_nat_brume","wz_nat_bneuve"],item_display:"fixed",view_range:1.5f,item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:nature_brume"}}}
execute as @e[type=item_display,tag=wz_nat_bneuve] run function wz_nature:brume_placer
scoreboard players remove #n wz_nat 1
execute if score #n wz_nat matches 1.. run function wz_nature:brume_une
