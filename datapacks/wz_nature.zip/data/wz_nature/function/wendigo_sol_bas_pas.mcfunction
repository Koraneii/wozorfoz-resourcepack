scoreboard players add #sol wz_nat 1
function wz_nature:wendigo_sol_bas
