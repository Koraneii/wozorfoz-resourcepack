execute if predicate {condition:"minecraft:random_chance",chance:0.07} store result score #a wz_nat run random value 1..7
execute if score #a wz_nat matches 1 run data merge entity @s {start_interpolation:0,interpolation_duration:10,transformation:{left_rotation:[0f,-0.6052f,0f,0.7961f]}}
execute if score #a wz_nat matches 2 run data merge entity @s {start_interpolation:0,interpolation_duration:10,transformation:{left_rotation:[0f,-0.3429f,0f,0.9394f]}}
execute if score #a wz_nat matches 3 run data merge entity @s {start_interpolation:0,interpolation_duration:10,transformation:{left_rotation:[0f,-0.1494f,0f,0.9888f]}}
execute if score #a wz_nat matches 4 run data merge entity @s {start_interpolation:0,interpolation_duration:10,transformation:{left_rotation:[0f,0.0f,0f,1.0f]}}
execute if score #a wz_nat matches 5 run data merge entity @s {start_interpolation:0,interpolation_duration:10,transformation:{left_rotation:[0f,0.1494f,0f,0.9888f]}}
execute if score #a wz_nat matches 6 run data merge entity @s {start_interpolation:0,interpolation_duration:10,transformation:{left_rotation:[0f,0.3429f,0f,0.9394f]}}
execute if score #a wz_nat matches 7 run data merge entity @s {start_interpolation:0,interpolation_duration:10,transformation:{left_rotation:[0f,0.6052f,0f,0.7961f]}}
scoreboard players set #a wz_nat 0
