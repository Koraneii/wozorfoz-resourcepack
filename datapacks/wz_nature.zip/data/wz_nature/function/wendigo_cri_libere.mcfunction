tag @a remove wz_nat_cri
