scoreboard players set #amb wz_nat 1
execute as @e[type=marker,tag=wz_nat_amb] run scoreboard players operation @s wz_nat_amb = @s wz_nat_amb_d
tellraw @s {"text":"Ambiances (forêt et eau) remises.","color":"dark_green"}
