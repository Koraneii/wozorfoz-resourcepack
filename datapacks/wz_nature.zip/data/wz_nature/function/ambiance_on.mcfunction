scoreboard players set #amb wz_nat 1
execute as @e[type=marker,tag=wz_nat_amb] run scoreboard players set @s wz_nat_amb 59
tellraw @s {"text":"Ambiance de forêt remise.","color":"dark_green"}
