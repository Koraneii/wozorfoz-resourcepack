execute as @a[tag=wz_nat_cri] at @s run title @s title {text:"\ue000",font:"wozorfoz:jumpscare",color:"white"}
execute as @a[tag=wz_nat_cri] at @s run playsound minecraft:entity.warden.roar master @s ~ ~ ~ 0.7 1.4
