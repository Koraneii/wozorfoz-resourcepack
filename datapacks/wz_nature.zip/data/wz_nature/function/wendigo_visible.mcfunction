# (en tant que point) le wendigo marche vers le joueur le plus proche et s'évanouit s'il arrive à moins de 2 blocs, ou au bout de 40 s
scoreboard players add @s wz_nat_wv 1
scoreboard players operation #id wz_nat = @s wz_nat_wid
scoreboard players set #cacher wz_nat 0
execute as @e[type=item_display,tag=wz_nat_wendigo,tag=!wz_nat_wderriere] if score @s wz_nat_wid = #id wz_nat at @s run function wz_nature:wendigo_marche
execute as @e[type=item_display,tag=wz_nat_wderriere] if score @s wz_nat_wid = #id wz_nat at @s run function wz_nature:wendigo_guette
execute unless entity @e[type=item_display,tag=wz_nat_wendigo] run scoreboard players set #cacher wz_nat 1
execute if score #cacher wz_nat matches 1.. run return run function wz_nature:wendigo_cacher
execute if score @s wz_nat_wv matches 40.. run return run function wz_nature:wendigo_cacher
