scoreboard players add @s wz_nat_wv 1
execute if entity @a[distance=..14,gamemode=!spectator] run return run function wz_nature:wendigo_cacher
execute if score @s wz_nat_wv matches 30.. run return run function wz_nature:wendigo_cacher
# il fixe le joueur le plus proche (rotation lissée sur 1 s)
execute as @e[type=item_display,distance=..1.5] if entity @s[tag=wz_nat_wendigo] at @s facing entity @p[gamemode=!spectator] feet rotated ~-90 0 run tp @s ~ ~ ~ ~ 0
execute as @e[type=item_display,distance=..1.5] if entity @s[tag=wz_nat_wyeux] at @s facing entity @p[gamemode=!spectator] feet rotated ~-90 0 run tp @s ~ ~ ~ ~ 0
execute if predicate {condition:"minecraft:random_chance",chance:0.2} run playsound minecraft:entity.horse.breathe hostile @a[distance=..40] ~ ~2.8 ~ 1.8 0.45
execute if predicate {condition:"minecraft:random_chance",chance:0.06} run playsound minecraft:entity.warden.sniff hostile @a[distance=..30] ~ ~2.8 ~ 1.2 0.6
