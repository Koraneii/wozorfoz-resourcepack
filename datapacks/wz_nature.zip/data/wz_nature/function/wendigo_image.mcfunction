scoreboard players add @s wz_nat_wf 1
execute if score @s wz_nat_wf matches 4.. run scoreboard players set @s wz_nat_wf 0
execute if score @s wz_nat_wf matches 0 run item replace entity @s contents with paper[item_model="wozorfoz:nature_wendigo_m1"]
execute if score @s wz_nat_wf matches 1 run item replace entity @s contents with paper[item_model="wozorfoz:nature_wendigo"]
execute if score @s wz_nat_wf matches 2 run item replace entity @s contents with paper[item_model="wozorfoz:nature_wendigo_m2"]
execute if score @s wz_nat_wf matches 3 run item replace entity @s contents with paper[item_model="wozorfoz:nature_wendigo"]
