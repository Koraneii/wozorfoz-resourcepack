# Regardez le pied d'un sapin (à moins de 6 blocs) : il change de forme, de taille et d'orientation
scoreboard players set #ray wz_nat 0
execute anchored eyes positioned ^ ^ ^ run function wz_nature:changer_rayon
