# le joueur s'est enfui : il s'efface sans bruit
scoreboard players set #cacher wz_nat 2
execute as @e[type=marker,tag=wz_nat_wpoint] if score @s wz_nat_wid = #id wz_nat at @s run function wz_nature:wendigo_cacher
