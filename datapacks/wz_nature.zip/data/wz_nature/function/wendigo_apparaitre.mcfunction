summon item_display ~ ~0.5 ~ {Tags:["wz_nat_wendigo","wz_nat_wneuf"],item_display:"fixed",view_range:2f,teleport_duration:20,item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:nature_wendigo"}}}
summon item_display ~ ~0.5 ~ {Tags:["wz_nat_wyeux","wz_nat_wneuf"],item_display:"fixed",view_range:2f,teleport_duration:20,brightness:{sky:15,block:15},item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:nature_wendigo_yeux"}}}
scoreboard players operation @e[type=item_display,tag=wz_nat_wneuf] wz_nat_wid = @s wz_nat_wid
execute as @e[type=item_display,tag=wz_nat_wneuf] at @s facing entity @p[gamemode=!spectator] feet rotated ~-90 0 run tp @s ~ ~ ~ ~ 0
tag @e[type=item_display,tag=wz_nat_wneuf] remove wz_nat_wneuf
particle minecraft:large_smoke ~ ~1.5 ~ 0.5 1.2 0.5 0.01 25
particle minecraft:ash ~ ~2 ~ 1 1.5 1 0 60
playsound minecraft:entity.warden.ambient hostile @a[distance=..48] ~ ~2.5 ~ 1.4 0.7
tag @s add wz_nat_wvisible
scoreboard players set @s wz_nat_wv 0
