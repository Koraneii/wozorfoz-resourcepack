execute as @e[type=item_display,tag=wz_nat_brume] run data merge entity @s {start_interpolation:0,interpolation_duration:60,transformation:{scale:[1f,1f,1f]}}
scoreboard players set #brume wz_nat 1
tellraw @s {"text":"Brume revenue.","color":"dark_green"}
