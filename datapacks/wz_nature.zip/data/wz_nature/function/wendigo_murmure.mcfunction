scoreboard players add @s wz_nat_wm 1
execute at @s as @p[distance=..48,gamemode=!spectator] run title @s actionbar [{text:"…",color:"dark_gray",italic:true},{selector:"@s",color:"gray",italic:true},{text:"…",color:"dark_gray",italic:true}]
execute at @s as @p[distance=..48,gamemode=!spectator] at @s run playsound minecraft:entity.vex.ambient hostile @s ~ ~ ~ 0.5 0.5
