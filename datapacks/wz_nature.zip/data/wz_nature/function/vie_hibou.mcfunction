# hululement, seulement la nuit (environ toutes les 30 s)
execute if predicate {condition:"minecraft:time_check",value:{min:12500,max:23500},period:24000} if predicate {condition:"minecraft:random_chance",chance:0.035} run playsound wozorfoz:nature.hibou ambient @a[distance=..28] ~ ~ ~ 1.6 1
