advancement revoke @s only wz_nature:pose_sanglier
scoreboard players set #ray wz_nat 0
execute anchored eyes positioned ^ ^ ^ run function wz_nature:rayon_sanglier
