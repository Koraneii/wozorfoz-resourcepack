# Montre les points d'ambiance (invisibles) par des particules, pendant quelques secondes
execute at @e[type=marker,tag=wz_nat_amb] run particle minecraft:happy_villager ~ ~ ~ 0.4 1 0.4 0 40 force @s
