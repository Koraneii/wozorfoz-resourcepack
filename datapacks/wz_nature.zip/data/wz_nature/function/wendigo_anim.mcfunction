schedule function wz_nature:wendigo_anim 5t replace
# une image toutes les 10 ticks en marche normale, toutes les 5 ticks quand il se rapproche (12 blocs) et charge
execute as @e[type=item_display,tag=wz_nat_wendigo,tag=!wz_nat_wderriere] run function wz_nature:wendigo_cadence
