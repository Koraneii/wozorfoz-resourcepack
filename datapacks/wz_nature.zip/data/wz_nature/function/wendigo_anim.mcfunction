schedule function wz_nature:wendigo_anim 10t replace
execute as @e[type=item_display,tag=wz_nat_wendigo,tag=!wz_nat_wderriere] run function wz_nature:wendigo_image
