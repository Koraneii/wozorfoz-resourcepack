schedule function wz_nature:wendigo_anim 5t replace
execute as @e[type=item_display,tag=wz_nat_wendigo] run function wz_nature:wendigo_image
