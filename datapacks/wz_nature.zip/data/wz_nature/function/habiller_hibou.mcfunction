# (au coin du bloc barrière, avec la rotation du joueur) : l'animal tourne la tête vers le joueur
execute rotated ~90 0 run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_nat_animal","wz_nat_hibou","wz_nat_neuf"],item_display:"fixed",view_range:0.6f,item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:animal_hibou"}}}
execute rotated ~90 0 as @e[type=item_display,tag=wz_nat_neuf] run tp @s ~0.5 ~0.5 ~0.5 ~ 0
execute as @e[type=item_display,tag=wz_nat_neuf] run function wz_nature:ecart
summon item_display ~0.5 ~0.5 ~0.5 {Tags:["wz_nat_hibou_tete","wz_nat_part","wz_nat_tete_neuve"],item_display:"fixed",view_range:0.6f,item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"wozorfoz:animal_hibou_tete"}}}
data modify entity @e[type=item_display,tag=wz_nat_tete_neuve,limit=1] Rotation set from entity @e[type=item_display,tag=wz_nat_neuf,limit=1] Rotation
tag @e[type=item_display,tag=wz_nat_tete_neuve] remove wz_nat_tete_neuve
tag @e[type=item_display,tag=wz_nat_neuf] remove wz_nat_neuf
