scoreboard objectives add wz_nat dummy
