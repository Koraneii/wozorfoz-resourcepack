scoreboard objectives add wz_nat dummy
scoreboard objectives add wz_nat_amb dummy
schedule function wz_nature:boucle 20t replace
