scoreboard objectives add wz_nat dummy
schedule function wz_nature:boucle 20t replace
