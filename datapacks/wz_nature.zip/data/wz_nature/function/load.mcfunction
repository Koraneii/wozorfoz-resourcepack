scoreboard objectives add wz_nat dummy
scoreboard objectives add wz_nat_amb dummy
scoreboard objectives add wz_nat_amb_d dummy
scoreboard objectives add wz_nat_wc dummy
scoreboard objectives add wz_nat_wv dummy
scoreboard objectives add wz_nat_wid dummy
scoreboard objectives add wz_nat_wf dummy
execute as @e[type=marker,tag=wz_nat_wpoint] unless score @s wz_nat_wid matches 1.. run function wz_nature:wendigo_id
kill @e[type=item_display,tag=wz_nat_wendigo]
kill @e[type=item_display,tag=wz_nat_wyeux]
tag @e[type=marker,tag=wz_nat_wpoint] remove wz_nat_wvisible
# anciens points d'ambiance (forêt) : durée de boucle et type
execute as @e[type=marker,tag=wz_nat_amb,tag=!wz_nat_amb_eau] unless score @s wz_nat_amb_d matches 1.. run scoreboard players set @s wz_nat_amb_d 60
execute as @e[type=marker,tag=wz_nat_amb,tag=!wz_nat_amb_eau] run tag @s add wz_nat_amb_nuit
execute as @e[type=marker,tag=wz_nat_amb,tag=!wz_nat_amb_eau] run data merge entity @s {data:{son:"ambiance_nuit"}}
schedule function wz_nature:boucle 20t replace
schedule function wz_nature:wendigo_anim 5t replace
