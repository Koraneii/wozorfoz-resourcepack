scoreboard objectives add wz_nat dummy
scoreboard objectives add wz_nat_amb dummy
scoreboard objectives add wz_nat_amb_d dummy
scoreboard objectives add wz_nat_wc dummy
scoreboard objectives add wz_nat_wv dummy
# anciens points d'ambiance (forêt) : durée de boucle et type
execute as @e[type=marker,tag=wz_nat_amb,tag=!wz_nat_amb_eau] unless score @s wz_nat_amb_d matches 1.. run scoreboard players set @s wz_nat_amb_d 60
execute as @e[type=marker,tag=wz_nat_amb,tag=!wz_nat_amb_eau] run tag @s add wz_nat_amb_nuit
execute as @e[type=marker,tag=wz_nat_amb,tag=!wz_nat_amb_eau] run data merge entity @s {data:{son:"ambiance_nuit"}}
schedule function wz_nature:boucle 20t replace
