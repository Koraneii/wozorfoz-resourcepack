execute if entity @s[tag=wz_nat_cerf] run function wz_nature:vie_cerf
execute if entity @s[tag=wz_nat_biche] run function wz_nature:vie_biche
execute if entity @s[tag=wz_nat_sanglier] run function wz_nature:vie_sanglier
execute if entity @s[tag=wz_nat_hibou] run function wz_nature:vie_hibou
execute if entity @s[tag=wz_nat_ecureuil] run function wz_nature:vie_ecureuil
