execute if block ~ ~-1 ~ #minecraft:replaceable if score #sol wz_nat matches ..6 positioned ~ ~-1 ~ run return run function wz_nature:wendigo_sol_bas_pas
function wz_nature:wendigo_poser_derriere
