kill @e[type=item_display,tag=wz_nat_hibou_tete,distance=..0.3]
execute if block ~ ~ ~ barrier run setblock ~ ~ ~ air
kill @s
