schedule function wz_nature:wendigo_fonce_boucle 2t replace
execute as @e[type=item_display,tag=wz_nat_wfonce] at @s run function wz_nature:wendigo_fonce
