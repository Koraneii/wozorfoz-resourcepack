# 1,5 s après sa disparition : quand on croit que c'est fini. Une fois sur deux, il emporte le joueur.
execute as @a[tag=wz_nat_peur,gamemode=!creative] if predicate {condition:"minecraft:random_chance",chance:0.5} run tag @s add wz_nat_proie
execute as @a[tag=wz_nat_peur] at @s run function wz_nature:wendigo_cri
execute if entity @a[tag=wz_nat_proie] run schedule function wz_nature:wendigo_emporter 12t append
