# 1,5 s après sa disparition : quand on croit que c'est fini
execute as @a[tag=wz_nat_peur] at @s run function wz_nature:wendigo_cri
