# Usage : /function wz_nature:brume_retirer {rayon:10}   (enlève les nappes autour de vous)
$kill @e[type=item_display,tag=wz_nat_brume,distance=..$(rayon)]
tellraw @s {"text":"Brume retirée autour de vous.","color":"dark_green"}
