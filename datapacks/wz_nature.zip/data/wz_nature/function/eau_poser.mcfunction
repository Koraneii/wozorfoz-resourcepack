# Usage : /function wz_nature:eau_poser {rayon:24}
# Pose un point d'ambiance (ruisseau) là où vous êtes ; il s'entend jusqu'à environ <rayon> blocs.
summon marker ~ ~1 ~ {Tags:["wz_nat_amb","wz_nat_amb_eau","wz_nat_amb_neuf"]}
$data merge entity @e[type=marker,tag=wz_nat_amb_neuf,limit=1] {data:{rayon:$(rayon),son:"ambiance_eau"}}
scoreboard players set @e[type=marker,tag=wz_nat_amb_neuf] wz_nat_amb_d 18
execute as @e[type=marker,tag=wz_nat_amb_neuf] run function wz_nature:ambiance_regler
$tellraw @s {"text":"Point d'ambiance « ruisseau » posé (rayon $(rayon) blocs).","color":"dark_green"}
