$playsound wozorfoz:nature.$(son) ambient @a[distance=..$(rayon),tag=!wz_nat_scene] ~ ~ ~ $(volume) 1
