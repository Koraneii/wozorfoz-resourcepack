$playsound wozorfoz:nature.ambiance_nuit ambient @a[distance=..$(rayon)] ~ ~ ~ $(volume) 1
