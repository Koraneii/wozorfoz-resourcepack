$playsound wozorfoz:nature.ambiance_nuit ambient @a[distance=..$(rayon),tag=!wz_nat_scene] ~ ~ ~ $(volume) 1
