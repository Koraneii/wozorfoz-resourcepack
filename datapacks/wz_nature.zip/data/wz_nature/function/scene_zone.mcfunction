execute store result score #v wz_nat run data get storage wz_drapeau:scene bx
execute store result storage wz_nature:zone x int 1 run scoreboard players remove #v wz_nat 2
execute store result score #v wz_nat run data get storage wz_drapeau:scene by
execute store result storage wz_nature:zone y int 1 run scoreboard players remove #v wz_nat 2
execute store result score #v wz_nat run data get storage wz_drapeau:scene bz
execute store result storage wz_nature:zone z int 1 run scoreboard players remove #v wz_nat 2
execute store result score #v wz_nat run data get storage wz_drapeau:scene dx
execute store result storage wz_nature:zone dx int 1 run scoreboard players add #v wz_nat 4
execute store result score #v wz_nat run data get storage wz_drapeau:scene dy
execute store result storage wz_nature:zone dy int 1 run scoreboard players add #v wz_nat 6
execute store result score #v wz_nat run data get storage wz_drapeau:scene dz
execute store result storage wz_nature:zone dz int 1 run scoreboard players add #v wz_nat 4
function wz_nature:scene_marquer with storage wz_nature:zone
