execute store result score #p wz_nat run data get entity @s Pos[0] 100
execute store result score #d wz_nat run random value -100..100
scoreboard players operation #d wz_nat *= #rb wz_nat
scoreboard players operation #p wz_nat += #d wz_nat
execute store result entity @s Pos[0] double 0.01 run scoreboard players get #p wz_nat
execute store result score #p wz_nat run data get entity @s Pos[2] 100
execute store result score #d wz_nat run random value -100..100
scoreboard players operation #d wz_nat *= #rb wz_nat
scoreboard players operation #p wz_nat += #d wz_nat
execute store result entity @s Pos[2] double 0.01 run scoreboard players get #p wz_nat
execute store result score #p wz_nat run data get entity @s Pos[1] 100
execute store result score #d wz_nat run random value 15..150
scoreboard players operation #p wz_nat += #d wz_nat
execute store result entity @s Pos[1] double 0.01 run scoreboard players get #p wz_nat
execute store result entity @s Rotation[0] float 1 run random value 0..359
execute store result score #d wz_nat run random value 1..3
execute if score #d wz_nat matches 1 run data merge entity @s {transformation:{scale:[0.75f,1f,0.75f]}}
execute if score #d wz_nat matches 3 run data merge entity @s {transformation:{scale:[1.25f,1f,1.25f]}}
tag @s remove wz_nat_bneuve
