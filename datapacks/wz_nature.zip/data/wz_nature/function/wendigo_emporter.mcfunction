execute as @a[tag=wz_nat_proie] at @s run particle minecraft:large_smoke ~ ~1 ~ 0.4 0.8 0.4 0.02 30
# (le message de mort habituel est masqué le temps d'afficher le nôtre)
gamerule showDeathMessages false
execute as @a[tag=wz_nat_proie] run tellraw @a [{selector:"@s",color:"gray"},{text:" a été emporté par le wendigo",color:"dark_red"}]
execute as @a[tag=wz_nat_proie] run kill @s
gamerule showDeathMessages true
tag @a remove wz_nat_proie
