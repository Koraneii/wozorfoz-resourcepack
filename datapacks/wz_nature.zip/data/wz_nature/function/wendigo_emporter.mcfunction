execute as @a[tag=wz_nat_proie] at @s run particle minecraft:large_smoke ~ ~1 ~ 0.4 0.8 0.4 0.02 30
execute as @a[tag=wz_nat_proie] run damage @s 1000 wz_nature:wendigo
tag @a remove wz_nat_proie
