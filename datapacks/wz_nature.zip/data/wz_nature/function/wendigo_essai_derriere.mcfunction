# Fait apparaître le wendigo dans votre dos tout de suite (pour tester)
execute at @s as @e[type=marker,tag=wz_nat_wpoint,tag=!wz_nat_wvisible,sort=nearest,limit=1] run function wz_nature:wendigo_derriere
