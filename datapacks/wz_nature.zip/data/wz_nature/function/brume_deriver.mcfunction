# (en tant que nappe) dérive doucement vers un point voisin (15 s)
execute store result storage wz_nature:derive x float 0.015 run random value -100..100
execute store result storage wz_nature:derive z float 0.015 run random value -100..100
function wz_nature:brume_bouger with storage wz_nature:derive
