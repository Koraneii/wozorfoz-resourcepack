execute as @a[tag=wz_nat_cri] run title @s title {text:"\ue000",font:"wozorfoz:jumpscare",color:"white"}
effect give @a[tag=wz_nat_cri] minecraft:blindness 2 0 true
effect give @a[tag=wz_nat_cri] minecraft:nausea 5 0 true
effect give @a[tag=wz_nat_cri] minecraft:darkness 6 0 true
execute as @a[tag=wz_nat_cri] at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 0.9
schedule function wz_nature:wendigo_coeur 20t append
schedule function wz_nature:wendigo_coeur 36t append
schedule function wz_nature:wendigo_coeur 52t append
schedule function wz_nature:wendigo_cri_libere 60t append
