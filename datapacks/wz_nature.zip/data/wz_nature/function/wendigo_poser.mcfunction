# Pose un point d'apparition du wendigo là où vous êtes (de préférence au loin, entre les arbres, à plus de 20 blocs des chemins)
summon marker ~ ~ ~ {Tags:["wz_nat_wpoint","wz_nat_wneuf_p"]}
execute as @e[type=marker,tag=wz_nat_wneuf_p] run function wz_nature:wendigo_id
execute as @e[type=marker,tag=wz_nat_wneuf_p] store result score @s wz_nat_wc run random value 30..90
tag @e[type=marker,tag=wz_nat_wneuf_p] remove wz_nat_wneuf_p
tellraw @s {"text":"Point du wendigo posé. Il n'apparaît que la nuit, quand quelqu'un est entre 16 et 48 blocs, et marche vers lui.","color":"dark_red"}
