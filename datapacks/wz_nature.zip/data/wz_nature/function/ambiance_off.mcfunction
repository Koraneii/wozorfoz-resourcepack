scoreboard players set #amb wz_nat 0
stopsound @a ambient wozorfoz:nature.ambiance_nuit
tellraw @s {"text":"Ambiance de forêt coupée.","color":"dark_green"}
