scoreboard players set #amb wz_nat 0
stopsound @a ambient wozorfoz:nature.ambiance_nuit
stopsound @a ambient wozorfoz:nature.ambiance_eau
tellraw @s {"text":"Ambiances (forêt et eau) coupées.","color":"dark_green"}
