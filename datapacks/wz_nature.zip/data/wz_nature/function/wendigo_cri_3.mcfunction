execute as @a[tag=wz_nat_cri] at @s run title @s title {text:"\ue002",font:"wozorfoz:jumpscare",color:"white"}
execute as @a[tag=wz_nat_cri] at @s run playsound minecraft:entity.enderman.stare master @s ~ ~ ~ 1 0.7
