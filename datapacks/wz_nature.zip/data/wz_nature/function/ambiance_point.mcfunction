# (en tant que point d'ambiance) relance la boucle de 60 s, seulement la nuit ; chaque point a son propre décalage
scoreboard players add @s wz_nat_amb 1
execute if score @s wz_nat_amb matches 60.. run scoreboard players set @s wz_nat_amb 0
execute if score @s wz_nat_amb matches 0 if predicate {condition:"minecraft:time_check",value:{min:12500,max:23500},period:24000} run function wz_nature:ambiance_jouer with entity @s data
