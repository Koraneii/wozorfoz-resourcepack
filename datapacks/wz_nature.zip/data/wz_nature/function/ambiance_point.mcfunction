# (en tant que point d'ambiance) relance sa boucle quand elle est finie ; chaque point a son propre décalage
scoreboard players add @s wz_nat_amb 1
execute if score @s wz_nat_amb >= @s wz_nat_amb_d run scoreboard players set @s wz_nat_amb 0
execute if score @s wz_nat_amb matches 0 if entity @s[tag=wz_nat_amb_nuit] if predicate {condition:"minecraft:time_check",value:{min:12500,max:23500},period:24000} run function wz_nature:ambiance_jouer with entity @s data
execute if score @s wz_nat_amb matches 0 if entity @s[tag=!wz_nat_amb_nuit] run function wz_nature:ambiance_jouer with entity @s data
execute if entity @s[tag=wz_nat_amb_eau] if predicate {condition:"minecraft:time_check",value:{min:12500,max:23500},period:24000} if predicate {condition:"minecraft:random_chance",chance:0.04} run playsound minecraft:entity.frog.ambient ambient @a[distance=..14,tag=!wz_nat_scene] ~ ~ ~ 0.5 0.9
