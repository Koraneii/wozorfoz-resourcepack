execute as @a[tag=wz_nat_cri] at @s run title @s title {text:"\ue003",font:"wozorfoz:jumpscare",color:"white"}
execute as @a[tag=wz_nat_cri] at @s run playsound minecraft:entity.ghast.hurt master @s ~ ~ ~ 1 0.5
