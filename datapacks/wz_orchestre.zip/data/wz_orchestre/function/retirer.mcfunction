function wz_orchestre:repos
kill @e[tag=wz_orch]
tellraw @s {"text":"Orchestre retiré.","color":"gold"}
