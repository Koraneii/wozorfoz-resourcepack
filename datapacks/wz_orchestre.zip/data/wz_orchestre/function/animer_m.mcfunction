$function wz_orchestre:image/$(role)_$(k)
