# Usage : /function wz_orchestre:tete {joueur:"NomDuJoueur"}  (tous les musiciens portent la tete de ce joueur)
$execute as @e[type=armor_stand,tag=wz_mus] run function wz_orchestre:tete_un {joueur:"$(joueur)"}
$tellraw @s {"text":"Les musiciens portent la tête de $(joueur).","color":"gold"}
