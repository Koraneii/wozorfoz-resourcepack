# Usage : /function wz_orchestre:chef_tete {joueur:"NomDuJoueur"}  (tete du chef d'orchestre seulement)
$execute as @e[type=armor_stand,tag=r_chef] run function wz_orchestre:tete_un {joueur:"$(joueur)"}
