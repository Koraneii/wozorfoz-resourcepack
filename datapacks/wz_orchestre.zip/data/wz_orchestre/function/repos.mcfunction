scoreboard players set #joue wz_orch 0
schedule clear wz_orchestre:boucle
function wz_orchestre:repos_poses
