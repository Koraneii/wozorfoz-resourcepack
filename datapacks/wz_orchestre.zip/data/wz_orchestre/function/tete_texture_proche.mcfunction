# Usage : /function wz_orchestre:tete_texture_proche {valeur:"eyJ0ZXh0dXJlcyI6..."}
# Tete a partir d'une valeur de texture (champ « Value » des sites de tetes) pour le musicien le plus proche (a moins de 4 blocs)
$execute as @e[type=armor_stand,tag=wz_mus,distance=..4,sort=nearest,limit=1] run function wz_orchestre:tete_un_texture {valeur:"$(valeur)"}
tellraw @s {"text":"Tête appliquée : le musicien le plus proche (a moins de 4 blocs).","color":"gold"}
