kill @e[tag=wz_orch,tag=!wz_choeur]
