# Usage : /function wz_orchestre:chef_tete_texture {valeur:"eyJ0ZXh0dXJlcyI6..."}
# Tete a partir d'une valeur de texture (champ « Value » des sites de tetes) pour le chef
$execute as @e[type=armor_stand,tag=r_chef] run function wz_orchestre:tete_un_texture {valeur:"$(valeur)"}
tellraw @s {"text":"Tête appliquée : le chef.","color":"gold"}
