# Usage : /function wz_orchestre:tete_proche {joueur:"NomDuJoueur"}  (le musicien le plus proche, a moins de 4 blocs)
$execute as @e[type=armor_stand,tag=wz_mus,distance=..4,sort=nearest,limit=1] run function wz_orchestre:tete_un {joueur:"$(joueur)"}
