# L'orchestre joue (a lancer en meme temps que la musique ; s'arrete avec wz_orchestre:repos)
scoreboard players set #joue wz_orch 1
schedule function wz_orchestre:boucle 1t replace
