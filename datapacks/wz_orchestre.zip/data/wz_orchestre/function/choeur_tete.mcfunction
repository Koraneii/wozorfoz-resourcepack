# Usage : /function wz_orchestre:choeur_tete {joueur:"NomDuJoueur"}
$execute as @e[type=armor_stand,tag=wz_choeur] run function wz_orchestre:tete_un {joueur:"$(joueur)"}
