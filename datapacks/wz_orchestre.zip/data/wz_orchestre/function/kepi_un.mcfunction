data merge entity @s {DisabledSlots:0}
item replace entity @s armor.head with leather_helmet[item_model="wozorfoz:casque",equippable={slot:"head",asset_id:"wozorfoz:musicien"}]
data merge entity @s {DisabledSlots:4144959}
