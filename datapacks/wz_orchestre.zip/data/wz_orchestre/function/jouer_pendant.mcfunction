# Usage (bloc de commande) : function wz_orchestre:jouer_pendant {s:134}
# Joue pendant s secondes puis repose les instruments (ex. 134 s : le spectacle de feux)
function wz_orchestre:jouer
$schedule function wz_orchestre:repos $(s)s replace
