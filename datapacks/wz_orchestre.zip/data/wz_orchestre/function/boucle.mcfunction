# (toutes les 2 ticks pendant que l'orchestre joue) image suivante pour chaque musicien
scoreboard players add #ph wz_orch 1
execute if score #ph wz_orch matches 16.. run scoreboard players set #ph wz_orch 0
execute as @e[type=armor_stand,tag=wz_mus,tag=r_chef] run function wz_orchestre:animer {role:"chef"}
execute as @e[type=armor_stand,tag=wz_mus,tag=r_violon] run function wz_orchestre:animer {role:"violon"}
execute as @e[type=armor_stand,tag=wz_mus,tag=r_violoncelle] run function wz_orchestre:animer {role:"violoncelle"}
execute as @e[type=armor_stand,tag=wz_mus,tag=r_harpe] run function wz_orchestre:animer {role:"harpe"}
execute as @e[type=armor_stand,tag=wz_mus,tag=r_trompette] run function wz_orchestre:animer {role:"trompette"}
execute as @e[type=armor_stand,tag=wz_mus,tag=r_cor] run function wz_orchestre:animer {role:"cor"}
execute as @e[type=armor_stand,tag=wz_mus,tag=r_timbales] run function wz_orchestre:animer {role:"timbales"}
execute as @e[type=armor_stand,tag=wz_mus,tag=r_tambour] run function wz_orchestre:animer {role:"tambour"}
execute as @e[type=armor_stand,tag=wz_mus,tag=r_piano] run function wz_orchestre:animer {role:"piano"}
execute as @e[type=armor_stand,tag=wz_mus,tag=r_choeur] run function wz_orchestre:animer {role:"choeur"}
execute if score #joue wz_orch matches 1 run schedule function wz_orchestre:boucle 2t replace
