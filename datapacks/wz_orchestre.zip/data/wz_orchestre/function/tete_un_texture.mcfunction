data merge entity @s {DisabledSlots:0}
$item replace entity @s armor.head with player_head[profile={properties:[{name:"textures",value:"$(valeur)"}]}]
data merge entity @s {DisabledSlots:4144959}
