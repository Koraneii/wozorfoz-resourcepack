# Usage : /function wz_orchestre:choeur_tete_texture {valeur:"eyJ0ZXh0dXJlcyI6..."}
# Tete a partir d'une valeur de texture (champ « Value » des sites de tetes) pour les choristes
$execute as @e[type=armor_stand,tag=wz_choeur] run function wz_orchestre:tete_un_texture {valeur:"$(valeur)"}
tellraw @s {"text":"Tête appliquée : les choristes.","color":"gold"}
