kill @e[tag=wz_choeur]
tellraw @s {"text":"Chœur retiré.","color":"gold"}
