# (en tant qu'un musicien) pose un instrument ou un pupitre devant lui, tourne vers lui
$summon item_display ^$(x) ^ ^$(z) {Tags:["wz_orch","wz_orch_objet","wz_orch_objet_neuf"],item_display:"fixed",brightness:{sky:15,block:12},item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"wozorfoz:$(modele)"}}}
rotate @e[type=item_display,tag=wz_orch_objet_neuf,limit=1] facing entity @s
$execute if score #$(modele) wz_orch matches 1 as @e[type=item_display,tag=wz_orch_objet_neuf,limit=1] at @s run rotate @s ~180 ~
execute as @e[type=item_display,tag=wz_orch_objet_neuf,limit=1] run data modify entity @s Rotation[1] set value 0f
tag @e[type=item_display,tag=wz_orch_objet_neuf] remove wz_orch_objet_neuf
