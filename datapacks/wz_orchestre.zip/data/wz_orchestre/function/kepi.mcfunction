# Remet le kepi bordeaux a tous les musiciens (a la place des visages)
execute as @e[type=armor_stand,tag=wz_mus] run function wz_orchestre:kepi_un
