# (en tant qu'un musicien) chacun a un leger decalage, pour ne pas jouer comme des automates
scoreboard players operation #k wz_orch = #ph wz_orch
scoreboard players operation #k wz_orch += @s wz_orch
scoreboard players operation #k wz_orch %= #seize wz_orch
execute store result storage wz_orchestre:t k int 1 run scoreboard players get #k wz_orch
$data modify storage wz_orchestre:t role set value "$(role)"
function wz_orchestre:animer_m with storage wz_orchestre:t
