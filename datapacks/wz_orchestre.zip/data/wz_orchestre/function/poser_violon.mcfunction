# (en tant qu'un violoniste) violon a l'horizontale sous le menton, la volute vers l'avant-gauche
execute rotated ~-50 0 positioned ^0.20 ^1.48 ^0.26 run summon item_display ~ ~ ~ {Tags:["wz_orch","wz_orch_objet","wz_violon_neuf"],item_display:"fixed",brightness:{sky:15,block:12},item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"wozorfoz:violon"}},transformation:{left_rotation:[0.7071f,0f,0f,0.7071f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.7f,0.7f,0.7f]}}
execute rotated ~-50 0 positioned ^0.20 ^1.48 ^0.26 run tp @e[type=item_display,tag=wz_violon_neuf,limit=1] ~ ~ ~ ~ 0
tag @e[type=item_display,tag=wz_violon_neuf] remove wz_violon_neuf
