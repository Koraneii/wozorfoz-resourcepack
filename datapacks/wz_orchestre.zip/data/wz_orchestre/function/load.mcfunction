scoreboard objectives add wz_orch dummy
scoreboard players set #seize wz_orch 16
scoreboard players set #pupitre_musique wz_orch 1
execute if score #joue wz_orch matches 1 run schedule function wz_orchestre:boucle 20t replace
