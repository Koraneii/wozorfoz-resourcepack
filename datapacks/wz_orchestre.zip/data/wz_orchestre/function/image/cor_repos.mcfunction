data merge entity @s {Pose:{Head:[0.0f,0.0f,0.0f],RightArm:[-35.0f,-10.0f,0.0f],LeftArm:[-30.0f,15.0f,0.0f]}}
