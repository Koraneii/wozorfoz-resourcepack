data merge entity @s {Pose:{Head:[15.0f,-25.0f,15.0f],RightArm:[-85.0f,-57.7f,0.0f],LeftArm:[-80.0f,40.0f,0.0f]}}
