data merge entity @s {Pose:{Head:[-7.8f,0.0f,0.0f],RightArm:[-132.7f,29.1f,0.0f],LeftArm:[-72.4f,-15.0f,0.0f]}}
