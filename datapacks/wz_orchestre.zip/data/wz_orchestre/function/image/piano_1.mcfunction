data merge entity @s {Pose:{Head:[20.0f,0.0f,0.0f],RightArm:[-50.1f,-2.1f,0.0f],LeftArm:[-59.9f,15.4f,0.0f]}}
