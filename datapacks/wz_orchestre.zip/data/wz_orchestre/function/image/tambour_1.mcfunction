data merge entity @s {Pose:{Head:[20.0f,0.0f,0.0f],RightArm:[-57.7f,-15.0f,0.0f],LeftArm:[-57.7f,15.0f,0.0f]}}
