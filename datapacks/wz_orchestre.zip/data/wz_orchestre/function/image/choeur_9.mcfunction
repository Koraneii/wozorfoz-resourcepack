data merge entity @s {Pose:{Head:[-9.9f,-5.7f,0.0f],RightArm:[-63.1f,-12.0f,0.0f],LeftArm:[-61.1f,14.0f,0.0f]}}
