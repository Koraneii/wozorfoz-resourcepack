data merge entity @s {Pose:{Head:[-2.2f,0.0f,0.0f],RightArm:[-97.3f,29.1f,0.0f],LeftArm:[-63.3f,-15.0f,0.0f]}}
