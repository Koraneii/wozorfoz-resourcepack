data merge entity @s {Pose:{Head:[-6.5f,0.0f,0.0f],RightArm:[-124.6f,33.5f,0.0f],LeftArm:[-68.2f,-15.0f,0.0f]}}
