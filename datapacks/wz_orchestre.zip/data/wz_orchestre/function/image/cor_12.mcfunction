data merge entity @s {Pose:{Head:[5.0f,0.0f,0.0f],RightArm:[-63.0f,-20.0f,0.0f],LeftArm:[-58.0f,25.0f,0.0f]}}
