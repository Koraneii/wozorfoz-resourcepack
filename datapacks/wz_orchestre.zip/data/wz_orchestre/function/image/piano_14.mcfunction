data merge entity @s {Pose:{Head:[20.0f,0.0f,0.0f],RightArm:[-62.0f,-8.3f,0.0f],LeftArm:[-48.0f,17.5f,0.0f]}}
