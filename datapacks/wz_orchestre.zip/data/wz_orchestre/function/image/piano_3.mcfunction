data merge entity @s {Pose:{Head:[20.0f,0.0f,0.0f],RightArm:[-50.1f,-3.4f,0.0f],LeftArm:[-59.9f,9.7f,0.0f]}}
