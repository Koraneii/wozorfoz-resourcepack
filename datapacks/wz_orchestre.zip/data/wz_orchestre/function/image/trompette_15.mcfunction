data merge entity @s {Pose:{Head:[-5.0f,0.0f,0.0f],RightArm:[-106.5f,-5.0f,0.0f],LeftArm:[-96.5f,25.0f,0.0f]}}
