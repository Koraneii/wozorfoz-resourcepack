data merge entity @s {Pose:{Head:[-8.7f,0.0f,0.0f],RightArm:[-138.1f,7.3f,0.0f],LeftArm:[-84.9f,-15.0f,0.0f]}}
