data merge entity @s {Pose:{Head:[-5.0f,0.0f,0.0f],RightArm:[-102.2f,-5.0f,0.0f],LeftArm:[-92.2f,25.0f,0.0f]}}
