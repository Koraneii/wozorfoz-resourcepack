data merge entity @s {Pose:{Head:[20.0f,0.0f,0.0f],RightArm:[-59.9f,-14.6f,0.0f],LeftArm:[-50.1f,2.0f,0.0f]}}
