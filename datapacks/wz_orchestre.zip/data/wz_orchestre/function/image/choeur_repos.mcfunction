data merge entity @s {Pose:{Head:[0.0f,0.0f,0.0f],RightArm:[-45.0f,-12.0f,0.0f],LeftArm:[-43.0f,14.0f,0.0f]}}
