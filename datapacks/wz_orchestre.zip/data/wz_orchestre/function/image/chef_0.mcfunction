data merge entity @s {Pose:{Head:[-5.0f,0.0f,0.0f],RightArm:[-115.0f,35.0f,0.0f],LeftArm:[-64.9f,-15.0f,0.0f]}}
