data merge entity @s {Pose:{Head:[-1.3f,0.0f,0.0f],RightArm:[-91.9f,22.7f,0.0f],LeftArm:[-65.1f,-15.0f,0.0f]}}
