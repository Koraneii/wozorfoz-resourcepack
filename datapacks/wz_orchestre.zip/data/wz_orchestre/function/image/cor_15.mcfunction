data merge entity @s {Pose:{Head:[5.0f,0.0f,0.0f],RightArm:[-61.1f,-20.0f,0.0f],LeftArm:[-56.1f,25.0f,0.0f]}}
