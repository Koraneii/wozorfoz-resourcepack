data merge entity @s {Pose:{Head:[20.0f,0.0f,0.0f],RightArm:[-55.0f,-16.7f,0.0f],LeftArm:[-55.0f,2.7f,0.0f]}}
