data merge entity @s {Pose:{Head:[-12.6f,-2.7f,0.0f],RightArm:[-64.8f,-12.0f,0.0f],LeftArm:[-62.8f,14.0f,0.0f]}}
