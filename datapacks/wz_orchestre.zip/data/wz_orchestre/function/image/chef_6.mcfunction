data merge entity @s {Pose:{Head:[-2.2f,0.0f,0.0f],RightArm:[-97.3f,0.9f,0.0f],LeftArm:[-77.6f,-15.0f,0.0f]}}
