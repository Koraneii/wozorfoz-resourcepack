data merge entity @s {Pose:{Head:[20.0f,0.0f,0.0f],RightArm:[-59.9f,-5.4f,0.0f],LeftArm:[-50.1f,18.0f,0.0f]}}
