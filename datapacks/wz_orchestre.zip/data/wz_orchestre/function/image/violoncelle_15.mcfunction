data merge entity @s {Pose:{Head:[15.0f,10.0f,0.0f],RightArm:[-45.0f,-26.5f,0.0f],LeftArm:[-105.0f,20.0f,0.0f]}}
