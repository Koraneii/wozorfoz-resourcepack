data merge entity @s {Pose:{Head:[-5.0f,0.0f,0.0f],RightArm:[-108.7f,-5.0f,0.0f],LeftArm:[-98.7f,25.0f,0.0f]}}
