data merge entity @s {Pose:{Head:[-5.0f,0.0f,0.0f],RightArm:[-115.0f,-5.0f,0.0f],LeftArm:[-85.1f,-15.0f,0.0f]}}
