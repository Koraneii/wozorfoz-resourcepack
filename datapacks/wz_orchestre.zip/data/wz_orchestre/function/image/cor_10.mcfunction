data merge entity @s {Pose:{Head:[5.0f,0.0f,0.0f],RightArm:[-62.1f,-20.0f,0.0f],LeftArm:[-57.1f,25.0f,0.0f]}}
