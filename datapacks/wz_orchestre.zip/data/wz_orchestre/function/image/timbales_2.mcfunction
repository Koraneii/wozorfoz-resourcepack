data merge entity @s {Pose:{Head:[15.0f,0.0f,0.0f],RightArm:[-71.2f,-15.0f,0.0f],LeftArm:[-50.0f,15.0f,0.0f]}}
