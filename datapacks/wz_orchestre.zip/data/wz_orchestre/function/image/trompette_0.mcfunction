data merge entity @s {Pose:{Head:[-5.0f,0.0f,0.0f],RightArm:[-105.0f,-5.0f,0.0f],LeftArm:[-95.0f,25.0f,0.0f]}}
