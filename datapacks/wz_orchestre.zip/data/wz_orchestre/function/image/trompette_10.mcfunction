data merge entity @s {Pose:{Head:[-5.0f,0.0f,0.0f],RightArm:[-107.8f,-5.0f,0.0f],LeftArm:[-97.8f,25.0f,0.0f]}}
