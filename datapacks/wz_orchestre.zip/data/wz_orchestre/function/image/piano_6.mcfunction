data merge entity @s {Pose:{Head:[20.0f,0.0f,0.0f],RightArm:[-62.0f,-11.7f,0.0f],LeftArm:[-48.0f,2.5f,0.0f]}}
