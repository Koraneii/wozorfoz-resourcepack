data merge entity @s {Pose:{Head:[5.0f,0.0f,0.0f],RightArm:[-58.9f,-20.0f,0.0f],LeftArm:[-53.9f,25.0f,0.0f]}}
