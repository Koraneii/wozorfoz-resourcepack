data merge entity @s {Pose:{Head:[-3.4f,-1.9f,0.0f],RightArm:[-59.2f,-12.0f,0.0f],LeftArm:[-57.2f,14.0f,0.0f]}}
