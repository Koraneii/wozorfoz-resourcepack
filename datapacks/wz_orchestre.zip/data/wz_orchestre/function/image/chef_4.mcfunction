data merge entity @s {Pose:{Head:[-1.0f,0.0f,0.0f],RightArm:[-90.0f,15.0f,0.0f],LeftArm:[-68.5f,-15.0f,0.0f]}}
