data merge entity @s {Pose:{Head:[0.0f,0.0f,0.0f],RightArm:[-20.0f,0.0f,0.0f],LeftArm:[-5.0f,0.0f,0.0f]}}
