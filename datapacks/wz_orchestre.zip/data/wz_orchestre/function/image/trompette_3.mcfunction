data merge entity @s {Pose:{Head:[-5.0f,0.0f,0.0f],RightArm:[-101.3f,-5.0f,0.0f],LeftArm:[-91.3f,25.0f,0.0f]}}
