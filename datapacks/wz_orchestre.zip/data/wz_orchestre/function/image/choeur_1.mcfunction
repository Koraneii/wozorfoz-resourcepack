data merge entity @s {Pose:{Head:[-6.1f,5.7f,0.0f],RightArm:[-60.9f,-12.0f,0.0f],LeftArm:[-58.9f,14.0f,0.0f]}}
