data merge entity @s {Pose:{Head:[10.0f,-15.0f,0.0f],RightArm:[-65.0f,-20.0f,0.0f],LeftArm:[-65.0f,25.0f,0.0f]}}
