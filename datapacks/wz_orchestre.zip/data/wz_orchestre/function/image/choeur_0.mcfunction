data merge entity @s {Pose:{Head:[-8.0f,6.0f,0.0f],RightArm:[-62.0f,-12.0f,0.0f],LeftArm:[-60.0f,14.0f,0.0f]}}
