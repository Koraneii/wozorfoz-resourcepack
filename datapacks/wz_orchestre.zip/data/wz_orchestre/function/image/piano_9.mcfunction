data merge entity @s {Pose:{Head:[20.0f,0.0f,0.0f],RightArm:[-50.1f,-17.9f,0.0f],LeftArm:[-59.9f,4.6f,0.0f]}}
