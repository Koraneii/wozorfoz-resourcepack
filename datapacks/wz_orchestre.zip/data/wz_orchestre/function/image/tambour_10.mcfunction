data merge entity @s {Pose:{Head:[20.0f,0.0f,0.0f],RightArm:[-65.0f,-15.0f,0.0f],LeftArm:[-40.0f,15.0f,0.0f]}}
