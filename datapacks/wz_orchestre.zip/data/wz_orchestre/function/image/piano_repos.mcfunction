data merge entity @s {Pose:{Head:[10.0f,0.0f,0.0f],RightArm:[-10.0f,0.0f,0.0f],LeftArm:[-10.0f,0.0f,0.0f]}}
