data merge entity @s {Pose:{Head:[10.0f,-15.0f,0.0f],RightArm:[-57.9f,-20.0f,0.0f],LeftArm:[-72.1f,25.0f,0.0f]}}
