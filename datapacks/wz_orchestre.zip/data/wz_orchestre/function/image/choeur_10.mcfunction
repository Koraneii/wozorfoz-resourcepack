data merge entity @s {Pose:{Head:[-11.5f,-4.5f,0.0f],RightArm:[-64.1f,-12.0f,0.0f],LeftArm:[-62.1f,14.0f,0.0f]}}
