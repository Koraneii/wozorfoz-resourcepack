data merge entity @s {Pose:{Head:[20.0f,0.0f,0.0f],RightArm:[-48.0f,-2.2f,0.0f],LeftArm:[-62.0f,12.8f,0.0f]}}
