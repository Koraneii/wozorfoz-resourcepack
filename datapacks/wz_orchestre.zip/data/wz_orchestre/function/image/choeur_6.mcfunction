data merge entity @s {Pose:{Head:[-4.5f,-3.9f,0.0f],RightArm:[-59.9f,-12.0f,0.0f],LeftArm:[-57.9f,14.0f,0.0f]}}
