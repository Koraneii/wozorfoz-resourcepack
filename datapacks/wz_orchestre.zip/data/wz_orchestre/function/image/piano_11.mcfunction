data merge entity @s {Pose:{Head:[20.0f,0.0f,0.0f],RightArm:[-50.1f,-16.6f,0.0f],LeftArm:[-59.9f,10.3f,0.0f]}}
