data merge entity @s {Pose:{Head:[-3.5f,0.0f,0.0f],RightArm:[-105.4f,33.5f,0.0f],LeftArm:[-63.2f,-15.0f,0.0f]}}
