data merge entity @s {Pose:{Head:[10.0f,0.0f,0.0f],RightArm:[-30.0f,-10.0f,0.0f],LeftArm:[-30.0f,10.0f,0.0f]}}
