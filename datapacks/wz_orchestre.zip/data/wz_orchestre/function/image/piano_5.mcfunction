data merge entity @s {Pose:{Head:[20.0f,0.0f,0.0f],RightArm:[-59.9f,-8.6f,0.0f],LeftArm:[-50.1f,4.1f,0.0f]}}
