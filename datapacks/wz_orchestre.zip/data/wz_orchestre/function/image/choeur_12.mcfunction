data merge entity @s {Pose:{Head:[-13.0f,-0.4f,0.0f],RightArm:[-65.0f,-12.0f,0.0f],LeftArm:[-63.0f,14.0f,0.0f]}}
