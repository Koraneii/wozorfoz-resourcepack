data merge entity @s {Pose:{Head:[-7.8f,0.0f,0.0f],RightArm:[-132.7f,0.9f,0.0f],LeftArm:[-86.7f,-15.0f,0.0f]}}
