data merge entity @s {Pose:{Head:[10.0f,0.0f,0.0f],RightArm:[-25.0f,-10.0f,0.0f],LeftArm:[-25.0f,10.0f,0.0f]}}
