data merge entity @s {Pose:{Head:[20.0f,0.0f,0.0f],RightArm:[-55.0f,-5.7f,0.0f],LeftArm:[-55.0f,6.7f,0.0f]}}
