data merge entity @s {Pose:{Head:[-3.5f,0.0f,0.0f],RightArm:[-105.4f,-3.5f,0.0f],LeftArm:[-81.8f,-15.0f,0.0f]}}
