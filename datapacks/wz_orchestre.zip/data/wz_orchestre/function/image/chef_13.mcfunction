data merge entity @s {Pose:{Head:[-8.7f,0.0f,0.0f],RightArm:[-138.1f,22.7f,0.0f],LeftArm:[-77.1f,-15.0f,0.0f]}}
