data merge entity @s {Pose:{Head:[-9.0f,0.0f,0.0f],RightArm:[-140.0f,15.0f,0.0f],LeftArm:[-81.5f,-15.0f,0.0f]}}
