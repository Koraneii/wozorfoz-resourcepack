data merge entity @s {Pose:{Head:[-3.0f,0.4f,0.0f],RightArm:[-59.0f,-12.0f,0.0f],LeftArm:[-57.0f,14.0f,0.0f]}}
